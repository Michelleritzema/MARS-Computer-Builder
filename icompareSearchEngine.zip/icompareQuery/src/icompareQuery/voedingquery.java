package icompareQuery;

import java.util.ArrayList;

public class voedingquery {
		
	    static String cpu_p4p4;
	    static String modulair; 
	    static String Certificering;
	    static String bequiet;
	    static String CoolerMarster;
	    static String Corsair;
	    static String Seasonic;
	    static String XFX;
	    static String pciexpress6pin;
	    static String pciexpress6PPpin;
	    static String VoedingPrijsMin;
	    static String VoedingPrijsMax;
	    static String VoedingVermogenMin;
	    static String VoedingVermogenMax;
	
	
	    
	public static String getvoedingguery(ArrayList alle_data) {
		
		String aansluiting = null;	
		String Modulair1 = null;
		String Certificering1 = null;
		String currentquery = null;
		String merkvoeding = null;
		String pciexpress6pin1 = null;
		String returnquery1 = ("MATCH (n:Item) WHERE n.category = �Voedingen� AND  n.cpuP4_P4='" + aansluiting + "' AND n.modulair = '" + Modulair1 + "'AND  n.certificering='" + Certificering1 + "'  AND n.merk '"+merkvoeding+"' AND n.pciexpress6_2pin = '"+pciexpress6pin1+"' AND n.prijs  <'" + VoedingPrijsMax + "' AND n.prijs > '" + VoedingPrijsMin + "'"
				+ "AND n.  <'" + VoedingVermogenMax + "' AND n.vermogen > '" + VoedingVermogenMin + "'  RETURN n");
		
		currentquery = "query1";

	//CPU P4+P4 aansluiting
	if(alle_data.get(2) == "0") {
		aansluiting = "0";
		}
		else if(alle_data.get(2) == "1") {
			aansluiting = "1";
		}
		else if(alle_data.get(2) == "2") {
			aansluiting = "2";
		}
		else if(alle_data.get(2) == "Geen Voorkeur") {
			aansluiting = "2";
		}
	//modulair	
	if(alle_data.get(3) == "ja") {
		Modulair1 = "Ja";
	}
	else if(alle_data.get(3) == "nee") {
		Modulair1 = "Nee";
	}
//Certificiring 
	if(alle_data.get(4) == "80PLUS") {
		Certificering1 = "0";
		}
		else if(alle_data.get(4) == "80 PLUS Bronze") {
			Certificering1 = "1";
		}
		else if(alle_data.get(4) == "80 PLUS Silver") {
			Certificering1 = "2";
		}
		else if(alle_data.get(4) == "80 PLUS Gold") {
			Certificering1 = "2";
		}
		else if(alle_data.get(4) == "Geencertificering") {
			Certificering1 = "2";
		}
		else if(alle_data.get(4) == "nopreference") {
			Certificering1 = "2";
		}
//merk van het onderdeel
		if(alle_data.get(5) == "BeQuite" && (alle_data.get(6) == "CoolerMaster" 
				&& alle_data.get(7)  == "Corsair" && alle_data.get(8)  == "Seasonic" && (alle_data.get(9)  == "XFX"))) {
			merkvoeding  = "'BeQuite' AND n.merk = 'CoolerMaster' AND n.merk ='Corsair' AND n.merk = 'Seasonic' AND n.merk = 'XFX' ";
			
		}
		else if(alle_data.get(5) == "BeQuite") { 
			merkvoeding = "BeQuite";
		}
		else if(alle_data.get(6) == "CoolerMaster") {
			merkvoeding = "Quad core";
		}
		else if(alle_data.get(7) == "Corsair") {
			merkvoeding = "Corsair";
		}
		else if(alle_data.get(8) == "Seasonic") {
			merkvoeding = "Seasonic";
		}
		else if(alle_data.get(9) == "XFX") {
			merkvoeding = "XFX";
		}
	//PCI Express 6-pin 
		if(alle_data.get(10) == "0") {
			pciexpress6pin1 = "0";
			}
			else if(alle_data.get(10)  == "1") {
				pciexpress6pin1 = "1";
			}
			else if(alle_data.get(10)  == "2") {
				pciexpress6pin1 = "2";
			}
			else if(alle_data.get(10)  == "Geen Voorkeur") {
				pciexpress6pin1 = "2";
			}
		
	//PCI Express 6+2-pin
		if(alle_data.get(11)  == "0") {
			pciexpress6pin1 = "0";
			}
			else if(alle_data.get(11) == "1") {
				pciexpress6pin1 = "1";
			}
			else if(alle_data.get(11) == "2") {
				pciexpress6pin1 = "2";
			}
			else if(alle_data.get(11) == "3") {
				pciexpress6pin1 = "3";
			}
			else if(alle_data.get(11) == "4") {
				pciexpress6pin1 = "4";
			}
			else if(alle_data.get(11) == "5") {
				pciexpress6pin1 = "5";
			}
			else if(alle_data.get(11) == "6") {
				pciexpress6pin1 = "6";
			}
			else if(alle_data.get(11) == "7") {
				pciexpress6pin1 = "7";
			}
			else if(alle_data.get(11) == "8") {
				pciexpress6pin1 = "8";
			}
			else if(alle_data.get(11) == "Geen voorkeur") {
				pciexpress6pin1 = "2";
			}
	
	return returnquery1;
}	
}
		
		
		
		
		
		
		
		
	
			
		
	

