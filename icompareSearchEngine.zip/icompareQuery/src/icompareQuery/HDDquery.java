package icompareQuery;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class HDDquery {
	//Variabelen van website
	static String HarddriveMerkLacie;
    static String HarddriveMerkSeagate;
    static String HarddriveMerToshiba;
    static String HarddriveMerWesternDigital;
    
    static String HarddriveFormaat; 
    static String Harddrivestoragecapacity160gb;
    static String Harddrivestoragecapacity320gb;
    static String Harddrivestoragecapacity500gb;
    static String Harddrivestoragecapacity750gb;
    static String Harddrivestoragecapacity1tb;
    static String Harddrivestoragecapacity2tb;
    static String Harddrivestoragecapacity3tb;
    static String Harddrivestoragecapacity4tb;
    static String Harddrivestoragecapacity5tb;
    static String Harddrivestoragecapacity6tb;
    static String Harddriveconnection;
    static String HarddriveBuffer;
    static String HarddriveSpeed;
    static String HarddrivePriceMin;
    static String HarddrivePriceMax;

	

	    
	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    
	public static String gethardeschijfquery(ArrayList alle_data) {
		//variabelen voor in de queries
		String hddmerk = null;
		String hddformaat = null;
		String hddopslag = null;
		String hddconnection = null;
		String hddbuffer = null;
		String hddspeed = null;
		String currentquery = null;
		String selquery = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		
		String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Internehardeschijven(HDD)� AND  n.merk='" + hddmerk + "'AND  n.formaathardeschijf='" + hddformaat + "' "
							+ "AND  n.opslagcapaciteit='" + hddopslag + "'AND  n.aansluiting='" + hddconnection + "' AND  n.hardeschijfsnelheid='" + hddspeed + "'"
							+ "AND toFloat(m.price) > '"+HarddrivePriceMax+"'AND toFloat(m.price) < '"+HarddrivePriceMin+"' AND m.gisteren RETURN n LIMIT 1");
				
		String returnquery2 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Internehardeschijven(HDD)� AND  n.formaathardeschijf='" + hddformaat + "' "
				+ "AND  n.opslagcapaciteit='" + hddopslag + "'AND  n.aansluiting='" + hddconnection + "'AND  n.hardeschijfsnelheid='" + hddspeed + "'"
				+ "AND toFloat(m.price) > '"+HarddrivePriceMax+"'AND toFloat(m.price) < '"+HarddrivePriceMin+"' AND m.gisteren RETURN n LIMIT 1");
						
		String returnquery3 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Internehardeschijven(HDD)� AND  n.formaathardeschijf='" + hddformaat + "'AND  n.merk='" + hddmerk + "' "
							+ "AND  n.opslagcapaciteit='" + hddopslag + "'AND  n.aansluiting='" + hddconnection + "'"
							+ "AND toFloat(m.price) > '"+HarddrivePriceMax+"'AND toFloat(m.price) < '"+HarddrivePriceMin+"' AND m.gisteren RETURN n LIMIT 1");
								
		String returnquery4 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Internehardeschijven(HDD)� AND  n.formaathardeschijf='" + hddformaat + "' "
							+ "AND  n.opslagcapaciteit='" + hddopslag + "'AND  n.aansluiting='" + hddconnection + "'"
							+ "AND toFloat(m.price) > '"+HarddrivePriceMax+"'AND toFloat(m.price) < '"+HarddrivePriceMin+"' AND m.gisteren RETURN n LIMIT 1");
		
	
				
				//controleert welke onderdelen wel of niet zijn gekozen en bepaalt daarop welke query wordt uitgevoerd
				if (selquery == "Q1" && selquery == "Q3")
				{
					currentquery = "query1";
				}else if (selquery == "Q1" && selquery == "Q4")
				{
					currentquery = "query3";
				}else if (selquery == "Q2" && selquery == "Q3")
				{
					currentquery = "query2";
				}else if (selquery == "Q2" && selquery == "Q4")
				{
					currentquery = "query4";
				}

	
	// Hier wordt gekeken welke checkbox/radio is aangeklikt en wleke waarde deze bevat. Dit wordt van de website opgehaald en de waardes worden in een nieuwe variabele gezet.
		if(alle_data.get(31) == "LaCie" && (alle_data.get(32) == "Seagate" && (alle_data.get(33) == "Toshiba" && (alle_data.get(34) == "WesternDigital")))) {
			hddmerk = "'LaCie' AND n.merk = 'Seagate' AND n.merk = 'Toshiba' AND n.merk = 'WesternDigital' AND n.merk = 'Samsung' AND n.merk = 'Asus'";
			selquery = "query1";
		}
		else if(alle_data.get(31) == "LaCie") { 
			hddmerk = "LaCie";
			selquery = "query1";
		}
		else if(alle_data.get(32) == "Seagate") {
			hddmerk = "Seagate";
			selquery = "query1";
		}
		else if(alle_data.get(33) == "Toshiba") {
			hddmerk = "Toshiba";
			selquery = "query1";
		}
		else if(alle_data.get(34) == "WesternDigital") {
			hddmerk = "WesternDigital";
			selquery = "query1";
		}
		else if(alle_data.get(31) == "chooseplease" && (alle_data.get(32) == "chooseplease" && (alle_data.get(33) == "chooseplease"
				&& (alle_data.get(34) == "chooseplease")))) { 
			selquery = "query2";
		}
		
		if(alle_data.get(35) == "2,5inch") {
			hddformaat = "2,5inch";
		}
		else if(alle_data.get(35) == "3,5inch") {
			hddformaat = "3,5inch";
		}
		
		if(alle_data.get(36) == "160 GB" && (alle_data.get(37) == "320 GB" && (alle_data.get(38) == "500 GB" && (alle_data.get(39) == "750 GB"
			&& (alle_data.get(40) == "1 TB" && (alle_data.get(41) == "2 TB" && (alle_data.get(42) == "3 TB" && (alle_data.get(43) == "4 TB"
			&& (alle_data.get(44) == "5 TB" && (alle_data.get(45) == "6 TB")))))))))) {
			hddopslag = "'160 GB' AND n.opslagcapaciteit = '320 GB' AND n.opslagcapaciteit = '500 GB' AND n.opslagcapaciteit = '750 GB' AND n.opslagcapaciteit = '1 TB'"
			+ "AND n.opslagcapaciteit = '2 TB' AND n.opslagcapaciteit = '3 TB'AND n.opslagcapaciteit = '4 TB' AND n.opslagcapaciteit = '5 TB' AND n.opslagcapaciteit = '6 TB' ";
		}
		else if(alle_data.get(36) == "160 GB") { 
			hddopslag = "160 GB";
		}
		else if(alle_data.get(37) == "320 GB") {
			hddopslag = "320 GB";
		}
		else if(alle_data.get(38) == "500 GB") {
			hddopslag = "500 GB";
		}
		else if(alle_data.get(39) == "750 GB") {
			hddopslag = "750 GB";
		}
		else if(alle_data.get(40) == "1 TB") { 
			hddopslag = "1 TB";
		}
		else if(alle_data.get(41) == "2 TB") {
			hddopslag = "2 TB";
		}
		else if(alle_data.get(42) == "3 TB") {
			hddopslag = "3 TB";
		}
		else if(alle_data.get(43) == "4 TB") {
			hddopslag = "4 TB";
		}
		else if(alle_data.get(44) == "5 TB") {
			hddopslag = "5 TB";
		}
		else if(alle_data.get(45) == "6 TB") {
			hddopslag = "6 TB";
		}
		
		if(alle_data.get(46) == "S-ATA(II)") {
			hddconnection = "S-ATA(II)";
		}
		else if(alle_data.get(46) == "S-ATA(III)") {
			hddconnection = "S-ATA(III)";
		}
		
		
		
		if(alle_data.get(48) == "5400rpm") {
			hddspeed = "5400rpm";
			selquery = "Q3";
		}
		else if(alle_data.get(48) == "5700rpm") {
			hddspeed = "16MB";
			selquery = "Q3";
		}
		else if(alle_data.get(48) == "5900rpm") {
			hddspeed = "32MB";
			selquery = "Q3";
		}
		else if(alle_data.get(48) == "5940rpm") {
			hddspeed = "64MB";
			selquery = "Q3";
		}
		else if(alle_data.get(48) == "7200rpm") {
			hddspeed = "128MB";
			selquery = "Q3";
		}
		else if(alle_data.get(48) == "Geen voorkeur") {
			hddspeed = "5700rpm";
			selquery = "Q3";
		}
		else if(alle_data.get(48) == "chooseplease") {
			hddspeed = "5700rpm";
			selquery = "Q4";
		}
			
		String query = null;
		if(currentquery == "query1") {
			query = returnquery1;
			}
		else if(currentquery == "query2") {
			query = returnquery2;
		}
		else if(currentquery == "query3") {
			query = returnquery3;
		}
		else if(currentquery == "query4") {
			query = returnquery4;
		}
		return query;
		
			}
		}	
	


	


