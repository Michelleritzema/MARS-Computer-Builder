package icompareQuery;
//aff
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;



public class Moederbordquery {
	 static String motherboardMerkAsrock;
	   static String motherboardMerkAsus;
	   static String motherboardMerkMSI;
	   static String motherboardformaat;
	   static String motherboardWifi;
	   static String motherboardmemoryslots;
	   static String motherboardHDMI;
	   static String motherboardVga;
	   static String motherboardDisplayport;
	   static String motherboardPrijsMin;
	   static String motherboardPrijsMax;
	   static String motherboardUsbPort;
	   static String motherboardEthernetport;
	   static String motherboardDVI;
	   static String motherboardRAID0;
	   static String motherboardRAID1;
	   static String motherboardRAID5;
	   static String motherboardRAID10;
	   static String motherboardJBOD;
	   static String motherboardGeen;
	   static String motherboardAudiChannel;
	   static String motherboardMemorytype;
	   static String motherboardmSATAConnection;
	   static String motherboardmSATA300Connection;
	   static String motherboardmSATA600Connection;


	   
	    
	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	
	    public static String getmoederbordquery(ArrayList alle_data) {
		String moederbordmerk = null;
		String moederbordformaat = null;
		String moederbordwifi = null;
		String moederbordgeheugenslots = null;
		String moederbordhdmi = null;
		String moederbordvga = null;
		String moederborddisplayport = null;
		String moederbordethernet = null;
		String moederborddvi = null;
		String moederbordraid = null;
		String moederbordaudio = null;
		String moederbordgeheugentype = null;
		String moederbordmsata = null;
		String currentquery = null;
		String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Moederborden� AND  n.merk='" + moederbordmerk + "'AND  n.formaatmoederbord='" + moederbordformaat + "' "
				+ "AND  n.wifi='" + moederbordwifi + "'AND  n.geheugenslotentotaal='" + moederbordgeheugenslots + "'AND  n.hdmi='" + moederbordhdmi + "' "
				+ "AND toFloat(m.price) > '"+motherboardPrijsMax+"' AND toFloat(m.price) < '"+motherboardPrijsMin+"'AND  n.vgapoort='" + moederbordvga + "'"
				+ "AND  n.displayport='" + moederborddisplayport + "'AND  n.ethernetpoorten='" + moederbordethernet + "'AND  n.dvi='" + moederborddvi + "'"
				+ "AND  n.aantalusb3poorten='" + motherboardUsbPort + "'AND  n.speakerkanalen='" + moederbordaudio + "'"
				+ "AND  n.geheugen='" + moederbordgeheugentype + "'AND m.gisteren RETURN n LIMIT 1");
		String returnquery2 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Moederborden� AND  n.formaatmoederbord='" + moederbordformaat + "' "
							+ "AND  n.wifi='" + moederbordwifi + "'AND  n.geheugenslotentotaal='" + moederbordgeheugenslots + "'AND  n.hdmi='" + moederbordhdmi + "' "
							+ "AND toFloat(m.price) > '"+motherboardPrijsMax+"' AND toFloat(m.price) < '"+motherboardPrijsMin+"'AND  n.vgapoort='" + moederbordvga + "'"
							+ "AND  n.displayport='" + moederborddisplayport + "'AND  n.ethernetpoorten='" + moederbordethernet + "'AND  n.dvi='" + moederborddvi + "'"
							+ "AND  n.aantalusb3poorten='" + motherboardUsbPort + "'AND  n.speakerkanalen='" + moederbordaudio + "'"
							+ "AND  n.geheugen='" + moederbordgeheugentype + "'AND m.gisteren RETURN n LIMIT 1");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
	
				
		if(alle_data.get(152) == "Asrock" && alle_data.get(153) == "Asus" && alle_data.get(154) == "MSI") {
			moederbordmerk = "'Asrock' AND n.merk = 'Asus' AND n.merk = 'MSI'";
			currentquery = "query1";
		}
		else if(alle_data.get(152) == "Asrock") { 
			moederbordmerk = "Asrock";
			currentquery = "query1";
		}
		else if(alle_data.get(153) == "Asus") {
			moederbordmerk = "Asus";
			currentquery = "query1";
		}
		else if(alle_data.get(154) == "MSI") {
			moederbordmerk = "MSI";
			currentquery = "query1";
		}
		else if(alle_data.get(152) == null && alle_data.get(153) == null && alle_data.get(154) == null) {
			currentquery = "query2";
		}
	
		if(alle_data.get(155) == "ATX") {
			moederbordformaat = "ATX";
		}
		else if(alle_data.get(155) == "E-ATX") { 
			moederbordformaat = "E-ATX";
		}
		else if(alle_data.get(155) == "Micro-ATX") {
			moederbordformaat = "Micro-ATX";
		}
		else if(alle_data.get(155) == "Mini-ITX") {
			moederbordformaat = "Mini-ITX";
		}
		else if(alle_data.get(155) == "XL-ATX") {
			moederbordformaat = "XL-ATX";
		}
		
		if(alle_data.get(156) == "Ja") {
			moederbordwifi = "Ja";
		}
		else if(alle_data.get(156) == "Nee") {
			moederbordwifi = "Nee";
		}
		
		if(alle_data.get(157) == "2") {
			moederbordgeheugenslots = "2";
		}
		else if(alle_data.get(157) == "4") {
			moederbordgeheugenslots = "4";
		}
		else if(alle_data.get(157) == "8") {
			moederbordgeheugenslots = "8";
		}
		
		if(alle_data.get(158) == "Ja") {
			moederbordhdmi = "Ja";
		}
		else if(alle_data.get(158) == "Nee") {
			moederbordhdmi = "Nee";
		}
		
		if(alle_data.get(159) == "Ja") {
			moederbordvga = "Ja";
		}
		else if(alle_data.get(159) == "Nee") {
			moederbordvga = "Nee";
		}
		
		if(alle_data.get(160) == "Ja") {
			moederborddisplayport = "Ja";
		}
		else if(alle_data.get(160) == "Nee") {
			moederborddisplayport = "Nee";
		}
		
		if(alle_data.get(164) == "1") {
			moederbordethernet = "1";
		}
		else if(alle_data.get(164) == "2") {
			moederbordethernet = "2";
		}
		
		if(alle_data.get(165) == "Ja") {
			moederborddvi = "Ja";
		}
		else if(alle_data.get(165) == "Nee") {
			moederborddvi = "Nee";
		}
		
		if(alle_data.get(166) == "RAID0" && alle_data.get(167) == "RAID1" && alle_data.get(168) == "RAID5"
				&& alle_data.get(169) == "RAID10" && alle_data.get(170) == "JBOD" && alle_data.get(171) == "geen") {
			moederbordraid = "'RAID0' AND n.raid = 'RAID-1' AND n.raid = 'RAID-5'AND n.raid = 'RAID-10' AND n.raid = 'JBOD' AND n.raid = 'geen'";
		}
		else if(alle_data.get(166) == "RAID0") { 
			moederbordraid = "RAID0";
		}
		else if(alle_data.get(167) == "RAID1") {
			moederbordraid = "RAID1";
		}
		else if(alle_data.get(168) == "RAID5") {
			moederbordraid = "RAID5";
		}
		else if(alle_data.get(169) == "RAID10") { 
			moederbordraid = "RAID10";
		}
		else if(alle_data.get(170) == "JBOD") {
			moederbordraid = "JBOD";
		}
		else if(alle_data.get(171) == "geen") {
			moederbordraid = "geen";
		}
		
		if(alle_data.get(172) == "5.1") {
			moederbordaudio = "5.1";
		}
		else if(alle_data.get(172) == "7.1") {
			moederbordaudio = "7.1";
		}
		
		if(alle_data.get(173) == "DDR3") {
			moederbordgeheugentype = "DDR3";
		}
		else if(alle_data.get(173) == "DIMM") {
			moederbordgeheugentype = "DIMM";
		}
		else if(alle_data.get(173) == "DIMM DDR4") {
			moederbordgeheugentype = "DIMM DDR4";
		}

		if(alle_data.get(174) == "Ja") {
			moederbordmsata = "Ja";
		}
		else if(alle_data.get(174) == "Nee") {
			moederbordmsata = "Nee";
		}

		String query = null;
		if(currentquery == "query1") {
			query = returnquery1;
			}
		else if(currentquery == "query2") {
			query = returnquery2;
		}
		return query;
	}

		
		
			
		}
