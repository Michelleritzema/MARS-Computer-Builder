package icompareQuery;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class Branderquery {
	 static String BluRayDVDMerkAsus;
	   static String BluRayDVDMerkFreecom;
	   static String BluRayDVDMerkApple;
	   static String BluRayDVDMerkLG;
	   static String BluRayDVDMerkSamsung;
	   static String BluRayDVDMerkGeenvoorkeur;
	   
	   static String BluRayDVDDriverType; 
	   static String BluRayDVDPrijsmin;
	   static String BluRayDVDPrijsmax;
	   
	   static String BluRayDVDPlaysDiscBluray;
	   static String BluRayDVDPlaysDiscDVD;
	   static String BluRayDVDPlaysDiscCD;
	   static String BluRayDVDPlaysDiscFloppy;
	   static String BluRayDVDOperatingSystem;
	   static String BluRayDVDtypetray;


	 
	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	   
       public static String getbrander(ArrayList alle_data) {
		
    	   String brandermerk = null;
   		String brandertype = null;
   		String branderspeeltvandisc = null;
   		String branderoperating = null;
   		String brandertypetray = null;
   		String currentquery = null;
   		Calendar cal = Calendar.getInstance();
   		cal.add(Calendar.DATE, -1);
   		String gisteren = dateFormat.format(cal.getTime());
   	//voeg string returnquery(v) ("query die erbij hoort");
   			String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Branders(DVD/Blu-Ray)� AND  n.merk='" + brandermerk + "'AND  n.typedrive='" + brandertype + "' "
							+ "AND  n.geschiktvoor='" + branderoperating + "'AND  n.typelade='" + brandertypetray + "' "
							+ "AND toFloat(m.price) > '"+BluRayDVDPrijsmax+"'AND toFloat(m.price) < '"+BluRayDVDPrijsmin+"' AND m.gisteren RETURN n LIMIT 1");
   			
   			String returnquery2 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Branders(DVD/Blu-Ray)�AND  n.typedrive='" + brandertype + "' "
					+ "AND  n.geschiktvoor='" + branderoperating + "'AND  n.typelade='" + brandertypetray + "' "
					+ "AND toFloat(m.price) > '"+BluRayDVDPrijsmax+"'AND toFloat(m.price) < '"+BluRayDVDPrijsmin+"' AND m.'"+gisteren+"' RETURN n LIMIT 1");
   			
   	
   		if(alle_data.get(248) == "Asus" && alle_data.get(249) == "Freecom" && alle_data.get(250) == "Apple" && alle_data.get(251) == "LG"
   				&& alle_data.get(252) == "Samsung" && alle_data.get(253) == "Geen voorkeur") {
   			brandermerk = "'Asus' AND n.merk = 'Freecom' AND n.merk = 'Apple' AND n.merk = 'LG' AND n.merk = 'Samsung' AND n.merk = 'Asus'";
   			currentquery = "query1";
   		
   		}
   		else if(alle_data.get(248) == "Asus") { 
   			brandermerk = "Asus";
   			currentquery = "query1";
   		}
   		else if(alle_data.get(249) == "Freecom") {
   			brandermerk = "Freecom";
   			currentquery = "query1";
   		}
   		else if(alle_data.get(250) == "Apple") {
   			brandermerk = "Apple";
   			currentquery = "query1";
   		}
   		else if(alle_data.get(251) == "LG") {
   			brandermerk = "qnap";
   			currentquery = "query1";
   		}
   		else if(alle_data.get(252)== "Samsung") {
   			brandermerk = "kingston";
   			currentquery = "query1";
   		}
   		else if(alle_data.get(253)== "Geen voorkeur") {
   			brandermerk = "Asus";
   			currentquery = "query1";
   		}
   		else if(alle_data.get(248) == "chooseplease" && alle_data.get(249) == "chooseplease" && alle_data.get(250) == "chooseplease"
   				&& alle_data.get(251) == "chooseplease" && alle_data.get(252) == "chooseplease" && alle_data.get(253) == "chooseplease" ) { 
   			currentquery = "query2";
   		}
   		
   		if(alle_data.get(254) == "Intern") {
   			brandertype = "Intern";
   		}
   		else if(alle_data.get(254) == "Extern") {
   			brandertype = "Extern";
   		}
   		
   		if(alle_data.get(257) == "Blu-ray" && alle_data.get(258) == "DVD" && alle_data.get(259) == "CD" && alle_data.get(260) == "Floppy") {
   			branderspeeltvandisc = "'Blu-ray' AND n.speeltvandisc = 'DVD' AND n.speeltvandisc = 'CD' AND n.speeltvandisc = 'Floppy' ";
   		}
   		else if(alle_data.get(257) == "Disc") { 
   			branderspeeltvandisc = "Disc";
   		}
   		else if(alle_data.get(258) == "Dvd") {
   			branderspeeltvandisc = "Dvd";
   		}
   		else if(alle_data.get(259) == "Cd") {
   			branderspeeltvandisc = "Cd";
   		}
   		else if(alle_data.get(260) == "Floppy") {
   			branderspeeltvandisc = "Floppy";
   		}
   		
   		if(alle_data.get(261) == "Windows") {
   			branderoperating = "Windows";
   		}
   		else if(alle_data.get(261) == "Mac OS X") {
   			branderoperating = "Mac OS X";
   		}
   		
   		if(alle_data.get(262)  == "Lade") {
   			brandertypetray = "Lade";
   		}
   		else if(alle_data.get(262)  == "Slot-in") {
   			brandertypetray = "Slot-in";
   		}
   		
   
   			String query = null;
   			if(currentquery == "query1") {
   				query = returnquery1;
   				}
   			else if(currentquery == "query2") {
   				query = returnquery2;
   			}
   			return query;
   			
   			}	
   	}
   
