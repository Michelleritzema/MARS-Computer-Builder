package icompareQuery;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class InternMemory {
	 static String internalmemoryCorsair;
	   static String internalmemoryCrucial;
	   static String internalmemorykingston;
	   static String internalmemoryqnap;
	   static String internalmemorysynology;
	   static String internalmemorygeenvoorkeur;
	   
	   static String internalmemoryRAM1GB;
	   static String internalmemoryRAM2GB;
	   static String internalmemoryRAM4GB;
	   static String internalmemoryRAM8GB;
	   static String internalmemoryRAM16GB;
	   static String internalmemoryRAM32GB;
	   
	   static String internalmemoryclocking;
	   
	   static String internalmemoryGaming;
	   
	   static String internalmemorysuitableforDesktop;
	   static String internalmemorysuitableforLaptop;
	   static String internalmemorysuitableforNas;
	   static String internalmemorysuitableforMac;

	   static String internalmemoryType;
	   static String internalmemoryChannel;
	   
	   static String internalmemoryPrijsMin;
	   
	   static String internalmemoryPrijsMax;

	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    
	    public static String getinternmemory(ArrayList alle_data) {
		String internalmemorymerk = null;
		String internalmemoryram = null;
		String internalmemorykloksnelheid = null;
		String internalmemorygame = null;
		String internalmemorysuitable = null;
		String internalmemorytype = null;
		String internalmemorykanaal = null;
		String currentquery = null;
		String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �intern geheugen� AND  n.merk='" + internalmemorymerk + "'AND  n.ramgeheugen='" + internalmemoryram + "' "
							+ "AND  n.kloksnelheidgeheugenmodule='" + internalmemorykloksnelheid + "'AND  n.geschiktvoorgaming='" + internalmemorygame + "'AND  n.geheugengeschiktvoor='" + internalmemorysuitable + "' "
									+ "AND toFloat(m.price) > '"+internalmemoryPrijsMax+"'AND toFloat(m.price) < '"+internalmemoryPrijsMin+"' AND m.gisteren RETURN n LIMIT 1");
	
		String returnquery2 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �intern geheugen� AND  n.ramgeheugen='" + internalmemoryram + "' AND  n.kloksnelheidgeheugenmodule='" + internalmemorykloksnelheid + "'"
					+ "AND  n.geschiktvoorgaming='" + internalmemorygame + "'AND  n.geheugengeschiktvoor='" + internalmemorysuitable + "' AND n.typegeheugen= '" + internalmemorytype + "' "
							+ "AND n.aantalgeheugenkanalen= '" + internalmemorykanaal + "'AND toFloat(m.price) > '"+internalmemoryPrijsMax+"'AND toFloat(m.price) < '"+internalmemoryPrijsMin+"' AND m.gisteren RETURN n LIMIT 1");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		
	
	
		if(alle_data.get(130) == "Corsair" && alle_data.get(131) == "Crusial" && alle_data.get(132) == "kingston" && alle_data.get(133) == "qnap"
				&& alle_data.get(134) == "synology" && alle_data.get(13) == "kingston") {
			internalmemorymerk = "'Corsair' AND n.merk = 'Crusial' AND n.merk = 'kingston' AND n.merk = 'qnap' AND n.merk = 'synology' AND n.merk = 'kingston'";
			currentquery = "query1";
		}
		else if(alle_data.get(130)  == "Corsair") { 
			internalmemorymerk = "Corsair";
			currentquery = "query1";
		}
		else if(alle_data.get(131)  == "Crucial") {
			internalmemorymerk = "Crusial";
			currentquery = "query1";
		}
		else if(alle_data.get(132)  == "kingston") {
			internalmemorymerk = "kingston";
			currentquery = "query1";
		}
		else if(alle_data.get(133)  == "qnap") {
			internalmemorymerk = "qnap";
			currentquery = "query1";
		}
		else if(alle_data.get(134)  == "synology") {
			internalmemorymerk = "qnap";
			currentquery = "query1";
		}
		else if(alle_data.get(135) == "Geen voorkeur") {
			internalmemorymerk = "kingston";
			currentquery = "query1";
		}
		else if(alle_data.get(130) == null && alle_data.get(131) == null && alle_data.get(132) == null
				&& alle_data.get(133) == null && alle_data.get(134) == null && alle_data.get(135) == null ) { 
			currentquery = "query2";
		}
		
		if(alle_data.get(136) == "1 GB" && alle_data.get(137) == "2 GB" 
				&& alle_data.get(138) == "4 GB" && alle_data.get(139) == "8 GB"
				&& alle_data.get(140) == "16 GB" && alle_data.get(141) == "32 GB") {
			internalmemoryram = "'1 GB' AND n.ramgeheugen = '2 GB' AND n.ramgeheugen ='4 GB'"
					+ "AND n.ramgeheugen = '8 GB'AND n.ramgeheugen = '16GB' AND n.ramgeheugen = '32 GB'   ";
		}
		else if(alle_data.get(136) == "1 GB") { 
			internalmemoryram = "1 GB";
		}
		else if(alle_data.get(137) == "2 GB") {
			internalmemoryram = "2 GB";
		}
		else if(alle_data.get(138) == "4 GB") {
			internalmemoryram = "4 GB";
		}
		else if(alle_data.get(139) == "8 GB") {
			internalmemoryram = "8 GB";
		}
		else if(alle_data.get(140) == "16 GB") {
			internalmemoryram = "16 GB";
		}
		else if(alle_data.get(141) == "32 GB") {
			internalmemoryram = "32 GB";
		}
		
		if(alle_data.get(142) == "667 MHz") {
			internalmemorykloksnelheid = "667 MHz";
		}
		else if(alle_data.get(142) == "800 MHz") {
			internalmemorykloksnelheid = "800 MHz";
		}
		else if(alle_data.get(142) == "1333 MHz") {
			internalmemorykloksnelheid = "1333 MHz";
		}
		else if(alle_data.get(142) == "1600 MHz") {
			internalmemorykloksnelheid = "1600 MHz";
		}
		
		if(alle_data.get(143) == "Ja") {
			internalmemorygame = "Ja";
		}
		else if(alle_data.get(143)  == "Nee") {
			internalmemorygame = "Nee";
		}
		
		if(alle_data.get(144)  == "Desktop" && alle_data.get(145)  == "Laptop" && alle_data.get(146)  == "Nas" && alle_data.get(147)  == "Mac") {
			internalmemorysuitable = "'Desktop' AND n.geheugengeschiktvoor = 'Laptop' AND n.geheugengeschiktvoor = 'NAS' AND n.geheugengeschiktvoor = 'Mac' ";
		}
		else if(alle_data.get(144)  == "Desktop") { 
			internalmemorysuitable = "Desktop";
		}
		else if(alle_data.get(145)  == "Laptop") {
			internalmemorysuitable = "Laptop";
		}
		else if(alle_data.get(146)  == "Nas") {
			internalmemorysuitable = "Nas";
		}
		else if(alle_data.get(147)  == "Mac") {
			internalmemorysuitable = "Mac";
		}
		
		if(alle_data.get(148)  == "DDR2") {
			internalmemorytype = "DDR2";
		}
		else if(alle_data.get(148) == "DDR3") {
			internalmemorytype = "DDR3";
		}
		else if(alle_data.get(148) == "DIMM DDR3") {
			internalmemorytype = "DIMM DDR3";
		}
		else if(alle_data.get(148) == "DIMM DDR4") {
			internalmemorytype = "DIMM DDR4";
		}
		
		if(alle_data.get(149) == "Single Channel") {
			internalmemorykanaal = "Single Channel";
		}
		else if(alle_data.get(149) == "Dual Channel") {
			internalmemorykanaal = "Dual Channel";
		}
		else if(alle_data.get(149) == "Quad Channel") {
			internalmemorykanaal = "Quad Channel";
		}
		if(internalmemoryChannel == "Single Channel") {
			internalmemorykanaal = "1 (Single Channel)";
		}
		else if(internalmemoryChannel == "Dual Channel") {
			internalmemorykanaal = "2 (Dual Channel)";
		}
		else if(internalmemoryChannel == "Quad Channel") {
			internalmemorykanaal = "4 (Quad Channel)";
		}
	    String query = null;
		if(currentquery == "query1") {
			query = returnquery1;
			}
		else if(currentquery == "query2") {
			query = returnquery2;
		}
		return query;
	    
	    
	    
	    
	}


		
	}

