package icompareQuery;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class videokaartquery {
	//Variabelen van website
	  static String VideocardmanufacturerNvidia;
	   static String VideocardAmdAMDRadeonR9270X;
	   static String VideocardAmdAMDRadeonR7240;
	   static String VideocardAmdAMDRadeonR9280;
	   static String VideocardAmdAMDRadeonR9290;
	   static String VideocardAmdAMDRadeonR7250;
	   static String VideocardAmdAMDRadeonR9270;
	   static String VideocardAmdAMDRadeonHD6450;
	   static String VideocardAmdAMDRadeonR9280X;
	   static String VideocardAmdAMDRadeonR9290X;
	   static String VideocardAmdAMDRadeonHD3450AGP;
	    
	   static String VideocardmanufacturerAmd;
	   static String VideocardnvidiaNVIDIAFX5500;
	   static String VideocardnvidiaNVIDIAGeForceGTX980;
	   static String VideocardnvidiaNVIDIAGeForceGT730;
	   static String VideocardnvidiaNVIDIAGeForceGTX750;
	   static String VideocardnvidiaNVIDIAGeForceGT740;
	   static String VideocardnvidiaNVIDIAGeForceGTX780;
	   static String VideocardnvidiaNVIDIAGeForceGTX970;
	   static String VideocardnvidiaNVIDIAGeForceGTX660;
	   static String VideocardnvidiaNVIDIAGeForceGTX760;
	   static String VideocardnvidiaNVIDIAGeForceGTX770;
	   
	   static String VideocardMerkAsus;
	   static String VideocardMerkClub3d;
	   static String VideocardMerkGigabyte;
	   static String VideocardMerkSapphire;
	   static String VideocardMerkMSI;
	   static String VideocardMerkGeenvoorkeur;
	   
	   static String VideocardTyeMemory;
	   static String VideocardHdmi;
	   static String VideocardVga;
	   static String VideocardMemorybus;
	   static String VideocardDVIIConnection;
	   static String VideocardDVIDConnection;
	   static String VideocardPrijsMin;
	   static String VideocardPrijsMax;
	   static String VideocardMemorryMBMin;
	   static String VideocardMemorryMBMax;

	   
	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    
	public static String getvideokaartenquery(ArrayList alle_data) {
		//variabelen voor in de queries
		String videokaartfabrikant = null;
		String videokaartmerk = null;
		String videokaartmerkamd = null;
		String videokaartmerknvidia = null;
		String videokaarttypegeheugen = null;
		String videokaarthdmi = null;
		String videokaartvga = null;
		String videokaartmemorybus = null;
		String videogeheugen = null;
		String currentquery = null;
		String selquery = null;
		String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.fabrikant='" + videokaartfabrikant + "'AND  n.typegpu='" + videokaartmerkamd + "'"
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+" AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ "AND m.gisteren RETURN n LIMIT 1");
		String returnquery2 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND n.fabrikant='" + videokaartfabrikant + "'"
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND n.hdmi='" + videokaarthdmi + "' "
							+ "AND n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ "  AND m.gisteren RETURN n LIMIT 1");
		String  returnquery3 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.fabrikant='" + videokaartfabrikant + "'AND n.typegpu='" + videokaartmerkamd + "'"
							+ "AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery4 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.fabrikant='" + videokaartfabrikant + "'AND n.typegpu='" + videokaartmerkamd + "'"
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND n.hdmi='" + videokaarthdmi + "' "
							+ "AND n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"' AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery5 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND n.fabrikant='" + videokaartfabrikant + "'"
							+ "AND n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND n.hdmi='" + videokaarthdmi + "' "
							+ "AND n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery6 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.fabrikant='" + videokaartfabrikant + "'AND n.typegpu='" + videokaartmerkamd + "'"
							+ "AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ "AND m.gisteren RETURN n LIMIT 1");
		String returnquery7 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.fabrikant='" + videokaartfabrikant + "'"
							+ "AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery8 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.fabrikant='" + videokaartfabrikant + "'"
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"' AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery9 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.typegpu='" + videokaartmerkamd + "'"
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery10 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� "
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery11 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.typegpu='" + videokaartmerkamd + "'"
							+ "AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery12 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND  n.typegpu='" + videokaartmerkamd + "'"
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery13 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND "
							+ "AND  n.merk='" + videokaartmerk + "'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery14 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� AND AND  n.typegpu='" + videokaartmerkamd + "'"
							+ "AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery15 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� "
							+ "AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		String returnquery16 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Videokaarten� "
							+ "AND n.typegpu='" + videokaartmerknvidia +"'AND  n.typegeheugen='" + videokaarttypegeheugen + "'AND  n.hdmi='" + videokaarthdmi + "' "
							+ "AND  n.vgapoort='" + videokaartvga + "'AND  n.bandbreedtegeheugenbus='" + videokaartmemorybus + "'"
							+ " AND toFloat(m.price) > '"+VideocardPrijsMax+"' AND toFloat(m.price) < '"+VideocardPrijsMin+"'  AND n.videogeheugen  <'" + videogeheugen + "'"
							+ " AND m.gisteren RETURN n LIMIT 1");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		
	
				//controleert welke onderdelen wel of niet zijn gekozen en bepaalt daarop welke query wordt uitgevoerd
				if (selquery == "Q1" && selquery == "Q3" && selquery == "Q5" && selquery == "Q7")
				{
					currentquery = "query1";
				}else if (selquery == "Q1" && selquery == "Q4" && selquery == "Q5" && selquery == "Q7")
				{
					currentquery = "query2";
				}else if (selquery == "Q1" && selquery == "Q3" && selquery == "Q6" && selquery == "Q7")
				{
					currentquery = "query3";
				}else if (selquery == "Q1" && selquery == "Q3" && selquery == "Q5" && selquery == "Q8")
				{
					currentquery = "query4";
				}
				else if (selquery == "Q1" && selquery == "Q4" && selquery == "Q6" && selquery == "Q7")
				{
					currentquery = "query5";
				}else if (selquery == "Q1" && selquery == "Q3" && selquery == "Q6" && selquery == "Q8")
				{
					currentquery = "query6";
				}else if (selquery == "Q1" && selquery == "Q4" && selquery == "Q6" && selquery == "Q8")
				{
					currentquery = "query7";
				}else if (selquery == "Q1" && selquery == "Q4" && selquery == "Q5" && selquery == "Q8")
				{
					currentquery = "quer8";
				}
				else if (selquery == "Q2" && selquery == "Q3" && selquery == "Q5" && selquery == "Q7")
				{
					currentquery = "query9";
				}else if (selquery == "Q2" && selquery == "Q4" && selquery == "Q5" && selquery == "Q7")
				{
					currentquery = "query10";
				}else if (selquery == "Q2" && selquery == "Q3" && selquery == "Q6" && selquery == "Q7")
				{
					currentquery = "query11";
				}else if (selquery == "Q2" && selquery == "Q3" && selquery == "Q5" && selquery == "Q8")
				{
					currentquery = "query12";
				}else if (selquery == "Q2" && selquery == "Q4" && selquery == "Q6" && selquery == "Q7")
				{
					currentquery = "query13";
				}else if (selquery == "Q2" && selquery == "Q3" && selquery == "Q6" && selquery == "Q8")
				{
					currentquery = "query14";
				}else if (selquery == "Q2" && selquery == "Q4" && selquery == "Q6" && selquery == "Q8")
				{
					currentquery = "query15";
				}else if (selquery == "Q2" && selquery == "Q4" && selquery == "Q5" && selquery == "Q8")
				{
					currentquery = "query16";
				}
				
				
	
	// Hier wordt gekeken welke checkbox/radio is aangeklikt en wleke waarde deze bevat. Dit wordt van de website opgehaald en de waardes worden in een nieuwe variabele gezet.
		if(alle_data.get(73) == "NVIDIA" && alle_data.get(74) == "AMD") {
			videokaartfabrikant = "'NVIDIA' AND n.fabrikant = 'AMD' ";
			selquery = "Q1";
		}
		else if(alle_data.get(73) == "NVIDIA") { 
			videokaartfabrikant = "NVIDIA";
			selquery = "Q1";
		}
		else if(alle_data.get(74) == "AMD") {
			videokaartfabrikant = "AMD";
			selquery = "Q1";
		}else if(VideocardmanufacturerNvidia == "chooseplease" && VideocardmanufacturerAmd == "chooseplease") { 
			selquery = "Q2";
		}
		
		if(alle_data.get(75) == "AMDRadeonR9270X" && alle_data.get(77) == "AMDRadeonR7240" && alle_data.get(79) == "AMDRadeonR9280" && alle_data.get(81) == "AMDRadeonR9290"
				&& alle_data.get(88) == "AMDRadeonR7250" && alle_data.get(76) == "AMDRadeonR9270" && alle_data.get(78) == "AMDRadeonHD6450" && alle_data.get(80) == "AMDRadeonR9280X"
				&& VideocardAmdAMDRadeonR9290X == "AMDRadeonR9290X" && VideocardAmdAMDRadeonHD3450AGP == "AMDRadeonHD3450AGP") {
			videokaartmerkamd = "'AMD Radeon R9 270X' AND n.typegpu = 'AMD Radeon R7 240' AND n.typegpu = 'AMD Radeon R9 280' AND n.typegpu = 'AMD Radeon R9 290' AND n.typegpu = 'AMD Radeon R7 250' AND n.typegpu = 'AMD Radeon R9 270'"
					+ "AND n.typegpu = 'AMD Radeon HD 6450' AND n.typegpu = 'AMD Radeon R9 280X' AND n.typegpu = 'AMD Radeon R9 290X' AND n.typegpu = 'AMD Radeon HD 3450AGP'";
			selquery = "Q3";
		}
		else if(alle_data.get(75) == "AMDRadeonR9270X") { 
			videokaartmerkamd = "AMD Radeon R9 270X";
			selquery = "Q3";
		}
		else if(alle_data.get(76)  == "AMDRadeonR9270") {
			videokaartmerkamd = "AMDRadeonR9270";
			selquery = "Q3";
		}else if(alle_data.get(77)  == "AMDRadeonR7240") { 
			videokaartmerkamd = "AMD Radeon R7240";
			selquery = "Q3";
		}
		else if(alle_data.get(78)  == "AMDRadeonHD6450") {
			videokaartmerkamd = "AMD RadeonHD 6450";
			selquery = "Q3";
		}
		else if(alle_data.get(79)  == "AMDRadeonR9280") { 
			videokaartmerkamd = "AMD Radeon R9280";
			selquery = "Q3";
		}
		else if(alle_data.get(80)  == "AMDRadeonR9280X") {
			videokaartmerkamd = "AMD Radeon R9280X";
			selquery = "Q3";
		}
		else if(alle_data.get(81) == "AMDRadeonR9290") { 
			videokaartmerkamd = "AM DRadeon R9290";
			selquery = "Q3";
		}
		else if(alle_data.get(82) == "AMDRadeonR9290X") {
			videokaartmerkamd = "AMD Radeon R9290X";
			selquery = "Q3";
		}
		else if(alle_data.get(83) == "AMDRadeonR7250") { 
			videokaartmerkamd = "AMD Radeon R7250";
			selquery = "Q3";
		}
		else if(alle_data.get(84) == "AMDRadeonHD3450AGP") {
			videokaartmerkamd = "AMD Radeon HD 3450AGP";
			selquery = "Q3";
		}
		
		else if((alle_data.get(75)) == "chooseplease" && (alle_data.get(77)) == "chooseplease"&& (alle_data.get(79)) == "chooseplease" && (alle_data.get(81)) == "chooseplease"
				&& (alle_data.get(83)) == "chooseplease" && (alle_data.get(76)) == "chooseplease" && (alle_data.get(78)) == "chooseplease" && (alle_data.get(80)) == "chooseplease"
				&& (alle_data.get(82)) == "chooseplease" && (alle_data.get(84)) == "chooseplease") { 
			selquery = "Q4";
		}
		
		if(alle_data.get(85) == "NVIDIAFX5500" && alle_data.get(87) == "NVIDIAGeForceGTX980" && alle_data.get(89) == "NVIDIAGeForceGT730" && (alle_data.get(91) == "NVIDIAGeForceGTX750"
				&& (alle_data.get(93) == "NVIDIAGeForceGT740" && alle_data.get(86) == "NVIDIAGeForceGTX780" && (alle_data.get(88) == "NVIDIAGeForceGTX970" && (alle_data.get(90) == "NVIDIAGeForceGTX660"
				&& (alle_data.get(92) == "NVIDIAGeForceGTX760" && (alle_data.get(94) == "NVIDIAGeForceGTX770"))))))) {
			videokaartmerknvidia = "'NVIDIA FX5500' AND n.typegpu = 'NVIDIA GeForce GTX 980' AND n.typegpu = 'NVIDIA GeForce GT 730' AND n.typegpu = 'NVIDIA GeForce GTX 750' "
					+ "AND n.typegpu = 'NVIDIA GeForce GT 740' AND n.typegpu = 'NVIDIA GeForce GTX 780'"
					+ "AND n.typegpu = 'NVIDIA GeForce GTX 970' AND n.typegpu = 'NVIDIA GeForce GTX 660' AND n.typegpu = 'NVIDIA GeForce GTX 760' AND n.typegpu = 'NVIDIA GeForce GTX 770'";
			selquery = "Q5";
		}
		else if(alle_data.get(85) == "NVIDIAFX5500") { 
			videokaartmerknvidia = "NVIDIA FX5500";
			selquery = "Q5";
		}else if(alle_data.get(86) == "NVIDIAGeForceGTX780") {
			videokaartmerknvidia = "NVIDIAGeForceGTX780";
			selquery = "Q5";
		}else if(alle_data.get(87) == "NVIDIAGeForceGTX980") { 
			videokaartmerknvidia = "NVIDIA GeForce GT 980";
			selquery = "Q5";
		}else if(alle_data.get(88) == "NVIDIAGeForceGTX970") {
			videokaartmerknvidia = "NVIDIA GeForce GTX 970";
			selquery = "Q5";
		}else if(alle_data.get(89) == "NVIDIAGeForceGT730") { 
			videokaartmerknvidia = "NVIDIA GeForce GT 730";
			selquery = "Q5";
		}else if(alle_data.get(90) == "NVIDIAGeForceGTX660") {
			videokaartmerknvidia = "NVIDIA GeForce GTX 660";
			selquery = "Q5";
		}else if(alle_data.get(91) == "NVIDIAGeForceGTX750") { 
			videokaartmerknvidia = "NVIDIA GeForce GTX 750";
			selquery = "Q5";
		}else if(alle_data.get(92) == "NVIDIAGeForceGTX760") {
			videokaartmerknvidia = "NVIDIA GeForce GTX 760";
			selquery = "Q5";
		}else if(alle_data.get(93)== "NVIDIA GeForce GT 740") { 
			videokaartmerknvidia = "NVIDIA GeForce GT 740";
			selquery = "Q5";
		}else if(alle_data.get(94) == "NVIDIAGeForceGTX770") {
			videokaartmerknvidia = "NVIDIA GeForce GTX 770";
			selquery = "Q5";
		}else if(alle_data.get(85) == "chooseplease" && alle_data.get(87) == "chooseplease"&& alle_data.get(89) == "chooseplease" && alle_data.get(91) == "chooseplease"
				&& alle_data.get(93) == "chooseplease" && alle_data.get(87) == "chooseplease" && alle_data.get(88) == "chooseplease" && alle_data.get(66) == "chooseplease"
				&& alle_data.get(92) == "chooseplease" && alle_data.get(94) == "chooseplease") { 
			selquery = "Q6";
		}
		
		if(alle_data.get(95) == "Asus" && alle_data.get(96) == "Club3D" && alle_data.get(97) == "Gigabyte" && alle_data.get(98) == "Sapphire"
				&& alle_data.get(99) == "MSI" && alle_data.get(100) == "Geen voorkeur" ) {
			videokaartmerk = "'Asus' AND n.merk = 'Club 3D' AND n.merk = 'Gigabyte' AND n.merk = 'Sapphire' "
					+ "AND n.merk = 'MSI' AND n.merk = 'Asus'";
			selquery = "Q7";
		}
		else if(alle_data.get(95) == "Asus") { 
			videokaartmerk = "Asus";
			selquery = "Q7";
		}else if(alle_data.get(96) == "Club3D") {
			videokaartmerk = "Club 3D";
			selquery = "Q7";
		}else if(alle_data.get(97) == "Gigabyte") { 
			videokaartmerk = "Gigabyte";
			selquery = "Q7";
		}else if(alle_data.get(98) == "Sapphire") {
			videokaartmerk = "Sapphire";
			selquery = "Q7";
		}else if(alle_data.get(99) == "MSI") { 
			videokaartmerk = "MSI";
			selquery = "Q7";
		}else if(alle_data.get(100) == "Geen voorkeur") {
			videokaartmerk = "Asus";
			selquery = "Q7";
		}else if(alle_data.get(95) == "chooseplease" && alle_data.get(96) == "chooseplease"&& alle_data.get(97) == "chooseplease" && alle_data.get(98) == "chooseplease"
				&& alle_data.get(99) == "chooseplease" && alle_data.get(100) == "chooseplease" ) { 
			selquery = "Q8";
		}
		
		if(alle_data.get(101) == "DDR") {
			videokaarttypegeheugen = "DDR";
		}else if(alle_data.get(101) == "DDR2") {
			videokaarttypegeheugen = "DDR2";
		}else if(alle_data.get(101) == "DDR3") {
			videokaarttypegeheugen = "DDR3";
		}else if(alle_data.get(101) == "GDDR5") {
			videokaarttypegeheugen = "GDDR5";
		}else if(alle_data.get(101) == "Geen voorkeur") {
			videokaarttypegeheugen = "DDR3";
		}
		
		if(alle_data.get(102) == "0") {
			videokaarthdmi = "0";
		}else if(alle_data.get(102) == "1") {
			videokaarthdmi = "1";
		}else if(alle_data.get(102) == "2") {
			videokaarthdmi = "2";
		}
		
		if(alle_data.get(103) == "Ja") {
			videokaartvga = "Ja";
		}else if(alle_data.get(103)== "Nee") {
			videokaartvga = "Nee";
		}
		
		if(alle_data.get(104) == "64bit") {
			videokaartmemorybus = "64bit";
		}else if(alle_data.get(104) == "128bit") {
			videokaartmemorybus = "128bit";
		}else if(alle_data.get(104) == "192bit") {
			videokaartmemorybus = "192bit";
		}else if(alle_data.get(104) == "256bit") {
			videokaartmemorybus = "256bit";
		}else if(alle_data.get(104) == "384bit") {
			videokaartmemorybus = "384bit";
		}else if(alle_data.get(104) == "512bit") {
			videokaartmemorybus = "512bit";
		}else if(alle_data.get(104) == "Geen voorkeur") {
			videokaartmemorybus = "256bit";
		}
		
		if(Integer.parseInt(VideocardMemorryMBMin) < 255 && Integer.parseInt(VideocardMemorryMBMax) > 257 ) {
			videogeheugen = "256 MB";
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 511 && Integer.parseInt(VideocardMemorryMBMax)  > 513) { 
			videogeheugen = "512 MB";	
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 1023 && Integer.parseInt(VideocardMemorryMBMax)  > 1025) { 
			videogeheugen = "1024 MB";	
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 2047 && Integer.parseInt(VideocardMemorryMBMax)  > 2049) { 
			videogeheugen = "2048 MB";	
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 3071 && Integer.parseInt(VideocardMemorryMBMax)  > 3073) { 
			videogeheugen = "3072 MB";	
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 4095 && Integer.parseInt(VideocardMemorryMBMax)  > 4097) { 
			videogeheugen = "4096 MB";	
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 8095 && Integer.parseInt(VideocardMemorryMBMax)  > 8097) { 
			videogeheugen = "8094 MB";	
		}else if(Integer.parseInt(VideocardMemorryMBMin) < 8191 && Integer.parseInt(VideocardMemorryMBMax)  > 8193) { 
			videogeheugen = "8192 MB";	
		}

	String query = null;
	if(currentquery == "query1") {
		query = returnquery1;
		}
	else if(currentquery == "query2") {
		query = returnquery2;
	}
	else if(currentquery == "query3") {
		query = returnquery3;
	}
	else if(currentquery == "query4") {
			query = returnquery4;
		}
	else if(currentquery == "query5") {
		query = returnquery5;
	}
	else if(currentquery == "query6") {
		query = returnquery6;
	}
	else if(currentquery == "query7") {
		query = returnquery7;
	}
	else if(currentquery == "query8") {
		query = returnquery8;
	}
	else if(currentquery == "query9") {
		query = returnquery9;
	}
	else if(currentquery == "query10") {
		query = returnquery10;
	}
	else if(currentquery == "query11") {
		query = returnquery11;
	}
	else if(currentquery == "query12") {
		query = returnquery12;
	}
	else if(currentquery == "query13") {
		query = returnquery13;
	}
	else if(currentquery == "query14") {
		query = returnquery14;
	}
	else if(currentquery == "query15") {
		query = returnquery15;
	}
	else if(currentquery == "query16") {
		query = returnquery16;
	}
	
	return query;
	
	}
}













