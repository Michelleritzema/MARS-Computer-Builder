package icompareQuery;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.io.*;

import org.neo4j.cypher.javacompat.ExecutionEngine;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;


public class Main {
	private static final String Neo4J_DBPath = "C:/Users/Anny/Documents/Neo4j/default.graphdb";

	    static GraphDatabaseService graphDataService;
	    Transaction transaction = graphDataService.beginTx();


	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		graphDataService = new GraphDatabaseFactory().newEmbeddedDatabase(Neo4J_DBPath);    
		try
			(Transaction tx = graphDataService.beginTx();) {
			ExecutionEngine engine = new ExecutionEngine(graphDataService);
		      
		         String clientSentence;
		         String capitalizedSentence;
		         ServerSocket welcomeSocket = new ServerSocket(6789);

		         while(true)
		         {
		            Socket connectionSocket = welcomeSocket.accept();
		            BufferedReader inFromClient =
		               new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
		            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
		            clientSentence = inFromClient.readLine();
		            //System.out.println("Received: " + clientSentence);
		            System.out.println(clientSentence);
		            capitalizedSentence = clientSentence.toUpperCase() + '\n';
		            Thread.sleep(4000);
		            outToClient.writeBytes(capitalizedSentence);
		            System.out.println("I did it!");
		            connectionSocket.close(); //this line was part of the solution
		        
	ArrayList alle_data = Translate.translateAll(clientSentence);
    String voeding_query = voedingquery.getvoedingguery(alle_data);
    System.out.println("1");
    Processorkoeler.getprocessorquery(alle_data);
    System.out.println("2");
    Geluidskaarten.getgeluidskaarten(alle_data);
    HDDquery.gethardeschijfquery( alle_data);
    Pciquery.getpciquery(alle_data);
    videokaartquery.getvideokaartenquery(alle_data);  
    ssdquery.getssdquery(alle_data);
    Branderquery.getbrander(alle_data);
    Behuizingquery.getbehuizing(alle_data);
    processorquery.getprocessorquery(alle_data);
    InternMemory.getinternmemory( alle_data); 
    Moederbordquery.getmoederbordquery(alle_data);
    

    //Make the files where we are going to put the data we got from the database
	File moederborden1 = new File("C:/Users/Anny/Desktop/raw_moederborden.json");
		
	ArrayList<Object> data = new ArrayList<Object>();	
    data.set(0,alle_data);
		FileWriter fw11 = new FileWriter(moederborden1.getAbsoluteFile());
    BufferedWriter bw11 = new BufferedWriter(fw11);
    bw11.write(data.toString());   
    System.out.println(bw11);
		         }
		}    
}
}