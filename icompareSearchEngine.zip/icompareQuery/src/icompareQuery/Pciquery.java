package icompareQuery;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Pciquery {
	//Variabelen van website
	 static String PciUsb;
	    static String PciFirewire;
	    static String PciSataConnection;
	    static String PciESataConnection;
	    static String PciPrijsMin;
	    static String PciPrijsMax;
    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    
	public static String getpciquery(ArrayList alle_data) {
		//variabelen voor in de queries
		String pciusbpoort = null;
		String pcifire = null;
		String pcisata = null;
		String pciesata = null;
		String currentquery = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �PCIExpresskaarten(HDD)� AND  n.usbpoort='" + pciusbpoort + "'AND  n.fireWire='" + pcifire + "' "
							+ "AND toFloat(m.price) > '"+PciPrijsMax+"'AND toFloat(m.price) < '"+PciPrijsMin+"' AND m.'"+gisteren+"' RETURN n LIMIT 1");
		
	// Hier wordt gekeken welke checkbox/radio is aangeklikt en wleke waarde deze bevat. Dit wordt van de website opgehaald en de waardes worden in een nieuwe variabele gezet.		
		if(alle_data.get(67) == "Ja") {
			pciusbpoort = "Ja";
			currentquery = "query1";
		}
		else if(alle_data.get(67) == "Nee") {
			pciusbpoort = "Nee";
			currentquery = "query1";
		}
		
		if(alle_data.get(68) == "Ja") {
			pcifire = "Ja";
			currentquery = "query1";
		}
		else if(alle_data.get(68) == "Nee") {
			pcifire = "Nee";
			currentquery = "query1";
		}
		
		if(alle_data.get(69) == "Ja") {
			pcisata = "Ja";
			currentquery = "query1";
		}
		else if(alle_data.get(69) == "Nee") {
			pcisata = "Nee";
			currentquery = "query1";
		}
		
		if(alle_data.get(70) == "Ja") {
			pciesata = "Ja";
			currentquery = "query1";
		}
		else if(alle_data.get(70) == "Nee") {
			pciesata = "Nee";
			currentquery = "query1";
		}
		
return returnquery1;
	}
}

