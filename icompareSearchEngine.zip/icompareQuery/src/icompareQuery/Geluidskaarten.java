package icompareQuery;


import java.util.ArrayList;




public class Geluidskaarten{
   
	 	static String SoundcardMerkAsus;
	    static String SoundcardMerkCreative;
	    static String SoundcardSample;
	    static String SoundcardAiso;
	    static String Soundcardopticalinput;
	  
	    static String SoundcardProcessorAsusAV100;
	    static String SoundcardProcessorAsusUS100;
	    static String SoundcardProcessorCmi8786;
	    static String SoundcardProcessorCmi8888DHT;
	    static String SoundcardProcessorSoundCore3D;
	    static String SoundcardProcessorSounndGeenvoorkeur;
	    
	    static String SoundcardSpeakerChannel;
	    static String headphonejack;
	    static String SoundcardPrijsMax;
	    static String SoundcardPrijsMin;
	    
	    
	//void = string    
	public static String getgeluidskaarten(ArrayList alle_data) {
		String merk = null;
		String sample = null;
		String input = null;
		String audioprocessor = null;
		String channel = null;
		String phonejack = null;
		String currentquery = null;
		//voeg string returnquery(v) ("query die erbij hoort");
		String returnquery1 = ("MATCH  WHERE n.category = �Geluidskaarten� AND  n.merk='" + merk + "' AND n.samplefrequentie='" + sample + "'"
							+ "AND  n.optischeingang='" + input + "' AND n.audioprocessor '"+ audioprocessor +"'AND n.speakerkanalen '"+ channel +"'AND n.hoofdtelefoonaansluiting '"+phonejack+"' "
									+ "AND toFloat(m.price) > '"+SoundcardPrijsMax+"' AND toFloat(m.price) < '"+SoundcardPrijsMin+"'RETURN n LIMIT 1");
		
		String returnquery2 = ("MATCH (n:Item) WHERE n.category = �Geluidskaarten� AND n.samplefrequentie='" + sample + "'"+ "AND  n.optischeingang='" + input + "' "
							+ "AND n.audioprocessor '"+audioprocessor +"' AND n.speakerkanalen '"+ channel +"'AND n.hoofdtelefoonaansluiting '"+phonejack+"' "
							+ "AND toFloat(m.price) > '"+SoundcardPrijsMax+"' AND toFloat(m.price) < '"+SoundcardPrijsMin+"'RETURN n LIMIT 1");
				//merk van het onderdeel
				if(alle_data.get(51) == "Asus") {
					merk = "Asus";
				
				}
				else if(alle_data.get(52) == "Creative") {
					merk = "Creative";
					
				}
				//Sample frequentie 
				if(alle_data.get(53) == "8" ) {
					sample = "8";
				}
				else if(alle_data.get(53) == "11,025") { 
					sample = "11,025";
				}
				else if(alle_data.get(53) == "16") {
					sample = "16";
				}
				else if(alle_data.get(53) == "22,05") {
					sample = "22,05";
				}
				else if(alle_data.get(53) == "24") { 
					sample = "24";
				}
				else if(alle_data.get(53) == "32") {
					sample = "32";
				}
				else if(alle_data.get(53) == "44,1") {
					sample = "44,1";
				}
				else if(alle_data.get(53) == "48") {
					sample = "48";
				}
				else if(alle_data.get(53) == "88,2") {
					sample = "88,2";
				}
				else if(alle_data.get(53) == "96") {
					sample = "96";
				}
				else if(alle_data.get(53) == "176,4") {
					sample = "176,4";
				}
				else if(alle_data.get(53) == "192") {
					sample = "192";
				}
				else if(alle_data.get(53) == "geen voorkeur") {
					sample = "96";
				}	
				//Optische ingang
				if(alle_data.get(55) == "Ja") {
					input = "Ja";
				}
				else if(alle_data.get(55) == "Nee") {
					input = "Nee";
				}	
				//Audio processor
				if(alle_data.get(56) == "Asus AV100" && alle_data.get(57) == "Asus UA100" && alle_data.get(58) == "C-Media CMI8786"&& alle_data.get(59) == "CMI8888DHT"
						&& alle_data.get(60) == "Sound Core3D" && alle_data.get(61) == "CMI8888DHT") {
					audioprocessor = "'Asus AV100' AND n.audioprocessor = 'Asus UA100' AND n.audioprocessor = 'C-Media CMI8786' AND n.audioprocessor = 'CMI8888DHT' "
							+ "AND n.audioprocessor = 'Sound Core3D' AND n.audioprocessor = 'CMI8888DHT' ";
					currentquery = "query1";
				}
				else if(alle_data.get(56) == "Asus AV100") { 
					audioprocessor = "Asus AV100";
					currentquery = "query1";
				}
				else if(alle_data.get(57) == "Asus UA100") {
					audioprocessor = "Asus UA100";
					currentquery = "query1";
				}
				else if(alle_data.get(58) == "C-Media CMI8786") {
					audioprocessor = "C-Media CMI8786";
					currentquery = "query1";
				}
				else if(alle_data.get(59) == "CMI8888DHT") {
					audioprocessor = "CMI8888DHT";
					currentquery = "query1";
				}		
				else if(alle_data.get(60) == "Sound Core3D") {
					audioprocessor = "Sound Core3D";
					currentquery = "query1";
				}
				else if(alle_data.get(61) == "Geen voorkeur") {
					audioprocessor = "CMI8888DHT";
					currentquery = "query1";
				}	
				//Speaker kanalen
				if(alle_data.get(62) == "5.1 Surround") {
					channel = "5.1 Surrounda";
				}
				else if(alle_data.get(62)== "7.1 Surround") {
					channel = "7.1 Surround";
				}	
			//Hoofdtelefoon aansluiting
				if(alle_data.get(63) == "Ja") {
					phonejack = "Ja";
				}
				else if(alle_data.get(63) == "Nee") {
					phonejack = "Nee";
				}	
	
	String query = null;
	if(currentquery == "query1") {
		query = returnquery1;
		}
	else if(currentquery == "query2") {
		query = returnquery2;
	}
	return query;
	
	}	
			
		
	}

