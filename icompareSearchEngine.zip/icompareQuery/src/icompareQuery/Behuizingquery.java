package icompareQuery;
// aff
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

// af
public class Behuizingquery {
	static String casingMerkAntec;
	   static String casingMerkCoolerMaster;
	   static String casingMerkCorsair;
	   static String casingMerkFractalDesign;
	   static String casingMerkSilverstone;
	   static String casingMerkGeenvoorkeur;

	   static String casingComputerModel;
	   static String casingfanController;
	   static String casingdustfilter;
	   static String casingsupplywatercooling;
	   static String casingLEDdisplay; 
	   static String casingnoiseReduction;
	   static String casingNoisereductionmats;
	   static String casingpanelDoor;
	   
	   static String CasingPrijsMin;
	   static String CasingPrijsMax;
	   
	   static String casingExpansionslotsMin;
	   static String casingExpansionslotsMax;
	   static String CasingMatrial;
	   static String CasingColor;
	   static String casingUsb20port0;
	   static String casingUsb20port1;
	   static String casingUsb20port2;
	   
	   static String casingUsb30port0;
	   static String casingUsb30port1;
	   static String casingUsb30port2;
	   
	   static String casingFirewireport;
	   static String casingESATAConnection;

	   static String casing25HDDSSDMin;
	   static String casing25HDDSSDMax;
	   static String casing35HDDMin;
	   static String casing35HDDMax;
	   static String casing525BayMin;
	   static String casing525BayMax;

	    
	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		
	    
	public static String getbehuizing (ArrayList alle_data) {
		String behuizingmerk = null;
		String behuizingmodel = null;
		String behuizingfan = null;
		String behuizingstof = null;
		String behuizingruisreductie = null;
		String behuizinggeluidmatten = null;
		String behuizingpaneeldeur = null;
		String behuizingkleur = null;
		String behuizingusb2 = null;
		String behuizingusb3 = null;
		String behuizingfirewire = null;
		String behuizingesata = null;
		String currentquery = null;
		String returnquery1 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = 'Behuizingen' AND n.merk = '" + behuizingmerk + "' "
							+ "AND n.computerbehuizing='" + behuizingmodel + "' AND  n.fancontroler='" + behuizingfan + "' AND n.stoffilter='" + behuizingstof + "'"
							+ " AND n.ruisreductie='"+behuizingruisreductie +"' "
							+ "AND n.geluidsdempendematten='"+behuizinggeluidmatten+"' AND n.paneeldeur='"+behuizingpaneeldeur+"' AND n.kleur='"+behuizingkleur+"' AND n.aantalusb2poorten='"+behuizingusb2+"' "
							+ "AND n.aantalusb3poorten='"+behuizingusb3+"' AND n.aantalfirewirepoorten='"+behuizingfirewire+"' AND  n.esataaansluitingen='"+behuizingesata+"' AND toFloat(m.price) > '"+CasingPrijsMax+"' "
							+ "AND toFloat(m.price) < '"+CasingPrijsMin+"' RETURN n LIMIT 1");
		String returnquery2 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = 'Behuizingen' "
							+ "AND n.computerbehuizing='" + behuizingmodel + "' AND  n.fancontroler='" + behuizingfan + "' AND n.stoffilter='" + behuizingstof + "'"
							+ " AND n.ruisreductie='"+behuizingruisreductie +"' "
							+ "AND n.geluidsdempendematten='"+behuizinggeluidmatten+"' AND n.paneeldeur='"+behuizingpaneeldeur+"' AND n.kleur='"+behuizingkleur+"' AND n.aantalusb2poorten='"+behuizingusb2+"' "
							+ "AND n.aantalusb3poorten='"+behuizingusb3+"' AND n.aantalfirewirepoorten='"+behuizingfirewire+"' AND  n.esataaansluitingen='"+behuizingesata+"' AND toFloat(m.price) > '"+CasingPrijsMax+"' "
							+ "AND toFloat(m.price) < '"+CasingPrijsMin+"' RETURN n LIMIT 1");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		
				
		// Hier wordt gekeken welke checkbox/radio is aangeklikt en wleke waarde deze bevat. Dit wordt van de website opgehaald en de waardes worden in een nieuwe variabele gezet.
				if(alle_data.get(177) == "Antec" && alle_data.get(178) == "CoolerMaster" && alle_data.get(179) == "Corsair"&& alle_data.get(180) == "FractalDesign"
						&& alle_data.get(181) == "Silverstone"&& alle_data.get(182) == "geen voorkeur") {
					behuizingmerk = "'Antec' AND n.merk = 'CoolerMaster' AND n.merk = 'Corsair'AND n.merk = 'FractalDesign' AND n.merk = 'Silverstone' "
							+ "AND n.merk = 'Corsair'";
					currentquery = "query1";
				}
				else if(alle_data.get(177) == "Antec") { 
					behuizingmerk = "Antec";
					currentquery = "query1";
				}
				else if(alle_data.get(178) == "CoolerMaster") {
					behuizingmerk = "CoolerMaster";
					currentquery = "query1";
				}
				else if(alle_data.get(179) == "Corsair") {
					behuizingmerk = "Corsair";
					currentquery = "query1";
				}
				else if(alle_data.get(180) == "FractalDesign") {
					behuizingmerk = "FractalDesign";
					currentquery = "query1";
				}
				else if(alle_data.get(181) == "Silverstone") {
					behuizingmerk = "Silverstone";
					currentquery = "query1";
				}
				else if(alle_data.get(182) == "geen voorkeur") {
					behuizingmerk = "Corsair";
					currentquery = "query1";
				}
				else if(alle_data.get(177) == null && alle_data.get(178) == null && alle_data.get(179) == null && alle_data.get(180) == null
						&& alle_data.get(181) == null && alle_data.get(182) == null ) {
					currentquery = "query2";
				}
		if(alle_data.get(183) == "Cube") {
			behuizingmodel = "Cube";
		}
		else if(alle_data.get(183) == "Full Tower") { 
			behuizingmodel = "Full Tower";
		}
		else if(alle_data.get(183) == "HTPC") {
			behuizingmodel = "HTPC";
		}
		else if(alle_data.get(183) == "Miditower") {
			behuizingmodel = "MidiITX";
		}
		else if(alle_data.get(183) == "Mini Tower") {
			behuizingmodel = "Mini Tower";
		}
		
		if(alle_data.get(184) == "Ja") {
			behuizingfan = "Ja";
		}
		else if(alle_data.get(184) == "Nee") {
			behuizingfan = "Nee";
		}
		
		if(alle_data.get(185) == "Ja") {
			behuizingstof = "Ja";
		}
		else if(alle_data.get(185) == "Nee") {
			behuizingstof = "Nee";
		}
		
		if(alle_data.get(188) == "Ja") {
			behuizingruisreductie = "Ja";
		}
		else if(alle_data.get(188) == "Nee") {
			behuizingruisreductie = "Nee";
		}
		
		if(alle_data.get(189) == "Ja") {
			behuizinggeluidmatten = "Ja";
		}
		else if(alle_data.get(189) == "Nee") {
			behuizinggeluidmatten = "Nee";
		}
		
		if(alle_data.get(190) == "Ja") {
			behuizingpaneeldeur = "Ja";
		}
		else if(alle_data.get(190) == "Nee") {
			behuizingpaneeldeur = "Nee";
		}
		
		if(alle_data.get(195) == "Grijs") {
			behuizingkleur = "Grijs";
		}
		else if(alle_data.get(195) == "Oranje") {
			behuizingkleur = "Oranje";
		}
		else if(alle_data.get(195) == "Wit") {
			behuizingkleur = "Wit";
		}
		else if(alle_data.get(195) == "Zwart") {
			behuizingkleur = "Zwart";
		}
		else if(alle_data.get(195) == "Geen Voorkeur") {
			behuizingkleur = "Zwart";
		}
		
		if(alle_data.get(197) == "0") {
			behuizingusb2 = "0";
		}
		else if(alle_data.get(198) == "1") {
			behuizingusb2 = "1";
		}
		else if(alle_data.get(199) == "2") {
			behuizingusb2 = "2";
		}

		if(alle_data.get(200) == "0") {
			behuizingusb3 = "0";
		}
		else if(alle_data.get(201) == "1") {
			behuizingusb3 = "1";
		}
		else if(alle_data.get(202) == "2") {
			behuizingusb3 = "2";
		}
		
		if(alle_data.get(203) == "0") {
			behuizingfirewire = "0";
		}
		else if(alle_data.get(203) == "1") {
			behuizingfirewire = "1";
		}
		else if(alle_data.get(203) == "Geen voorkeur") {
			behuizingfirewire = "1";
		}
		
		if(alle_data.get(204) == "0") {
			behuizingesata = "0";
		}
		else if(alle_data.get(204) == "1") {
			behuizingesata = "1";
		}
		else if(alle_data.get(204)== "Geen voorkeur") {
			behuizingesata = "1";
		}
		String query = null;
		if(currentquery == "query1") {
			query = returnquery1;
			}
		else if(currentquery == "query2") {
			query = returnquery2;
		}
		return query;
		
		
		
		
		
}
	



}
