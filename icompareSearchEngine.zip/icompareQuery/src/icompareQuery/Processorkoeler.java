package icompareQuery;

import java.util.ArrayList;

public class Processorkoeler {
	  static String ProcessorkoelerMerkBequite;
	    static String ProcessorkoelerMerkcoolermaster;
	    static String ProcessorkoelerMerkcorsair;
	    static String ProcessorkoelerMerkartic;
	    static String ProcessorkoelMerkercrucial;
	    static String ProcessorkoelerMerkingston;
	    static String ProcessorkoelerMerkscythe;
	    static String ProcessorPrijsMin;
	    static String ProcessorPrijsMax;
	    static String ProcessorKoelerMethode;
	    static String ProcessorkoelerMerkcrucial;
	
	   

	   
	public static String getprocessorquery(ArrayList alle_data) {
		String proceskoelermerk = null;
		String ProcessorKoelerMethode1 = null;
		String currentquery = null;
		String returnquery1 = ("MATCH (n:Item) WHERE n.category = �Processorkoelers� AND  n.merk='" + proceskoelermerk + "' AND n.methode='" + ProcessorKoelerMethode1 + "'"
							+ " AND m.prijs  <'" + ProcessorPrijsMax + "' AND m.prijs > '" + ProcessorPrijsMin + "' RETURN n LIMIT" );
		String returnquery2 = ("MATCH (n:Item) WHERE n.category = �Processorkoelers� AND  n.merk='" + proceskoelermerk + "' AND n.methode='" + ProcessorKoelerMethode1 + "'"
							+ " AND m.prijs  <'" + ProcessorPrijsMax + "' AND m.prijs > '" + ProcessorPrijsMin + "' RETURN n LIMIT 1");
		
	
	if(alle_data.get(18) == "BeQuite" && (alle_data.get(20) == "Corsair" && (alle_data.get(21) == "Arctic"&& (alle_data.get(22) == "Crucial"
			&& (alle_data.get(23) == "Kingston" && (alle_data.get(24) == "Scythe"  && (alle_data.get(19) == "CoolerMaster"))))))) {
	proceskoelermerk = "'BeQuite' AND n.merk = 'Corsair' AND n.merk = 'Arctic' AND n.merk = 'Crucial' "
				+ "AND n.merk = 'Kingston' AND n.merk = 'Scythe' AND n.merk = 'CoolerMaster'";
currentquery = "query1";
			}
	//merk van het onderdeel
		else if(alle_data.get(18) == "Bequiet!") { 
			proceskoelermerk = "BeQuite";
			currentquery = "query1";
				}
			else if(alle_data.get(19) == "CoolerMaster") {
				proceskoelermerk = "CoolerMaster";
				currentquery = "query1";
				}
			else if(alle_data.get(20) == "Corsair") {
				proceskoelermerk = "Corsair";
				currentquery = "query1";
				}
		else if(alle_data.get(21) == "Arctic") {
		         proceskoelermerk = "Arctic";
			currentquery = "query1";
				}
				else if(alle_data.get(22) == "Crucial") {
					proceskoelermerk = "Crucial";
					currentquery = "query1";
				}
				else if(alle_data.get(23) == "Kingston") {
					proceskoelermerk = "Kingston";
					currentquery = "query1";
				}
				else if(alle_data.get(24) == "Scythe") {
					proceskoelermerk = "Scythe";
					currentquery = "query1";
				}
				
				
			//methode	
				if(alle_data.get(27) == "Lucht") {
					ProcessorKoelerMethode1 = "Lucht";
				}
				else if(alle_data.get(27) == "Water") {
					ProcessorKoelerMethode1 = "Water";
				}

				String query = null;
				if(currentquery == "query1") {
					query = returnquery1;
					}
				else if(currentquery == "query2") {
					query = returnquery2;
				}
				return query;
}
}


