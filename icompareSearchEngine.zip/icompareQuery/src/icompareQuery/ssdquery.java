package icompareQuery;
// aff
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class ssdquery {
	//Variabelen van website
	 static String ssdstoragecapacity30gb;
	   static String ssdstoragecapacity60gb;
	   static String ssdstoragecapacity64gb;
	   static String ssdstoragecapacity80gb;
	   static String ssdstoragecapacity120gb;
	   
	   static String ssdstoragecapacity128gb;
	   static String ssdstoragecapacity180gb;
	   static String ssdstoragecapacity240gb;
	   static String ssdstoragecapacity250gb;
	   static String ssdstoragecapacity256gb;
	   
	   static String ssdstoragecapacity480gb;
	   static String ssdstoragecapacity500gb;
	   static String ssdstoragecapacity512gb;
	   static String ssdstoragecapacity960gb;
	   static String ssdstoragecapacity1tb;
	 
	   static String ssdFormaat;
	   static String ssdTypeMemory;
	   
	   static String ssdPrijsMin;
	   static String ssdPrijsMax;
	   
	   static String ssdMerkAMD;
	   static String ssdMerkCrucial;
	   static String ssdMerkIntel;
	   static String sssdMerkKingston;
	   static String ssdMerkOCZ;
	   
	   static String ssdMerkSamsung;
	   static String ssdMerkSanDisk;
	   static String sssdMerkGeenvoorkeur;
	   
	   static String ssdControllerIndilinx;
	   static String ssdControllerIntel;
	   static String ssdControllerMarvell;
	   static String ssdControllerSamsung;
	   static String ssdControllerSandForce;
	   static String ssdControllerPhison;
	   
	   static String ssdWritingSpeedMin;
	   static String ssdWritingSpeedMax;
	   
	   static String ssdReadingSpeedMin;
	   static String ssdReadingSpeedMax;

	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    
	    public static String getssdquery(ArrayList alle_data) {
		//variabelen voor in de queries
	    	String SSDopslag = null;
			String SSDmerk = null;
			String SSDformaat = null;
			String SSDsoort = null;
			String ssdleessnelheid = null;
			String ssdschrijfsnelheid = null;
			String selquery = null;
			String currentquery = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		String returnquery1 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �SolidStateDrives(SSD)� AND  n.opslagcapaciteit='" + SSDopslag + "'AND  n.merk='" + SSDmerk + "' "
							+ "AND  n.formaathardeschijf='" + SSDformaat + "'AND  n.Soortgeheugen='" + SSDsoort + "'AND n.maximaleschrijfsnelheid='"+ssdschrijfsnelheid+"'AND n.maximaleleessnelheid='"+ssdleessnelheid+"' "
							+ "AAND toFloat(m.price) > '"+ssdPrijsMax+"'AND toFloat(m.price) < '"+ssdPrijsMin+"' AND m.'"+gisteren+"' RETURN n LIMIT 1");
		String returnquery2 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �SolidStateDrives(SSD)� AND  n.opslagcapaciteit='" + SSDopslag + "' "
							+ "AND  n.formaathardeschijf='" + SSDformaat + "'AND n.maximaleschrijfsnelheid='"+ssdschrijfsnelheid+"'AND n.maximaleleessnelheid='"+ssdleessnelheid+"' "
							+ "AND toFloat(m.price) > '"+ssdPrijsMax+"'AND toFloat(m.price) < '"+ssdPrijsMin+"' AND m.'"+gisteren+"' RETURN n LIMIT 1");
		String returnquery3 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �SolidStateDrives(SSD)� AND  n.opslagcapaciteit='" + SSDopslag + "'"
							+ "AND  n.formaathardeschijf='" + SSDformaat + "'AND  n.Soortgeheugen='" + SSDsoort + "'AND n.maximaleschrijfsnelheid='"+ssdschrijfsnelheid+"'AND n.maximaleleessnelheid='"+ssdleessnelheid+"' "
							+ "AND toFloat(m.price) > '"+ssdPrijsMax+"'AND toFloat(m.price) < '"+ssdPrijsMin+"' AND m.'"+gisteren+"' RETURN n LIMIT 1");
		String returnquery4 =("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �SolidStateDrives(SSD)� AND  n.opslagcapaciteit='" + SSDopslag + "'AND  n.merk='" + SSDmerk + "' "
							+ "AND  n.formaathardeschijf='" + SSDformaat + "'AND n.maximaleschrijfsnelheid='"+ssdschrijfsnelheid+"'AND n.maximaleleessnelheid='"+ssdleessnelheid+"'"
							+ "AND toFloat(m.price) > '"+ssdPrijsMax+"'AND toFloat(m.price) < '"+ssdPrijsMin+"' AND m.'"+gisteren+"' RETURN n LIMIT 1");
		if (selquery == "Q1" && selquery == "Q3" )
				{
					currentquery = "query1";
				}
				else if (selquery == "Q1" && selquery == "Q4" )
				{
					currentquery = "query4";
				}
				else if (selquery == "Q2" && selquery == "Q3" )
				{
					currentquery = "query3";
				}
				else if (selquery == "Q2" && selquery == "Q4" )
				{
					currentquery = "query2";
				}
				
				// Hier wordt gekeken welke checkbox/radio is aangeklikt en wleke waarde deze bevat. Dit wordt van de website opgehaald en de waardes worden in een nieuwe variabele gezet.
		if(alle_data.get(211) == "30 GB" && (alle_data.get(212) == "60 GB" && (alle_data.get(213) == "64 GB" && (alle_data.get(214) == "80 GB"
				&& (alle_data.get(215) == "120 GB" && (alle_data.get(216) == "128GB"&& (alle_data.get(217) == "180 GB" && (alle_data.get(218) == "240 GB"
				&& (alle_data.get(219) == "250 GB" && (alle_data.get(220) == "256 GB"&& (alle_data.get(221) == "480 GB" && (alle_data.get(222) == "500 GB"
				&& (alle_data.get(223) == "512 GB" && (alle_data.get(224) == "960 GB" && (alle_data.get(225) == "1 TB"))))))))))))))) {
			SSDopslag = "'30 GB' AND n.opslagcapaciteit = 'Crusial' AND n.opslagcapaciteit = '60 GB' AND n.opslagcapaciteit = '64 GB' AND n.opslagcapaciteit = '80 GB' "
					+ "AND n.opslagcapaciteit = '120 GB'AND n.opslagcapaciteit = '128 GB'AND n.opslagcapaciteit = '180 GB'AND n.opslagcapaciteit = '240 GB'"
					+ "AND n.opslagcapaciteit = '250 GB'AND n.opslagcapaciteit = '256 GB'AND n.opslagcapaciteit = '480 GB'AND n.opslagcapaciteit = '500 GB'"
					+ "AND n.opslagcapaciteit = '512 GB'AND n.opslagcapaciteit = '960 GB'AND n.opslagcapaciteit = '1 TB'";
		}
		else if(alle_data.get(211)  == "30 GB") { 
			SSDopslag = "30 GB";
		}
		else if(alle_data.get(212) == "60 GB") {
			SSDopslag = "60 GB";
		}
		else if(alle_data.get(213) == "64 GB") {
			SSDopslag = "64 GB";
		}
		else if(alle_data.get(214) == "80 GB") {
			SSDopslag = "80 GB";
		}
		else if(alle_data.get(215)== "120 GB") {
			SSDopslag = "120 GB";
		}
		else if(alle_data.get(216) == "128 GB") { 
			SSDopslag = "128 GB";
		}
		else if(alle_data.get(217) == "180 GB") {
			SSDopslag = "180 GB";
		}
		else if (alle_data.get(218)== "240 GB") {
			SSDopslag = "240 GB";
		}
		else if(alle_data.get(119) == "250 GB") {
			SSDopslag = "250 GB";
		}
		else if(alle_data.get(220)== "256 GB") {
			SSDopslag = "256 GB";
		}
		else if(alle_data.get(221) == "480 GB") { 
			SSDopslag = "480 GB";
		}
		else if(alle_data.get(222) == "500 GB") {
			SSDopslag = "500 GB";
		}
		else if(alle_data.get(223) == "512 GB") {
			SSDopslag = "512 GB";
		}
		else if(alle_data.get(224) == "960 GB") {
			SSDopslag = "960 GB";
		}
		else if(alle_data.get(225)== "1 TB") {
			SSDopslag = "1 TB";
		}
		
		if(alle_data.get(226) == "2,5 inch") {
			SSDformaat = "2,5 inch";
		}
		else if(alle_data.get(226) == "mSATA") {
			SSDformaat = "mSATA";
		}
		else if(alle_data.get(226) == "M.2") {
			SSDformaat = "M.2";
		}
		
		if(alle_data.get(227) == "Multi Level Cell") {
			SSDsoort = "Multi Level Cell";
		}
		else if(alle_data.get(227) == "Triple Level Cell") {
			SSDsoort = "Triple Level Cell";
		}
		
		
		
		
		if(alle_data.get(230) == "AMD" && alle_data.get(231) == "Crucial" && alle_data.get(232) == "Intel" 
				&& alle_data.get(233) == "Kingston"&& alle_data.get(234) == "OCZ" && alle_data.get(235) == "Samsung"
				&& alle_data.get(236) == "SanDisk"&& alle_data.get(237) == "Samsung") {
			SSDmerk = "'AMD' AND n.merk = 'Crucial' AND n.merk ='Intel'"
					+ "AND n.merk = 'Kingston'AND n.merk = 'OCZ' AND n.merk = 'Samsung'"
					+ "AND n.merk = 'SanDisk' AND n.merk = 'Samsung'  ";
			selquery = "Q1";
		}
		else if(alle_data.get(230) == "AMD") { 
			SSDmerk = "AMD";
			selquery = "Q1";
		}
		else if(alle_data.get(231) == "Crucial") {
			SSDmerk = "Crucial";
			selquery = "Q1";
		}
		else if(alle_data.get(232) == "Intel") {
			SSDmerk = "Intel";
			selquery = "Q1";
		}
		else if(alle_data.get(233) == "Kingston") {
			SSDmerk = "Kingston";
			selquery = "Q1";
		}
		else if(alle_data.get(234) == "OCZ") {
			SSDmerk = "OCZ";
			selquery = "Q1";
		}
		else if(alle_data.get(235) == "Samsung") {
			SSDmerk = "Samsung";
			selquery = "Q1";
		}
		else if(alle_data.get(236) == "SanDisk") {
			SSDmerk = "SanDisk";
			selquery = "Q1";
		}
		else if(alle_data.get(237) == "Geen voorkeur") {
			SSDmerk = "Samsung";
			selquery = "Q1";
		}
		else if(alle_data.get(231) == "chooseplease" && alle_data.get(232) == "chooseplease" && alle_data.get(233) == "chooseplease" && 
				alle_data.get(234) == "chooseplease" && alle_data.get(235) == "chooseplease" && alle_data.get(236) == "chooseplease" &&
						alle_data.get(237) == "chooseplease") { 
			selquery = "Q2";
		}

	
		if(Integer.parseInt(ssdWritingSpeedMin) < 99 && Integer.parseInt(ssdWritingSpeedMax) > 101 ) {
			ssdschrijfsnelheid = "100 MB/s";
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 119 && Integer.parseInt(ssdWritingSpeedMax) > 121) { 
			ssdschrijfsnelheid = "120 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 149 && Integer.parseInt(ssdWritingSpeedMax) > 151) { 
			ssdschrijfsnelheid = "150 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 219 && Integer.parseInt(ssdWritingSpeedMax) > 221) { 
			ssdschrijfsnelheid = "220 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 239 && Integer.parseInt(ssdWritingSpeedMax) > 241) { 
			ssdschrijfsnelheid = "240 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 249 && Integer.parseInt(ssdWritingSpeedMax) > 251) { 
			ssdschrijfsnelheid = "250 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 269 && Integer.parseInt(ssdWritingSpeedMax) > 271) { 
			ssdschrijfsnelheid = "270 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 329 && Integer.parseInt(ssdWritingSpeedMax) > 331) { 
			ssdschrijfsnelheid = "330 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 339 && Integer.parseInt(ssdWritingSpeedMax) > 341) { 
			ssdschrijfsnelheid = "340 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 349 && Integer.parseInt(ssdWritingSpeedMax) > 351) { 
			ssdschrijfsnelheid = "350 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 394 && Integer.parseInt(ssdWritingSpeedMax) > 396) { 
			ssdschrijfsnelheid = "395 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 399 && Integer.parseInt(ssdWritingSpeedMax) > 401) { 
			ssdschrijfsnelheid = "400 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 419 && Integer.parseInt(ssdWritingSpeedMax) > 421) { 
			ssdschrijfsnelheid = "420 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 429 && Integer.parseInt(ssdWritingSpeedMax) > 431) { 
			ssdschrijfsnelheid = "430 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 449 && Integer.parseInt(ssdWritingSpeedMax) > 451) { 
			ssdschrijfsnelheid = "450 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 469 && Integer.parseInt(ssdWritingSpeedMax) > 471) { 
			ssdschrijfsnelheid = "470 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 479 && Integer.parseInt(ssdWritingSpeedMax) > 481) { 
			ssdschrijfsnelheid = "480 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 489 && Integer.parseInt(ssdWritingSpeedMax) > 491) { 
			ssdschrijfsnelheid = "490 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 499 && Integer.parseInt(ssdWritingSpeedMax) > 501) { 
			ssdschrijfsnelheid = "500 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 509 && Integer.parseInt(ssdWritingSpeedMax) > 511) { 
			ssdschrijfsnelheid = "510 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 511 && Integer.parseInt(ssdWritingSpeedMax) > 513) { 
			ssdschrijfsnelheid = "512 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 519 && Integer.parseInt(ssdWritingSpeedMax) > 521) { 
			ssdschrijfsnelheid = "520 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 524 && Integer.parseInt(ssdWritingSpeedMax) > 526) { 
			ssdschrijfsnelheid = "525 MB/s";	
		}else if(Integer.parseInt(ssdWritingSpeedMin) < 529 && Integer.parseInt(ssdWritingSpeedMax) > 531) { 
			ssdschrijfsnelheid = "530 MB/s";	
		}
		
		if(Integer.parseInt(ssdReadingSpeedMin) < 419 && Integer.parseInt(ssdReadingSpeedMax) > 421 ) {
			ssdleessnelheid = "420 MB/s";
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 449 && Integer.parseInt(ssdReadingSpeedMax) > 451) { 
			ssdleessnelheid = "450 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 469 && Integer.parseInt(ssdReadingSpeedMax) > 471) { 
			ssdleessnelheid = "470 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 474 && Integer.parseInt(ssdReadingSpeedMax) > 476) { 
			ssdleessnelheid = "475 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 479 && Integer.parseInt(ssdReadingSpeedMax) > 481) { 
			ssdleessnelheid = "480 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 489 && Integer.parseInt(ssdReadingSpeedMax) > 491) { 
			ssdleessnelheid = "490 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 499 && Integer.parseInt(ssdReadingSpeedMax) > 501) { 
			ssdleessnelheid = "500 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 524 && Integer.parseInt(ssdReadingSpeedMax) > 526) { 
			ssdleessnelheid = "525 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 529 && Integer.parseInt(ssdReadingSpeedMax) > 531) { 
			ssdleessnelheid = "530 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 544 && Integer.parseInt(ssdReadingSpeedMax) > 546) { 
			ssdleessnelheid = "545 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 549 && Integer.parseInt(ssdReadingSpeedMax) > 551) { 
			ssdleessnelheid = "550 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 553 && Integer.parseInt(ssdReadingSpeedMax) > 555) { 
			ssdleessnelheid = "554 MB/s";	
		}else if(Integer.parseInt(ssdReadingSpeedMin) < 554 && Integer.parseInt(ssdReadingSpeedMax) > 556) { 
			ssdleessnelheid = "555 MB/s";	
	}
		String query = null;
		if(currentquery == "query1") {
			query = returnquery1;
			}
		else if(currentquery == "query2") {
			query = returnquery2;
		}
		else if(currentquery == "query3") {
			query = returnquery3;
		}
		else if(currentquery == "query4") {
			query = returnquery4;
		}
		return query;
		
		
	}
}

