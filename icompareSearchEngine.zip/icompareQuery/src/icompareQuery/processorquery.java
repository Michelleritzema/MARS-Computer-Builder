package icompareQuery;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;




public class processorquery {
	 static String ProcessorMerkIntel;
	   static String ProcessorMerkAMD;
	  
	   static String ProcessorcoresDualcore;
	   static String ProcessorcoresQuadcore;
	   static String Processorcores6core;
	   static String Processorcores8core;
	   
	   static String ProcessorPPrijsMin;
	   static String ProcessorPPrijsMax;
	    
	   static String ProcessorSerieA10;
	   static String ProcessorSerieA6;
	   static String ProcessorSerieA8;
	   static String ProcessorSeriecorei3;
	   static String ProcessorSeriecorei5;
	   static String ProcessorSeriecorei7;
	   static String ProcessorSerieFX;
	   static String ProcessorSeriepentium;
	   static String ProcessorSeriesempron;
	   
	   static String ProcessorclockingMin;
	   static String ProcessorclockingMax;
	

	  
	    static DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	    
	public static String getprocessorquery(ArrayList alle_data) {
		String procescores = null;
		String procesmerk = null;
		String processerie = null;
		String currentquery = null;
		String proceskloksnelheid = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String gisteren = dateFormat.format(cal.getTime());
		
		String returnquery1 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Processor� AND  n.merk='" + procesmerk + "' AND n.serie='" + processerie + "'"
							+ "AND  n.processorkernen='" + procescores + "'AND toFloat(m.price) > '"+ProcessorPPrijsMax+"'AND toFloat(m.price) < '"+ProcessorPPrijsMin+"' "
									+ "AND n.kloksnelheid  ='" + proceskloksnelheid + "' AND m.gisteren RETURN n LIMIT 1");
	
        String returnquery2 = ("MATCH (n:Item)-[r]-(m:Price) WHERE n.category = �Processor�AND n.serie='" + processerie + "'"+ "AND  n.processorkernen='" + procescores + "' "
							+ "AND toFloat(m.price) > '"+ProcessorPPrijsMax+"'AND toFloat(m.price) < '"+ProcessorPPrijsMin+"'"
								+ "AND n.kloksnelheid ='" + proceskloksnelheid + "' AND m.gisteren RETURN n LIMIT 1");

		
	
		if(alle_data.get(111) == "Intel" && alle_data.get(112) == "AMD") {
			procesmerk = "'Intel' AND n.merk = 'AMD' ";
			currentquery = "query1";
		}
		else if(alle_data.get(111) == "Intel") { 
			procesmerk = "Intel";
			currentquery = "query1";
		}
		else if(alle_data.get(112) == "AMD") {
			procesmerk = "AMD";
			currentquery = "query1";
		}
		else if(alle_data.get(111) == null && alle_data.get(112) == null) { 
			currentquery = "query2";
		}
		
		if(alle_data.get(113) == "Dual core" && alle_data.get(114) == "Quad core" 
				&& alle_data.get(115) == "6-core" && alle_data.get(116) == "8-core") {
			procescores = "'Dual core' AND n.processorkernen = 'Quad core' AND n.processorkernen ='6-core' AND n.processorkernen = '8-core'  ";
		}
		else if(alle_data.get(113) == "Dual core") { 
			procescores = "Dual core";
		}
		else if(alle_data.get(114) == "Quad core") {
			procescores = "Quad core";
		}
		else if(alle_data.get(115) == "6-core") {
			procescores = "6-core";
		}
		else if(alle_data.get(116) == "8-core") {
			procescores = "8-core";
		}
		
	
		if(alle_data.get(119) == "A10" && alle_data.get(120) == "A6" && alle_data.get(121) == "A8" && alle_data.get(122) == "Core i3"
				&& alle_data.get(123) == "Core i5" && alle_data.get(124) == "Core i7" && alle_data.get(125) == "FX"
				&& alle_data.get(126) == "pentium" && alle_data.get(127) == "sempron") {
			processerie = "'A10' AND n.cores = 'A6' AND n.cores ='A8' AND n.cores = 'Core i3'AND n.cores = 'Core i5'AND n.cores = 'Core i7'AND n.cores = 'FX'AND n.cores = 'pentium'AND n.cores = 'sempron'  ";
		}
		else if(alle_data.get(119) == "A10") { 
			processerie = "A10";
		}
		else if(alle_data.get(120) == "A6") { 
			processerie = "A6";
		}
		else if(alle_data.get(121) == "A8") { 
			processerie = "A8";
		}
		else if(alle_data.get(122) == "Core i3") { 
			processerie = "Core i3";
		}
		else if(alle_data.get(123) == "Core i5") { 
			processerie = "Core i5";
		}
		else if(alle_data.get(124) == "Core i7") { 
			processerie = "Core i7";
		}
		else if(alle_data.get(125) == "FX") { 
			processerie = "FX";
		}
		else if(alle_data.get(126) == "pentium") { 
			processerie = "pentium";
		}
		else if(alle_data.get(127) == "sempron") { 
			processerie = "senmpron";
		}
		
			if(Integer.parseInt(ProcessorclockingMin) < 2899 && Integer.parseInt(ProcessorclockingMax) > 2901 ) {
				proceskloksnelheid = "2900 Mhz";
			}else if(Integer.parseInt(ProcessorclockingMin) < 3049 && Integer.parseInt(ProcessorclockingMax)  > 3051) { 
				proceskloksnelheid = "3050 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 3199 && Integer.parseInt(ProcessorclockingMax)  > 3201) { 
				proceskloksnelheid = "3200 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 3349 && Integer.parseInt(ProcessorclockingMax)  > 3351) { 
				proceskloksnelheid = "3350 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 3499 && Integer.parseInt(ProcessorclockingMax)  > 3501) { 
				proceskloksnelheid = "3500 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 3599 && Integer.parseInt(ProcessorclockingMax)  > 3601) { 
				proceskloksnelheid = "3600 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 3799 && Integer.parseInt(ProcessorclockingMax)  > 3801) { 
				proceskloksnelheid = "3800 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 3949 && Integer.parseInt(ProcessorclockingMax)  > 3951) { 
				proceskloksnelheid = "3950 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 4099 && Integer.parseInt(ProcessorclockingMax)  > 4101) { 
				proceskloksnelheid = "4100 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 4249 && Integer.parseInt(ProcessorclockingMax)  > 4251) { 
				proceskloksnelheid = "4250 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 4399 && Integer.parseInt(ProcessorclockingMax)  > 4401) { 
				proceskloksnelheid = "4400 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 4449 && Integer.parseInt(ProcessorclockingMax)  > 3351) { 
				proceskloksnelheid = "4450 Mhz";	
			}else if(Integer.parseInt(ProcessorclockingMin) < 4699 && Integer.parseInt(ProcessorclockingMax)  > 4701) {
				proceskloksnelheid = "4700 Mhz";
			}
			String query = null;
			if(currentquery == "query1") {
				query = returnquery1;
				}
			else if(currentquery == "query2") {
				query = returnquery2;
			}
			return query;
			
			}	
			
	}	

			
		
	

