package icompareQuery;

import java.util.ArrayList;

public class Translate {

	
	static String string = "";
    static char temp;
    
    static ArrayList<String> alle_data = new ArrayList<String>();
    
    static String cpu_p4;
    static String cpu_p8;
    static String cpu_p4p4;
    static String modulair; 
    static String Certificering;
    static String bequiet;
    static String CoolerMarster;
    static String Corsair;
    static String Seasonic;
    static String XFX;
    static String pciexpress6pin;
    static String pciexpress6PPpin;
    static String VoedingPrijsMin;
    static String VoedingPrijsMax;
    static String VoedingVermogenMin;
    static String VoedingVermogenMax;
    static String VoedingSATAaansluitingMin;
    static String VoedingSATAaansluitingMax;
  
    // processoren 
    static String ProcessorkoelerMerkBequite;
    static String ProcessorkoelerMerkcoolermaster;
    static String ProcessorkoelerMerkcorsair;
    static String ProcessorkoelerMerkartic;
    static String ProcessorkoelMerkercrucial;
    static String ProcessorkoelerMerkingston;
    static String ProcessorkoelerMerkscythe;
    static String ProcessorPrijsMin;
    static String ProcessorPrijsMax;
    static String ProcessorKoelerMethode;
    static String ProcessorkoelerMerkcrucial;
    static String ProcessorDiamter;
    static String ProcessorCoolerRSpeedMax;
    static String ProcessorCoolerRSpeedMin;
    
    // interne harde schijf 
    
    static String HarddriveMerkLacie;
    static String HarddriveMerkSeagate;
    static String HarddriveMerToshiba;
    static String HarddriveMerWesternDigital;
    
    static String HarddriveFormaat; 
    static String Harddrivestoragecapacity160gb;
    static String Harddrivestoragecapacity320gb;
    static String Harddrivestoragecapacity500gb;
    static String Harddrivestoragecapacity750gb;
    static String Harddrivestoragecapacity1tb;
    static String Harddrivestoragecapacity2tb;
    static String Harddrivestoragecapacity3tb;
    static String Harddrivestoragecapacity4tb;
    static String Harddrivestoragecapacity5tb;
    static String Harddrivestoragecapacity6tb;
    static String Harddriveconnection;
    static String HarddriveBuffer;
    static String HarddriveSpeed;
    static String HarddrivePriceMin;
    static String HarddrivePriceMax;
    
    static String SoundcardMerkAsus;
    static String SoundcardMerkCreative;
    static String SoundcardSample;
    static String SoundcardAiso;
    static String Soundcardopticalinput;
  
    static String SoundcardProcessorAsusAV100;
    static String SoundcardProcessorAsusUS100;
    static String SoundcardProcessorCmi8786;
    static String SoundcardProcessorCmi8888DHT;
    static String SoundcardProcessorSoundCore3D;
    static String SoundcardProcessorSounndGeenvoorkeur;
    static String SoundcardSpeakerChannel;
    static String headphonejack;
    static String mmminijack;
    static String SoundcardPrijsMax;
    static String SoundcardPrijsMin;
    
    //pci 
    static String PciUsb;
    static String PciFirewire;
    static String PciSataConnection;
    static String PciESataConnection;
    static String PciPrijsMin;
    static String PciPrijsMax;
    
        
   static String VideocardmanufacturerNvida;
   static String VideocardAmdAMDRadeonR9270X;
   static String VideocardAmdAMDRadeonR7240;
   static String VideocardAmdAMDRadeonR9280;
   static String VideocardAmdAMDRadeonR9290;
   static String VideocardAmdAMDRadeonR7250;
   static String VideocardAmdAMDRadeonR9270;
   static String VideocardAmdAMDRadeonHD6450;
   static String VideocardAmdAMDRadeonR9280X;
   static String VideocardAmdAMDRadeonR9290X;
   static String VideocardAmdAMDRadeonHD3450AGP;
    
   // nvidia
   static String VideocardmanufacturerAmd;
   static String VideocardnvidiaNVIDIAFX5500;
   static String VideocardnvidiaNVIDIAGeForceGTX980;
   static String VideocardnvidiaNVIDIAGeForceGT730;
   static String VideocardnvidiaNVIDIAGeForceGTX750;
   static String VideocardnvidiaNVIDIAGeForceGT740;
   static String VideocardnvidiaNVIDIAGeForceGTX780;
   static String VideocardnvidiaNVIDIAGeForceGTX970;
   static String VideocardnvidiaNVIDIAGeForceGTX660;
   static String VideocardnvidiaNVIDIAGeForceGTX760;
   static String VideocardnvidiaNVIDIAGeForceGTX770;
   
   static String VideocardMerkAsus;
   static String VideocardMerkClub3d;
   static String VideocardMerkGigabyte;
   static String VideocardMerkSapphire;
   static String VideocardMerkMSI;
   static String VideocardMerkGeenvoorkeur;
   
   static String VideocardTyeMemory;
   static String VideocardHdmi;
   static String VideocardVga;
   static String VideocardMemorybus;
   static String VideocardDVIIConnection;
   static String VideocardDVIDConnection;
   static String VideocardPrijsMin;
   static String VideocardPrijsMax;
   static String VideocardMemorryMBMin;
   static String VideocardMemorryMBMax;
    
    
	  
   static String ProcessorMerkIntel;
   static String ProcessorMerkAMD;
   static String ProcessorcoresDualcore;
   static String ProcessorcoresQuadcore;
   static String Processorcores6core;
   static String Processorcores8core;
   static String ProcessorPPrijsMin;
   static String ProcessorPPrijsMax;
   static String ProcessorSerieA10;
   static String ProcessorSerieA6;
   static String ProcessorSerieA8;
   static String ProcessorSeriecorei3;
   static String ProcessorSeriecorei5;
   static String ProcessorSeriecorei7;
   static String ProcessorSerieFX;
   static String ProcessorSeriepentium;
   static String ProcessorSeriesempron;
   static String ProcessorclockingMin;
   static String ProcessorclockingMax;
   
   static String internalmemoryCorsair;
   static String internalmemoryCrusial;
   static String internalmemorykingston;
   static String internalmemoryqnap;
   static String internalmemorysynology;
   static String internalmemorygeenvoorkeur;
   
   static String internalmemoryRAM1GB;
   static String internalmemoryRAM2GB;
   static String internalmemoryRAM4GB;
   static String internalmemoryRAM8GB;
   static String internalmemoryRAM16GB;
   static String internalmemoryRAM32GB;
   static String internalmemoryclocking;
   static String internalmemoryGaming;
   
   static String internalmemorysuitableforDesktop;
   static String internalmemorysuitableforLaptop;
   static String internalmemorysuitableforNas;
   static String internalmemorysuitableforMac;
   static String internalmemoryType;
   static String internalmemoryChannel;
   static String internalmemoryPrijsMin;
   static String internalmemoryPrijsMax;

   // moederbord
   static String motherboardMerkAsrock;
   static String motherboardMerkAsus;
   static String motherboardMerkMSI;
   static String motherboardformaat;
   static String motherboardWifi;
   static String motherboardmemoryslots;
   static String motherboardHDMI;
   static String motherboardVga;
   static String motherboardDisplayport;
   static String motherboardPrijsMin;
   static String motherboardPrijsMax;
   static String motherboardUsbPort;
   static String motherboardEthernetport;
   static String motherboardDVI;
   static String motherboardRAID0;
   static String motherboardRAID1;
   static String motherboardRAID5;
   static String motherboardRAID10;
   static String motherboardJBOD;
   static String motherboardGeen;
   static String motherboardAudiChannel;
   static String motherboardMemorytype;
   static String motherboardmSATAConnection;
   static String motherboardmSATA300Connection;
   static String motherboardmSATA600Connection;
   
 //casing  
   static String casingMerkAntec;
   static String casingMerkCoolerMaster;
   static String casingMerkCorsair;
   static String casingMerkFractalDesign;
   static String casingMerkSilverstone;
   static String casingMerGeenvoorkeur;

   static String casingComputerModel;
   static String casingfanController;
   static String casingdustfilter;
   static String casingsupplywatercooling;
   static String casingLEDdisplay; 
   static String casingnoiseReduction;
   static String casingNoisereductionmats;
   static String casingpanelDoor;
   
   static String CasingPrijsMin;
   static String CasingPrijsMax;
   
   static String casingExpansionslotsMin;
   static String casingExpansionslotsMax;
   static String CasingMatrial;
   static String CasingColor;
   static String casingUsb20port0;
   static String casingUsb20port1;
   static String casingUsb20port2;
   
   static String casingUsb30port0;
   static String casingUsb30port1;
   static String casingUsb30port2;
   
   static String casingFirewireport;
   static String casingESATAConnection;

   static String casing25HDDSSDMin;
   static String casing25HDDSSDMax;
   static String casing35HDDMin;
   static String casing35HDDMax;
   static String casing525BatyMin;
   static String casing525BatyMax;
   // ssd
   static String ssdstoragecapacity30gb;
   static String ssdstoragecapacity60gb;
   static String ssdstoragecapacity64gb;
   static String ssdstoragecapacity80gb;
   static String ssdstoragecapacity120gb;
   
   static String ssdstoragecapacity128gb;
   static String ssdstoragecapacity180gb;
   static String ssdstoragecapacity240gb;
   static String ssdstoragecapacity250gb;
   static String ssdstoragecapacity256gb;
   
   static String ssdstoragecapacity480gb;
   static String ssdstoragecapacity500gb;
   static String ssdstoragecapacity512gb;
   static String ssdstoragecapacity960gb;
   static String ssdstoragecapacity1tb;
 
   static String ssdFormaat;
   static String ssdTypeMemory;
   
   static String ssdPrijsMin;
   static String ssdPrijsMax;
   
   static String ssdMerkAMD;
   static String ssdMerkCrucial;
   static String ssdMerkIntel;
   static String sssdMerkKingston;
   static String ssdMerkOCZ;
   
   static String ssdMerkSamsung;
   static String ssdMerkSanDisk;
   static String sssdMerkGeenvoorkeur;
   
   static String ssdControllerIndilinx;
   static String ssdControllerIntel;
   static String ssdControllerMarvell;
   static String ssdControllerSamsung;
   static String ssdControllerSandForce;
   static String ssdControllerPhison;
   
   static String ssdWritingSpeedMin;
   static String ssdWritingSpeedMax;
   
   static String ssdReadingSpeedMin;
   static String ssdReadingSpeedMax;
   
// Blu-Ray & DVD
   static String BluRayDVDMerkAsus;
   static String BluRayDVDMerkFreecom;
   static String BluRayDVDMerkApple;
   static String BluRayDVDMerkLG;
   static String BluRayDVDMerkSamsung;
   static String BluRayDVDMerkGeenvoorkeur;
   
   static String BluRayDVDDriverType; 
   static String BluRayDVDPrijsmin;
   static String BluRayDVDPrijsmax;
   
   static String BluRayDVDPlaysDiscBluray;
   static String BluRayDVDPlaysDiscDVD;
   static String BluRayDVDPlaysDiscCD;
   static String BluRayDVDPlaysDiscFloppy;
   static String BluRayDVDOperatingSystem;
   static String BluRayDVDtypetray;
    
   public static ArrayList translateAll(String clientSentence) {
		// TODO Auto-generated method stub
		
  
    
		string = clientSentence;
		
		
		cpu_p4();
        System.out.print(cpu_p4+ "\n");
        cpu_p8();
        System.out.print(cpu_p8+ "\n");
        cpu_p4p4();
        System.out.print(cpu_p4p4+ "\n");
        modulair();
        System.out.print(modulair+ "\n");
        Certificering();
        System.out.print(Certificering+ "\n");
        bequiet();
        System.out.print(bequiet+ "\n");
        CoolerMarster();
        System.out.print(CoolerMarster+ "\n");
        Corsair();
        System.out.print(Corsair + "\n");
        Seasonic();
        System.out.print(Seasonic + "\n");
        XFX();
        System.out.print(XFX+ "\n");
        pciexpress6pin();
        System.out.print(pciexpress6pin + "\n");
        pciexpress6PPpin();
        System.out.print(pciexpress6PPpin + "\n");
        VoedingPrijsMin();
        System.out.print(VoedingPrijsMin + "\n");
        VoedingPrijsMax();
        System.out.print(VoedingPrijsMax + "\n");
        VoedingVermogenMin();
        System.out.print(VoedingVermogenMin+ "\n");
        VoedingVermogenMax();
        System.out.print(VoedingVermogenMax+ "\n");
        VoedingSATAaansluitingMin();
        System.out.print(VoedingSATAaansluitingMin+ "\n");
        VoedingSATAaansluitingMax();
        System.out.print(VoedingSATAaansluitingMax + "\n");
      
        // processorkoeler
        ProcessorkoelerMerkBequite();    
        System.out.print(ProcessorkoelerMerkBequite+ "\n");
        ProcessorkoelerMerkcoolermaster();
        System.out.print(ProcessorkoelerMerkcoolermaster+ "\n");
        ProcessorkoelerMerkcorsair();
        System.out.print(ProcessorkoelerMerkcorsair+ "\n");
        ProcessorkoelerMerkartic();
        System.out.print(ProcessorkoelerMerkartic+ "\n");
        ProcessorkoelerMerkcrucial();
        System.out.print(ProcessorkoelerMerkcrucial+ "\n");
        ProcessorkoelerMerkingston();
        System.out.print(ProcessorkoelerMerkingston + "\n");
        ProcessorkoelerMerkscythe();
        System.out.print(ProcessorkoelerMerkscythe+ "\n");
        ProcessorPrijsMin();
        System.out.print(ProcessorPrijsMin+ "\n");
        ProcessorPrijsMax();
        System.out.print(ProcessorPrijsMax+ "\n");
        ProcessorKoelerMethode();
        System.out.print(ProcessorKoelerMethode+ "\n");
        ProcessorDiamter();
        System.out.print(ProcessorDiamter+ "\n");
        ProcessorCoolerRSpeedMin();
        System.out.print(ProcessorCoolerRSpeedMin+ "\n");
        ProcessorCoolerRSpeedMax();
        System.out.print(ProcessorCoolerRSpeedMax+ "\n");
        
        // harde schijf
        HarddriveMerkLacie();
        System.out.print(HarddriveMerkLacie +"\n");
        HarddriveMerkSeagate();
        System.out.print(HarddriveMerkSeagate +"\n");
        HarddriveMerToshiba();
        System.out.print(HarddriveMerToshiba +"\n");
        HarddriveMerWesternDigital();
        System.out.print(HarddriveMerWesternDigital +"\n");
        
        HarddriveFormaat(); 
        System.out.print(HarddriveFormaat +"\n");
        Harddrivestoragecapacity160gb();
        System.out.print(Harddrivestoragecapacity160gb +"\n");
        Harddrivestoragecapacity320gb();
        System.out.print(Harddrivestoragecapacity320gb +"\n");
        Harddrivestoragecapacity500gb();                                   
        System.out.print(Harddrivestoragecapacity500gb +"\n");
        Harddrivestoragecapacity750gb();
        System.out.print(Harddrivestoragecapacity750gb +"\n");
        Harddrivestoragecapacity1tb();
        System.out.print(Harddrivestoragecapacity1tb +"\n");
        Harddrivestoragecapacity2tb();
        System.out.print(Harddrivestoragecapacity2tb +"\n");
        Harddrivestoragecapacity3tb();
        System.out.print(Harddrivestoragecapacity3tb +"\n");
        Harddrivestoragecapacity4tb();
        System.out.print(Harddrivestoragecapacity4tb +"\n");
        Harddrivestoragecapacity5tb();
        System.out.print(Harddrivestoragecapacity5tb +"\n");
        Harddrivestoragecapacity6tb();
        System.out.print(Harddrivestoragecapacity6tb +"\n");
        
        Harddriveconnection();
        System.out.print(Harddriveconnection +"\n");
        HarddriveBuffer();
        System.out.print(HarddriveBuffer +"\n");
        HarddriveSpeed();
        System.out.print(HarddriveSpeed +"\n");
        HarddrivePriceMin();
        System.out.print(HarddrivePriceMin +"\n");
        HarddrivePriceMax();
        System.out.print(HarddrivePriceMax +"\n");
	
        
        // Geluidskaart
        SoundcardMerkAsus();
        System.out.print(SoundcardMerkAsus +"\n");
        SoundcardMerkCreative();
        System.out.print(SoundcardMerkCreative +"\n");
        SoundcardSample();
	    System.out.print(SoundcardSample +"\n");
	    SoundcardAiso();
	    System.out.print(SoundcardAiso +"\n");
	    Soundcardopticalinput();
	    System.out.print(Soundcardopticalinput +"\n");
	    SoundcardProcessorAsusAV100();
	    System.out.print(SoundcardProcessorAsusAV100 +"\n");
	    SoundcardProcessorCmi8786();
	    System.out.print(SoundcardProcessorCmi8786 +"\n"); 
	    SoundcardProcessorCmi8888DHT();
	    System.out.print(SoundcardProcessorCmi8888DHT +"\n");	   
	    SoundcardProcessorSoundCore3D();
	    System.out.print(SoundcardProcessorSoundCore3D +"\n");
	    SoundcardProcessorSounndGeenvoorkeur();
	    System.out.print(SoundcardProcessorSounndGeenvoorkeur +"\n");
	    SoundcardSpeakerChannel();
	    System.out.print(SoundcardSpeakerChannel +"\n");
	 	headphonejack();
	    System.out.print(headphonejack +"\n");
	 	mmminijack();
	    System.out.print(mmminijack +"\n");	
	    SoundcardPrijsMin();
	    System.out.print(SoundcardPrijsMin +"\n");
	    SoundcardPrijsMax();
	    System.out.print(SoundcardPrijsMax +"\n");

	  
	   // pci 
	    PciUsb();
	    System.out.print(PciUsb +"\n");
	    PciFirewire();
	    System.out.print(PciFirewire +"\n");	
	    PciSataConnection();
	    System.out.print(PciSataConnection +"\n" );	    
	    PciESataConnection();
	    System.out.print(PciESataConnection +"\n" );
	    PciPrijsMin();
	    System.out.print(PciPrijsMin +"\n");
	    PciPrijsMax();
	    System.out.print(PciPrijsMax +"\n");
	    
	    // videokaart
	    VideocardmanufacturerNvida();
		System.out.print(VideocardmanufacturerNvida +"\n"); 
	    VideocardmanufacturerAmd();
		System.out.print(VideocardmanufacturerAmd +"\n");
		 
		
	
		VideocardAmdAMDRadeonR9270X();
		System.out.print(VideocardAmdAMDRadeonR9270X +"\n"); 
		VideocardAmdAMDRadeonR9270();
		System.out.print(VideocardAmdAMDRadeonR9270 +"\n");      
		VideocardAmdAMDRadeonR7240();
		System.out.print(VideocardAmdAMDRadeonR7240 +"\n");  
		VideocardAmdAMDRadeonHD6450();
		System.out.print(VideocardAmdAMDRadeonHD6450 +"\n"); 
		VideocardAmdAMDRadeonR9280();
		System.out.print(VideocardAmdAMDRadeonR9280 +"\n"); 
		VideocardAmdAMDRadeonR9280X();
		System.out.print(VideocardAmdAMDRadeonR9280X +"\n"); 
		VideocardAmdAMDRadeonR9290();
		System.out.print(VideocardAmdAMDRadeonR9290 +"\n"); 
		VideocardAmdAMDRadeonR9290X();
		System.out.print(VideocardAmdAMDRadeonR9280X +"\n");  
		VideocardAmdAMDRadeonR7250();
		System.out.print(VideocardAmdAMDRadeonR7250 +"\n");
		VideocardAmdAMDRadeonHD3450AGP();
		System.out.print(VideocardAmdAMDRadeonHD3450AGP +"\n"); 
		VideocardnvidiaNVIDIAFX5500();
		System.out.print(VideocardnvidiaNVIDIAFX5500 +"\n"); 
		VideocardnvidiaNVIDIAGeForceGTX780();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX780 +"\n"); 		  
		VideocardnvidiaNVIDIAGeForceGTX980();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX980 +"\n");
		VideocardnvidiaNVIDIAGeForceGTX970();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX970 +"\n");  
		VideocardnvidiaNVIDIAGeForceGT730();
		System.out.print(VideocardnvidiaNVIDIAGeForceGT730 +"\n"); 
		VideocardnvidiaNVIDIAGeForceGTX660();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX660 +"\n"); 
		VideocardnvidiaNVIDIAGeForceGTX750();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX750 +"\n"); 
		VideocardnvidiaNVIDIAGeForceGTX760();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX760 +"\n"); 
		VideocardnvidiaNVIDIAGeForceGT740();
		System.out.print(VideocardnvidiaNVIDIAGeForceGT740 +"\n"); 
		VideocardnvidiaNVIDIAGeForceGTX770();
		System.out.print(VideocardnvidiaNVIDIAGeForceGTX770 +"\n"); 
		VideocardMerkAsus();
	    System.out.print(VideocardMerkAsus +"\n"); 
		VideocardMerkClub3d();
		System.out.print(VideocardMerkClub3d +"\n"); 
		VideocardMerkGigabyte();
		System.out.print(VideocardMerkGigabyte +"\n"); 
		VideocardMerkSapphire();
		System.out.print(VideocardMerkSapphire +"\n"); 
	    VideocardMerkMSI();
		System.out.print(VideocardMerkMSI +"\n");
		VideocardMerkGeenvoorkeur();   
		System.out.print(VideocardMerkGeenvoorkeur +"\n"); 
		VideocardTyeMemory();
		System.out.print(VideocardTyeMemory +"\n"); 
	    VideocardHdmi();
		System.out.print(VideocardHdmi +"\n"); 
		VideocardVga();
		System.out.print(VideocardVga +"\n"); 
		VideocardMemorybus();
		System.out.print(VideocardMemorybus +"\n"); 
		VideocardDVIIConnection();
		System.out.print(VideocardDVIIConnection +"\n"); 
		VideocardDVIDConnection();
		System.out.print(VideocardDVIDConnection +"\n"); 
		VideocardPrijsMin();
		System.out.print(VideocardPrijsMin +"\n"); 
		VideocardPrijsMax();
		System.out.print(VideocardPrijsMax +"\n"); 
	    VideocardMemorryMBMin();
		System.out.print(VideocardMemorryMBMin +"\n"); 
		VideocardMemorryMBMax();
		System.out.print(VideocardMemorryMBMax +"\n"); 
		  

	
		  
		  
		  // processor 
		   ProcessorMerkIntel();
		   System.out.print(ProcessorMerkIntel + "\n");  
			  
		   ProcessorMerkAMD();
		   System.out.print(ProcessorMerkAMD +"\n");  
		  
		  
		   ProcessorcoresDualcore();
		   System.out.print(ProcessorcoresDualcore +"\n");  
			  
		   ProcessorcoresQuadcore();
		   System.out.print(ProcessorcoresQuadcore +"\n");  
			  
		   Processorcores6core();
		   System.out.print(Processorcores6core +"\n");  
			  
		   Processorcores8core();
		   System.out.print(Processorcores8core +"\n");  
		  
		   
		   ProcessorPPrijsMin();
		   System.out.print(ProcessorPPrijsMin +"\n");  
			  
		   ProcessorPPrijsMax();
		   System.out.print(ProcessorPPrijsMax +"\n");  
			  
		    
		   ProcessorSerieA10();
		   System.out.print(ProcessorSerieA10 +"\n" );  
			  
		   ProcessorSerieA6();
		   System.out.print(ProcessorSerieA6 +"\n");  
		  
		   ProcessorSerieA8();
		   System.out.print(ProcessorSerieA8 +"\n");  
		   
		   ProcessorSeriecorei3();
		   System.out.print(ProcessorSeriecorei3 +"\n");  
		  
		   ProcessorSeriecorei5();
		   System.out.print(ProcessorSeriecorei5 +"\n");  
			  
		   ProcessorSeriecorei7();
		   System.out.print(ProcessorSeriecorei7 +"\n");  
			  
		   ProcessorSerieFX();
		   System.out.print(ProcessorSerieFX +"\n");  
			  
		   ProcessorSeriepentium();
		   System.out.print(ProcessorSeriepentium +"\n");  
			  
		   ProcessorSeriesempron();
		   System.out.print(ProcessorSeriesempron +"\n");  
		  
		   
		  ProcessorclockingMin();
		  System.out.print(ProcessorclockingMin +"\n" );  
			  
		  ProcessorclockingMax();
		  System.out.print(ProcessorclockingMax +"\n" );  
	
		 
		
		  
		  // intern geheugen 
		    internalmemoryCorsair();
		    System.out.print(internalmemoryCorsair + "\n");  
		    internalmemoryCrusial();
		    System.out.print(internalmemoryCrusial + "\n");  
		    internalmemorykingston();
		    System.out.print(internalmemorykingston + "\n" );  
		    internalmemoryqnap();
		    System.out.print(internalmemoryqnap + "\n" );  
		    internalmemorysynology();
		    System.out.print(internalmemorysynology + "\n" );  
		    internalmemorygeenvoorkeur();
		    System.out.print(internalmemorygeenvoorkeur + "\n");  
		   
		    internalmemoryRAM1GB();
		    System.out.print(internalmemoryRAM1GB + "\n");  
		    internalmemoryRAM2GB();
		    System.out.print(internalmemoryRAM2GB + "\n");  
		    internalmemoryRAM4GB();
		    System.out.print(internalmemoryRAM4GB + "\n");  
		    internalmemoryRAM8GB();
		    System.out.print(internalmemoryRAM8GB + "\n");  
		    internalmemoryRAM16GB();
		    System.out.print(internalmemoryRAM16GB + "\n" );  
		    internalmemoryRAM32GB();
		    System.out.print(internalmemoryRAM32GB + "\n");  
		   
		   internalmemoryclocking();
		   System.out.print(internalmemoryclocking + "\n");  
		   
		   internalmemoryGaming();
		   System.out.print(internalmemoryGaming + "\n" );  
		   
		  internalmemorysuitableforDesktop();
		  System.out.print(internalmemorysuitableforDesktop + "\n");  
		  internalmemorysuitableforLaptop();
		  System.out.print(internalmemorysuitableforLaptop + "\n" );  
		  internalmemorysuitableforNas();
		  System.out.print(internalmemorysuitableforNas + "\n");  
		  internalmemorysuitableforMac();
		  System.out.print(internalmemorysuitableforMac + "\n");  ;

		  internalmemoryType();
		  System.out.print(internalmemoryType + "\n" );  
		  internalmemoryChannel();
		  System.out.print(internalmemoryChannel + "\n" );  
		   
		  internalmemoryPrijsMin();
		  System.out.print(internalmemoryPrijsMin + "\n");  
		   
		  internalmemoryPrijsMax();
		  System.out.print(internalmemoryPrijsMax + "\n" );  
		  
		   
		  // motherboard
		   motherboardMerkAsrock();
		   System.out.print(motherboardMerkAsrock + "\n");  
		   motherboardMerkAsus();
		   System.out.print(motherboardMerkAsus + "\n" );  
		   motherboardMerkMSI();
		   System.out.print(motherboardMerkMSI + "\n");  
		   
		    motherboardformaat();
		    System.out.print(motherboardformaat + "\n");  
		    motherboardWifi();
		    System.out.print(motherboardWifi + "\n" );  
		    motherboardmemoryslots();
		    System.out.print(motherboardmemoryslots + "\n" );  
		    motherboardHDMI();
		    System.out.print(motherboardHDMI + "\n" );  
		    motherboardVga();
		    System.out.print(motherboardVga + "\n");  
		    motherboardDisplayport();
		    System.out.print(motherboardDisplayport + "\n");  
		    
		    motherboardPrijsMin();
		    System.out.print(motherboardPrijsMin+ "\n");  
		    motherboardPrijsMax();
		    System.out.print(motherboardPrijsMax + "\n");  
		   
		    motherboardUsbPort();
		    System.out.print(motherboardUsbPort + "\n");  
		    
		    
		  
		   
		    motherboardEthernetport();
		    System.out.print(motherboardEthernetport + "\n" );  
		    
		    motherboardDVI();
		    System.out.print(motherboardDVI + "\n");  
		   
		   motherboardRAID0();
		   System.out.print(motherboardRAID0 + "\n" );  
		   motherboardRAID1();
		   System.out.print(motherboardRAID1 + "\n" );  
		   motherboardRAID5();
		   System.out.print(motherboardRAID5 + "\n" );  
		   motherboardRAID10();
		   System.out.print(motherboardRAID10 + "\n" );  
		   motherboardJBOD();
		   System.out.print(motherboardJBOD+ "\n" );  
		   motherboardGeen();
		   System.out.print(motherboardGeen + "\n" );  
		   
		    motherboardAudiChannel();
		    System.out.print(motherboardAudiChannel + "\n" );  
		    motherboardMemorytype();
		    System.out.print(motherboardMemorytype + "\n" );  
		    motherboardmSATAConnection();
		    System.out.print(motherboardmSATAConnection + "\n");  
		    motherboardmSATA300Connection();
		    System.out.print(motherboardmSATA300Connection + "\n");  
		    motherboardmSATA600Connection();
		    System.out.print(motherboardmSATA600Connection + "\n");  
		   
       
		    
		    //casing 
		    casingMerkAntec();
		    System.out.print(casingMerkAntec + "\n" ); 
		    casingMerkCoolerMaster();
		    System.out.print(casingMerkCoolerMaster + "\n" ); 
		    casingMerkCorsair();
		    System.out.print(casingMerkCorsair + "\n" ); 
		    casingMerkFractalDesign();
		    System.out.print(casingMerkFractalDesign + "\n"); 
		    casingMerkSilverstone();
		    System.out.print(casingMerkSilverstone + "\n" ); 
		    casingMerGeenvoorkeur();
		    System.out.print(casingMerGeenvoorkeur + "\n" ); 

		    casingComputerModel();
			System.out.print(casingComputerModel + "\n" ); 
		    casingfanController();
		    System.out.print(casingfanController + "\n" ); 
		    casingdustfilter();
		    System.out.print(casingdustfilter + "\n" ); 
		    casingsupplywatercooling();
		    System.out.print(casingsupplywatercooling + "\n" ); 
		    casingLEDdisplay(); 
		    System.out.print(casingLEDdisplay + "\n" ); 
		    casingnoiseReduction();
		    System.out.print(casingnoiseReduction + "\n" ); 
		    casingNoisereductionmats();
		    System.out.print(casingNoisereductionmats + "\n" ); 
		     casingpanelDoor();
			 System.out.print(casingpanelDoor + "\n" ); 
		    
		     CasingPrijsMin();
			 System.out.print(CasingPrijsMin + "\n"); 
		     CasingPrijsMax();
			 System.out.print(CasingPrijsMax + "\n" ); 
		    
		    
			 casingExpansionslotsMin();
			 System.out.print(casingExpansionslotsMin + "\n" ); 
			 casingExpansionslotsMax();
			 System.out.print(casingExpansionslotsMax + "\n" ); 
			 
		    
		     CasingColor();
			 System.out.print(CasingColor + "\n"); 
			 
			 CasingMatrial();
			 System.out.print(CasingMatrial + "\n"); 
			 
		    casingUsb20port0();
		    System.out.print(casingUsb20port0 + "\n"); 
		     casingUsb20port1();
			  System.out.print(casingUsb20port1 + "\n" ); 
		    casingUsb20port2();
		    System.out.print(casingUsb20port2 + "\n"); 
		    
		     casingUsb30port0();
			 System.out.print(casingUsb30port0 + "\n" ); 
		    casingUsb30port1();
		    System.out.print(casingUsb30port1 + "\n" ); 
		    casingUsb30port2();
		    System.out.print(casingUsb30port2 + "\n"); 
		    
		   casingFirewireport();
		   System.out.print(casingFirewireport + "\n" ); 
		     casingESATAConnection();
			 System.out.print(casingESATAConnection + "\n" ); 

		     casing25HDDSSDMin();
			  System.out.print(casing25HDDSSDMin + "\n"); 
		    
			  casing25HDDSSDMax();
		    System.out.print(casing25HDDSSDMax + "\n" ); 
		   
		    casing35HDDMin();
			 System.out.print(casing35HDDMin + "\n" ); 
		   
			 casing35HDDMax();
		    System.out.print(casing35HDDMax + "\n" ); 
		   
		    casing525BatyMin();
			  System.out.print(casing525BatyMin + "\n" ); 
		    
			  casing525BatyMax();
		    System.out.print(casing525BatyMax + "\n" ); 
	
		    
		  
		    // SSD 
		    ssdstoragecapacity30gb();
		    System.out.print(ssdstoragecapacity30gb + "\n" ); 
		   ssdstoragecapacity60gb();
		   System.out.print(ssdstoragecapacity60gb + "\n" ); 
		     ssdstoragecapacity64gb();
		     System.out.print(ssdstoragecapacity64gb + "\n" ); 
		     ssdstoragecapacity80gb();
		     System.out.print(ssdstoragecapacity80gb + "\n" ); 
		    ssdstoragecapacity120gb();
		    System.out.print(ssdstoragecapacity120gb + "\n"); 
		    
		   ssdstoragecapacity128gb();
		   System.out.print(ssdstoragecapacity128gb + "\n"); 
		   ssdstoragecapacity180gb();
		   System.out.print(ssdstoragecapacity180gb + "\n"); 
		     ssdstoragecapacity240gb();
		     System.out.print(ssdstoragecapacity240gb + "\n"); 
		    ssdstoragecapacity250gb();
		    System.out.print(ssdstoragecapacity250gb + "\n"); 
		    ssdstoragecapacity256gb();
		    System.out.print(ssdstoragecapacity256gb + "\n"); 
		    
		    
		     ssdstoragecapacity480gb();
		     System.out.print(ssdstoragecapacity480gb + "\n"); 
		    ssdstoragecapacity500gb();
		    System.out.print(ssdstoragecapacity500gb + "\n"); 
		     ssdstoragecapacity512gb();
		     System.out.print(ssdstoragecapacity512gb + "\n" ); 
		     ssdstoragecapacity960gb();
		     System.out.print(ssdstoragecapacity960gb + "\n" ); 
		     ssdstoragecapacity1tb();
		     System.out.print(ssdstoragecapacity1tb + "\n"); 
		  
		     ssdFormaat();
		     System.out.print(ssdFormaat + "\n" ); 
		     ssdTypeMemory();
		     System.out.print(ssdTypeMemory + "\n" ); 
		    
		    
		     ssdPrijsMin();
		     System.out.print(ssdPrijsMin + "\n"); 
		     ssdPrijsMax();
		     System.out.print(ssdPrijsMax + "\n"); 
		    
		     ssdMerkAMD();
		     System.out.print(ssdMerkAMD + "\n" ); 
		    ssdMerkCrucial();
		    System.out.print(ssdMerkCrucial + "\n" ); 
		     ssdMerkIntel();
		     System.out.print(ssdMerkIntel + "\n" ); 
		     sssdMerkKingston();
		     System.out.print(sssdMerkKingston + "\n"); 
		     ssdMerkOCZ();
		     System.out.print(ssdMerkOCZ + "\n"); 
		    
		    ssdMerkSamsung();
		    System.out.print(ssdMerkSamsung + "\n"); 
		     ssdMerkSanDisk();
		     System.out.print(ssdMerkSanDisk + "\n" ); 
		     sssdMerkGeenvoorkeur();
		     System.out.print(sssdMerkGeenvoorkeur + "\n"); 
		    
		     ssdControllerIndilinx();
		     System.out.print(ssdControllerIndilinx + "\n"); 
		     ssdControllerIntel();
		     System.out.print(ssdControllerIntel + "\n"); 
		  ssdControllerMarvell();
		    System.out.print(ssdControllerMarvell + "\n" ); 
		     ssdControllerSamsung();
		     System.out.print(ssdControllerSamsung + "\n"); 
		     ssdControllerSandForce();
		     System.out.print(ssdControllerSandForce + "\n"); 
		   ssdControllerPhison();
		   System.out.print(ssdControllerPhison + "\n"); 
		    
		     ssdWritingSpeedMin();
		     System.out.print(ssdWritingSpeedMin + "\n" ); 
		     ssdWritingSpeedMax();
		     System.out.print(ssdWritingSpeedMax + "\n"); 
		    
		     ssdReadingSpeedMin();
		     System.out.print(ssdReadingSpeedMin + "\n" ); 
		     ssdReadingSpeedMax();
		     System.out.print(ssdReadingSpeedMax + "\n" ); 
		    
		    
		      BluRayDVDMerkAsus();
		      System.out.print(BluRayDVDMerkAsus  + "\n" ); 
		     BluRayDVDMerkFreecom();
		     System.out.print(BluRayDVDMerkFreecom  + "\n" ); 
		     BluRayDVDMerkApple();
		     System.out.print(BluRayDVDMerkApple  + "\n" ); 
		      BluRayDVDMerkLG();
		      System.out.print(BluRayDVDMerkLG  + "\n"); 
		      BluRayDVDMerkSamsung();
		      System.out.print(BluRayDVDMerkSamsung  + "\n"); 
		      BluRayDVDMerkGeenvoorkeur();
		      System.out.print(BluRayDVDMerkGeenvoorkeur  + "\n"); 
		     
		    BluRayDVDDriverType(); 
		    System.out.print(BluRayDVDDriverType  + "\n" ); 
		      BluRayDVDPrijsmin();
		      System.out.print(BluRayDVDPrijsmin  + "\n"); 
		      BluRayDVDPrijsmax();
		      System.out.print(BluRayDVDPrijsmax  + "\n" ); 
		     
		     BluRayDVDPlaysDiscBluray();
		     System.out.print(BluRayDVDPlaysDiscBluray  + "\n"); 
		    BluRayDVDPlaysDiscDVD();
		    System.out.print(BluRayDVDPlaysDiscDVD  + "\n"); 
		      BluRayDVDPlaysDiscCD();
		      System.out.print(BluRayDVDPlaysDiscCD  + "\n"); 
		      BluRayDVDPlaysDiscFloppy();
		      System.out.print(BluRayDVDPlaysDiscFloppy  + "\n"); 
		      BluRayDVDOperatingSystem();
		      System.out.print(BluRayDVDOperatingSystem  + "\n"); 
		     BluRayDVDtypetray();
		     System.out.print(BluRayDVDtypetray  + "\n"); 
		    
		     
		     
/*---------------------------------------------------------------------------------------------------------------------------*/		     	     
		 // voeding  
		alle_data.add(cpu_p4 );   
		alle_data.add(cpu_p8);     
		alle_data.add(cpu_p4p4);
		alle_data.add(modulair);
		alle_data.add(Certificering);
		alle_data.add(bequiet);
		alle_data.add(CoolerMarster);
		alle_data.add(Corsair);
		alle_data.add(Seasonic);
		alle_data.add(XFX );
		alle_data.add(pciexpress6pin );
		alle_data.add(pciexpress6PPpin);
		alle_data.add(VoedingPrijsMin );
		alle_data.add(VoedingPrijsMax );
		alle_data.add(VoedingVermogenMin  );
		alle_data.add(VoedingVermogenMax );
		alle_data.add(VoedingSATAaansluitingMin );
		alle_data.add(VoedingSATAaansluitingMax);
		
		// processorkoeler
		alle_data.add(ProcessorkoelerMerkBequite);
		alle_data.add(ProcessorkoelerMerkcoolermaster );
		alle_data.add(ProcessorkoelerMerkcorsair );
		alle_data.add(ProcessorkoelerMerkartic);
		alle_data.add(ProcessorkoelerMerkcrucial );
		alle_data.add(ProcessorkoelerMerkingston );
		alle_data.add(ProcessorkoelerMerkscythe );
		alle_data.add(ProcessorKoelerMethode );
		alle_data.add(ProcessorPrijsMin );
		alle_data.add(ProcessorPrijsMax );
		alle_data.add(ProcessorKoelerMethode );
		alle_data.add(ProcessorDiamter );
		alle_data.add(ProcessorCoolerRSpeedMin );
		alle_data.add(ProcessorCoolerRSpeedMax );
		
		
		
		// Harde schijf
		alle_data.add(HarddriveMerkLacie );
		alle_data.add(HarddriveMerkSeagate);
		alle_data.add(HarddriveMerToshiba);
		alle_data.add(HarddriveMerWesternDigital);
		alle_data.add(HarddriveFormaat);
		alle_data.add(Harddrivestoragecapacity160gb);
		alle_data.add(Harddrivestoragecapacity320gb);
		alle_data.add(Harddrivestoragecapacity500gb);
		alle_data.add(Harddrivestoragecapacity750gb);
		alle_data.add(Harddrivestoragecapacity1tb);
		alle_data.add(Harddrivestoragecapacity2tb);
		alle_data.add(Harddrivestoragecapacity3tb);
		alle_data.add(Harddrivestoragecapacity4tb);
		alle_data.add(Harddrivestoragecapacity5tb);
		alle_data.add(Harddrivestoragecapacity6tb);
		alle_data.add(Harddriveconnection);
		alle_data.add(HarddriveBuffer);
		alle_data.add(HarddriveSpeed);
		alle_data.add(HarddrivePriceMin);
		alle_data.add(HarddrivePriceMax);
		
		// Geluidskaart 
		alle_data.add(SoundcardMerkAsus );
		alle_data.add(SoundcardMerkCreative);
		alle_data.add(SoundcardSample);
		alle_data.add(SoundcardAiso);
		alle_data.add(Soundcardopticalinput);
		alle_data.add(SoundcardProcessorAsusAV100);
		alle_data.add(SoundcardProcessorAsusUS100 );
		alle_data.add(SoundcardProcessorCmi8786 );
		alle_data.add(SoundcardProcessorCmi8888DHT );
		alle_data.add(SoundcardProcessorSoundCore3D);
		alle_data.add(SoundcardProcessorSounndGeenvoorkeur );
		alle_data.add(SoundcardSpeakerChannel);
		alle_data.add(headphonejack);
		alle_data.add(mmminijack);
		alle_data.add(SoundcardPrijsMin);
		alle_data.add(SoundcardPrijsMax);
		
		//pci express
		alle_data.add(PciUsb );
		alle_data.add(PciFirewire);
		alle_data.add(PciSataConnection );
		alle_data.add(PciESataConnection);
		alle_data.add(PciPrijsMin);
		alle_data.add(PciPrijsMax);
	
		//videokaart 
		alle_data.add(VideocardmanufacturerNvida );
		alle_data.add(VideocardmanufacturerAmd);
		alle_data.add(VideocardAmdAMDRadeonR9270X);
		alle_data.add(VideocardAmdAMDRadeonR9270);
		alle_data.add(VideocardAmdAMDRadeonR7240);
		alle_data.add(VideocardAmdAMDRadeonHD6450);
		alle_data.add(VideocardAmdAMDRadeonR9280);
		alle_data.add(VideocardAmdAMDRadeonR9280X);
		alle_data.add(VideocardAmdAMDRadeonR9290);
		alle_data.add(VideocardAmdAMDRadeonR9290X);
		alle_data.add(VideocardAmdAMDRadeonR7250);
		alle_data.add(VideocardAmdAMDRadeonHD3450AGP);
		
		alle_data.add(VideocardnvidiaNVIDIAFX5500);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX780);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX980);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX970);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGT730);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX660);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX750);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX760);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGT740);
		alle_data.add(VideocardnvidiaNVIDIAGeForceGTX770);
		

		alle_data.add(VideocardMerkAsus);
		alle_data.add(VideocardMerkClub3d);
		alle_data.add(VideocardMerkGigabyte);
		alle_data.add(VideocardMerkSapphire);
		alle_data.add(VideocardMerkMSI);
		alle_data.add(VideocardMerkGeenvoorkeur);
		
		alle_data.add(VideocardTyeMemory);
		alle_data.add(VideocardHdmi);
		alle_data.add(VideocardVga);
		alle_data.add(VideocardMemorybus);
		alle_data.add(VideocardDVIIConnection);
		alle_data.add(VideocardDVIDConnection);
		
		alle_data.add(VideocardPrijsMin);
		alle_data.add(VideocardPrijsMax );
		alle_data.add(VideocardMemorryMBMin);
		alle_data.add(VideocardMemorryMBMax);
		
		
		
		// processor
		alle_data.add(ProcessorMerkIntel );
		alle_data.add(ProcessorMerkAMD);
		alle_data.add(ProcessorcoresDualcore);
		alle_data.add(ProcessorcoresQuadcore);
		alle_data.add(Processorcores6core);
		alle_data.add(Processorcores8core );
		alle_data.add(ProcessorPPrijsMin );
		alle_data.add(ProcessorPPrijsMax );
		
		alle_data.add(ProcessorSerieA10);
		alle_data.add(ProcessorSerieA6 );
		alle_data.add(ProcessorSerieA8);
		alle_data.add(ProcessorSeriecorei3);
		alle_data.add(ProcessorSeriecorei5);
		alle_data.add(ProcessorSeriecorei7);
		
		alle_data.add(ProcessorSerieFX );
		alle_data.add(ProcessorSeriepentium);
		alle_data.add(ProcessorSeriesempron);
		alle_data.add(ProcessorclockingMin);
		alle_data.add(ProcessorclockingMax);
		
		
		// intern geheugen 
		alle_data.add(internalmemoryCorsair );
		alle_data.add(internalmemoryCrusial );
		alle_data.add(internalmemorykingston );
		alle_data.add(internalmemoryqnap);
		alle_data.add(internalmemorysynology );
		alle_data.add(internalmemorygeenvoorkeur );
		
		alle_data.add(internalmemoryRAM1GB);
		alle_data.add(internalmemoryRAM2GB);
		alle_data.add(internalmemoryRAM4GB);
		alle_data.add(internalmemoryRAM8GB);
		alle_data.add(internalmemoryRAM16GB );
		alle_data.add(internalmemoryRAM32GB );
		alle_data.add(internalmemoryclocking );
		
		alle_data.add(internalmemoryGaming);
		alle_data.add(internalmemorysuitableforDesktop );
		alle_data.add(internalmemorysuitableforLaptop);
		alle_data.add(internalmemorysuitableforNas);
		alle_data.add(internalmemorysuitableforMac);
		alle_data.add(internalmemoryType);
		alle_data.add(internalmemoryChannel );
		alle_data.add(internalmemoryPrijsMin );
		alle_data.add(internalmemoryPrijsMax );
		
		//moederborden 
		alle_data.add(motherboardMerkAsrock );
		alle_data.add(motherboardMerkAsus );
		alle_data.add(motherboardMerkMSI );
		alle_data.add(motherboardformaat);
		alle_data.add(motherboardWifi );
		
		alle_data.add(motherboardmemoryslots);
		alle_data.add(motherboardHDMI);
		alle_data.add(motherboardVga);
		alle_data.add(motherboardDisplayport);
		alle_data.add(motherboardPrijsMin );
		alle_data.add(motherboardPrijsMax );
		alle_data.add(motherboardUsbPort );
		
		alle_data.add(motherboardEthernetport);
		alle_data.add(motherboardDVI );
		
		alle_data.add(motherboardRAID0);
		alle_data.add(motherboardRAID1);
		alle_data.add(motherboardRAID5);
		alle_data.add(motherboardRAID10);
		alle_data.add(motherboardJBOD );
		alle_data.add(motherboardGeen );
		alle_data.add(motherboardAudiChannel );
		alle_data.add(motherboardMemorytype );
		alle_data.add(motherboardmSATAConnection );
		alle_data.add(motherboardmSATA300Connection );
		alle_data.add(motherboardmSATA600Connection );
		
	
		// behuizing 
		
		alle_data.add(casingMerkAntec );
		alle_data.add(casingMerkCoolerMaster);
		alle_data.add(casingMerkCorsair);
		alle_data.add(casingMerkFractalDesign);
		alle_data.add(casingMerkSilverstone);
		alle_data.add(casingMerGeenvoorkeur);
		
		
		alle_data.add(casingComputerModel);
		alle_data.add(casingfanController);
		alle_data.add(casingdustfilter);
		alle_data.add(casingnoiseReduction);
		alle_data.add(casingNoisereductionmats);
		alle_data.add(casingpanelDoor);
		
		alle_data.add(CasingPrijsMin);
		alle_data.add(CasingPrijsMax);
		alle_data.add(casingExpansionslotsMin);
		alle_data.add(casingExpansionslotsMax);
		alle_data.add(CasingColor);
		alle_data.add(CasingMatrial);
		alle_data.add(casingUsb20port0);
		alle_data.add(casingUsb20port1);
		alle_data.add(casingUsb20port2);
		alle_data.add(casingUsb30port0);
		
		alle_data.add(casingUsb30port1);
		alle_data.add(casingUsb30port2);
		
		alle_data.add(casingFirewireport);
		alle_data.add(casingESATAConnection);
		alle_data.add(casing25HDDSSDMin);
		alle_data.add(casing25HDDSSDMax);
		
		alle_data.add(casing35HDDMin);
		alle_data.add(casing35HDDMax);
		alle_data.add(casing525BatyMin);
		alle_data.add(casing525BatyMax);
		alle_data.add(casingLEDdisplay);
		alle_data.add(casing525BatyMax);
		
		//casingLEDdisplay
		//casingsupplywatercooling

		
	// ssd 
		alle_data.add(ssdstoragecapacity30gb);
		alle_data.add(ssdstoragecapacity60gb);
		alle_data.add(ssdstoragecapacity64gb);
		alle_data.add(ssdstoragecapacity80gb);
		alle_data.add(ssdstoragecapacity120gb);
		
		alle_data.add(ssdstoragecapacity128gb);
		alle_data.add(ssdstoragecapacity180gb);
		
		alle_data.add(ssdstoragecapacity240gb);
		alle_data.add(ssdstoragecapacity250gb);
		alle_data.add(ssdstoragecapacity256gb);
		alle_data.add(ssdstoragecapacity480gb);
		
		alle_data.add(ssdstoragecapacity500gb);
		alle_data.add(ssdstoragecapacity512gb);
		alle_data.add(ssdstoragecapacity960gb);
		alle_data.add(ssdstoragecapacity1tb);
		
		
		
		
		alle_data.add(ssdFormaat);
		alle_data.add(ssdTypeMemory);
		
		alle_data.add(ssdPrijsMin);
		alle_data.add(ssdPrijsMax);
		
		alle_data.add(ssdMerkAMD);
		alle_data.add(ssdMerkCrucial);
		alle_data.add(ssdMerkIntel);
		
		alle_data.add(sssdMerkKingston);
		alle_data.add(ssdMerkOCZ);
		alle_data.add(ssdMerkSamsung);
		alle_data.add(ssdMerkSanDisk);
		alle_data.add(sssdMerkGeenvoorkeur);
		
		alle_data.add(ssdControllerIndilinx);
		alle_data.add(ssdControllerIntel);
		alle_data.add(ssdControllerMarvell);
		
		alle_data.add(ssdControllerSamsung);
		alle_data.add(ssdControllerSandForce);
		alle_data.add(ssdControllerPhison);
		
		
		alle_data.add(ssdWritingSpeedMin);
		alle_data.add(ssdWritingSpeedMax);
		
		alle_data.add(ssdReadingSpeedMin);
		alle_data.add(ssdReadingSpeedMax);
 
		// bludray dvd 
		
		alle_data.add(BluRayDVDMerkAsus);
		alle_data.add(BluRayDVDMerkFreecom);
		
		alle_data.add(BluRayDVDMerkApple);
		alle_data.add(BluRayDVDMerkLG);
		
		alle_data.add(BluRayDVDMerkSamsung);
		alle_data.add(BluRayDVDMerkGeenvoorkeur);
		alle_data.add(BluRayDVDDriverType);
		
		alle_data.add(BluRayDVDPrijsmin);
		alle_data.add(BluRayDVDPrijsmax);
		alle_data.add(BluRayDVDPlaysDiscBluray);
		alle_data.add(BluRayDVDPlaysDiscDVD);
		alle_data.add(BluRayDVDPlaysDiscCD);
		
		alle_data.add(BluRayDVDPlaysDiscFloppy);
		
		alle_data.add(BluRayDVDOperatingSystem);
		alle_data.add(BluRayDVDtypetray);
		
		
		
		
		System.out.println("Array is: " + alle_data);
		     
/*---------------------------------------------------------------------------------------------------------------------------*/		     
		     
		     
		     
		return(alle_data);
	}
   
   
		
	    
	     
	public static String cpu_p4() {
		temp = string.charAt(0);
		//System.out.print(temp);
		if(temp == '1') {
			cpu_p4 = " CPUP4";
		}
		else {
			cpu_p4 = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return cpu_p4;
	}
	public static String cpu_p8() {
		temp = string.charAt(1);
		if(temp == '1') {
			cpu_p8 = "CPUP8";
		}
		else {
			cpu_p8 = "chooseplease";
		}
		return cpu_p8;
	}
	//01
	
	//radio 
	public static String cpu_p4p4() {
		temp = string.charAt(2);
		if(temp == '1') {
			cpu_p4p4 = "0";
		}
		else if(temp == '2') {
			cpu_p4p4 = "1";
		}
		else if(temp == '3') {
			cpu_p4p4 = "2";
		}
		else {
			cpu_p4p4 = "nopreference";
		}
		return cpu_p4p4;
	}
	//2
	public static String modulair() {
		temp = string.charAt(3);
		if(temp == '1') {
			modulair = "Ja";
		}
		else if(temp == '2') {
			modulair = "Nee";
		}	
		return modulair;
		}
		//3
	
	public static String Certificering() {
		temp = string.charAt(4);
		if(temp == '1') {
			Certificering = "80PLUS";
		}
		else if(temp == '2') {
			Certificering = "80PLUSBronze";
		}	
		else if(temp == '3') {
			Certificering = "80PLUSSilver";
		}	
		else if(temp == '4') {
			Certificering = "80PLUSGold";
		}	
		else if(temp == '5') {
			Certificering = "Geencertificering";
		}	
		else if(temp == '6') {
			Certificering = "nopreference";
		}	
		return Certificering;
		}
	
	//4
		
public static String bequiet() {
	temp = string.charAt(5);
	//System.out.print(temp);
	if(temp == '1') {
		bequiet = "Be quiet!";
	}
	else {
		bequiet = "notavailable";
	}
	//System.out.print(cpu_p4);
	return bequiet;
}

public static String CoolerMarster() {
	temp = string.charAt(6);
	//System.out.print(temp);
	if(temp == '1') {
		CoolerMarster = "Cooler Marster";
	}
	else {
		CoolerMarster = "notavailable";
	}
	//System.out.print(cpu_p4);
	return CoolerMarster;
}

public static String Corsair() {
	temp = string.charAt(7);
	//System.out.print(temp);
	if(temp == '1') {
		Corsair = "Corsair";
	}
	else {
		Corsair = "notavailable7";
	}
	//System.out.print(cpu_p4);
	return Corsair;
}



public static String Seasonic() {
	temp = string.charAt(8);
	//System.out.print(temp);
	if(temp == '1') {
		Seasonic = "Seasonic";
	}
	else {
		Seasonic = "notavailable";
	}
	//System.out.print(cpu_p4);
	return Seasonic;
}


public static String XFX() {
	temp = string.charAt(9);
	//System.out.print(temp);
	if(temp == '1') {
		XFX = "XFX";
	}
	else {
		XFX = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return XFX;
}

public static String pciexpress6pin() {
	temp = string.charAt(10);
	if(temp == '1') {
		pciexpress6pin = "0";
	}
	else if(temp == '2') {
		pciexpress6pin = "1";
	}	
	else if(temp == '3') {
		pciexpress6pin = "2";
	}	
	else if(temp == '4') {
		pciexpress6pin = "Geen voorkeur";
	}	
	else if(temp == '0') {
		pciexpress6pin = "0";
	}	
	return pciexpress6pin;
	}

public static String pciexpress6PPpin() {
	temp = string.charAt(11);
	if(temp == '1') {
		pciexpress6PPpin = "0";
	}
	else if(temp == '2') {
		pciexpress6PPpin = "1";
	}	
	else if(temp == '3') {
		pciexpress6PPpin = "2";
	}	
	else if(temp == '4') {
		pciexpress6PPpin = "3";
	}
	else if(temp == '5') {
		pciexpress6PPpin = "4";
	}	
	else if(temp == '6') {
		pciexpress6PPpin = "5";
	}	
	else if(temp == '7') {
		pciexpress6PPpin = "6";
	}	
	else if(temp == '8') {
		pciexpress6PPpin = "7";
	}	
	else if(temp == '9') {
		pciexpress6PPpin = "8";
	}
	else if(temp == 'a') {
		pciexpress6PPpin = "Geen voorkeur";
	}
	
	return pciexpress6PPpin;
	
}


public static String VoedingPrijsMin() {
	temp = string.charAt(12);
	//System.out.print(temp);
	if(temp == '1') {
		VoedingPrijsMin = "0";
	}
	else if(temp == '2') {
		VoedingPrijsMin = "40";
	}	
	else if(temp == '3') {
		VoedingPrijsMin = "80";
	}
	else if(temp == '4') {
		VoedingPrijsMin = "160";
	}	
	else if(temp == '5') {
		VoedingPrijsMin = "200";
	}	
	else if(temp == '6') {
		VoedingPrijsMin = "240";
	}	
	else if(temp == '7') {
		VoedingPrijsMin = "280";
	}	
	else if(temp == '8') {
		VoedingPrijsMin = "320";
	}	
	else if(temp == '9') {
		VoedingPrijsMin = "360";
	}	
	else if(temp == 'a') {
		VoedingPrijsMin = "400";
	}
	return VoedingPrijsMin;	
}	

	
	

public static String VoedingPrijsMax() {
	temp = string.charAt(13);
	//System.out.print(temp);
	if(temp == '1') {
		VoedingPrijsMax = "0";
	}
		else if(temp == '2') {
			VoedingPrijsMax = "40";
		}	
		else if(temp == '3') {
			VoedingPrijsMax = "80";
		}
		else if(temp == '4') {
			VoedingPrijsMax = "160";
		}	
		else if(temp == '5') {
			VoedingPrijsMax = "200";
		}	
		else if(temp == '6') {
			VoedingPrijsMax = "240";
		}	
		else if(temp == '7') {
			VoedingPrijsMax = "280";
		}	
		else if(temp == '8') {
			VoedingPrijsMax = "320";
		}	
		else if(temp == '9') {
			VoedingPrijsMax = "360";
		}	
		else if(temp == 'a') {
			VoedingPrijsMax = "400";
		}
		return VoedingPrijsMax;	
	}	

		
		

public static String VoedingVermogenMin() {
	temp = string.charAt(14);
	//System.out.print(temp);
   if(temp == '1') {
		VoedingVermogenMin = "400";	
		}
	else if(temp == '2') {
		VoedingVermogenMin = "450";
	}	
	else if(temp == '3') {
		VoedingVermogenMin = "500";
	}
	else if(temp == '4') {
		VoedingVermogenMin = "550";
	}	
	else if(temp == '5') {
		VoedingVermogenMin = "600";
	}	
	else if(temp == '6') {
		VoedingVermogenMin = "650";
	}	
	else if(temp == '7') {
		VoedingVermogenMin = "700";
	}	
	else if(temp == '8') {
		VoedingVermogenMin = "750";
	}	
	else if(temp == '9') {
		VoedingVermogenMin = "800";
	}	
	else if(temp == 'a') {
		VoedingVermogenMin = "850";
	}
	else if(temp == 'b') {
		VoedingVermogenMin = "900";
	}
	else if(temp == 'c') {
		VoedingVermogenMin = "950";
	}
	else if(temp == 'd') {
		VoedingVermogenMin = "1000";
	}
	else if(temp == '0') {
		VoedingVermogenMin = "0";
	}
	return VoedingVermogenMin;	
}	


public static String VoedingVermogenMax() {
	temp = string.charAt(15);
	   if(temp == '1') {
		   VoedingVermogenMax = "400";	
			}
		else if(temp == '2') {
			VoedingVermogenMax = "450";
		}	
		else if(temp == '3') {
			VoedingVermogenMax = "500";
		}
		else if(temp == '4') {
			VoedingVermogenMax = "550";
		}	
		else if(temp == '5') {
			VoedingVermogenMax = "600";
		}	
		else if(temp == '6') {
			VoedingVermogenMax = "650";
		}	
		else if(temp == '7') {
			VoedingVermogenMax = "700";
		}	
		else if(temp == '8') {
			VoedingVermogenMax = "750";
		}	
		else if(temp == '9') {
			VoedingVermogenMax = "800";
		}	
		else if(temp == 'a') {
			VoedingVermogenMax = "850";
		}
		else if(temp == 'b') {
			VoedingVermogenMax = "900";
		}
		else if(temp == 'c') {
			VoedingVermogenMax = "950";
		}
		else if(temp == 'd') {
			VoedingVermogenMax = "1000";
		}
		else if(temp == '0') {
			VoedingVermogenMax = "0";
		}
		return VoedingVermogenMax;	
	}	

//
public static String VoedingSATAaansluitingMin() {
	temp = string.charAt(16);
	//System.out.print(temp);
	if(temp == '1') {
		VoedingSATAaansluitingMin = "0";	
		}
	else if(temp == '2') {
		VoedingSATAaansluitingMin = "1";
	}	
	else if(temp == '3') {
		VoedingSATAaansluitingMin = "2";
	}
	else if(temp == '4') {
		VoedingSATAaansluitingMin = "3";
	}	
	else if(temp == '5') {
		VoedingSATAaansluitingMin = "4";
	}
	else if(temp == '6') {
		VoedingSATAaansluitingMin = "5";
	}
	else if(temp == '7') {
		VoedingSATAaansluitingMin = "6";
	}
	else if(temp == '8') {
		VoedingSATAaansluitingMin = "7";
	}
	//
	else if(temp == '9') {
		VoedingSATAaansluitingMin = "8";
	}
	else if(temp == 'a') {
		VoedingSATAaansluitingMin = "9";
	}
	else if(temp == 'b') {
		VoedingSATAaansluitingMin = "10";
	}
	else if(temp == 'c') {
		VoedingSATAaansluitingMin = "11";
	}
	else if(temp == 'd') {
		VoedingSATAaansluitingMin = "12";
	}
	else if(temp == '0') {
		VoedingSATAaansluitingMin = "0";
	}
	return VoedingSATAaansluitingMin;	
}



public static String VoedingSATAaansluitingMax() {
	temp = string.charAt(17);
	//System.out.print(temp);
	if(temp == '1') {
		VoedingSATAaansluitingMax = "0";	
		}
	else if(temp == '2') {
		VoedingSATAaansluitingMax = "1";
	}	
	else if(temp == '3') {
		VoedingSATAaansluitingMax = "2";
	}
	else if(temp == '4') {
		VoedingSATAaansluitingMax = "3";
	}	
	else if(temp == '5') {
		VoedingSATAaansluitingMax = "4";
	}
	else if(temp == '6') {
		VoedingSATAaansluitingMax = "5";
	}
	else if(temp == '7') {
		VoedingSATAaansluitingMax = "6";
	}
	else if(temp == '8') {
		VoedingSATAaansluitingMax = "7";
	}
	//
	else if(temp == '9') {
		VoedingSATAaansluitingMax = "8";
	}
	else if(temp == 'a') {
		VoedingSATAaansluitingMax = "9";
	}
	else if(temp == 'b') {
		VoedingSATAaansluitingMax = "10";
	}
	else if(temp == 'c') {
		VoedingSATAaansluitingMax = "11";
	}
	else if(temp == 'd') {
		VoedingSATAaansluitingMax = "12";
	}
	else if(temp == '0') {
		VoedingSATAaansluitingMax = "0";
	}
	return VoedingSATAaansluitingMax;	
}



// Processor Koeler 
//  boxen = 18 19 20 21 22 23 24 
//slider = 25 stappen min  26 max stappen 
//radio = 27 (1 2)
//slider 28stappen 
//slider  30 stappen min  31 max stappen


public static String ProcessorkoelerMerkBequite() {
	temp = string.charAt(18);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkBequite = "Bequiet!";
	}
	else {
		ProcessorkoelerMerkBequite = "selecteer merk ";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkBequite;
}


public static String ProcessorkoelerMerkcoolermaster() {
	temp = string.charAt(19);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkcoolermaster = "CoolerMaster";
	}
	else {
		ProcessorkoelerMerkcoolermaster = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkcoolermaster;
}


public static String ProcessorkoelerMerkcorsair() {
	temp = string.charAt(20);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkcorsair = "Cosair";
	}
	else {
		ProcessorkoelerMerkcorsair = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkcorsair;
}


public static String ProcessorkoelerMerkartic() {
	temp = string.charAt(21);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkartic = "Arctic";
	}
	else {
		ProcessorkoelerMerkartic = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkartic;
}


public static String ProcessorkoelerMerkcrucial() {
	temp = string.charAt(22);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkcrucial = "Crucial";
	}
	else {
		ProcessorkoelerMerkcrucial = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkcrucial;
}

public static String ProcessorkoelerMerkingston() {
	temp = string.charAt(23);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkingston = "Kingston";
	}
	else {
		ProcessorkoelerMerkingston = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkingston;
}

public static String ProcessorkoelerMerkscythe() {
	temp = string.charAt(24);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorkoelerMerkscythe = "Scythe";
	}
	else {
		ProcessorkoelerMerkscythe = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return ProcessorkoelerMerkscythe;
}

public static String ProcessorPrijsMin() {
	temp = string.charAt(25);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorPrijsMin = "0";	
		}
		else if(temp == '2') {
			ProcessorPrijsMin = "20";
		}	
		else if(temp == '3') {
			ProcessorPrijsMin = "40";
		}
		else if(temp == '4') {
			ProcessorPrijsMin = "60";
		}	
		else if(temp == '5') {
			ProcessorPrijsMin = "80";
		}	
		else if(temp == '6') {
			ProcessorPrijsMin = "100";
		}
		else if(temp == '7') {
				ProcessorPrijsMin = "120";
	//System.out.print(cpu_p4);
		}
	return ProcessorPrijsMin;
}

public static String ProcessorPrijsMax() {
	temp = string.charAt(26);
	if(temp == '1') {
		ProcessorPrijsMax = "0";	
		}
		else if(temp == '2') {
			ProcessorPrijsMax = "20";
		}	
		else if(temp == '3') {
			ProcessorPrijsMax = "40";
		}
		else if(temp == '4') {
			ProcessorPrijsMax = "60";
		}	
		else if(temp == '5') {
			ProcessorPrijsMax = "80";
		}	
		else if(temp == '6') {
			ProcessorPrijsMax = "100";
		}
		else if(temp == '7') {
			ProcessorPrijsMax = "120";
	//System.out.print(cpu_p4);
		}
	return ProcessorPrijsMax;
}	


public static String ProcessorKoelerMethode() {
	temp = string.charAt(27);
	if(temp == '1') {
		ProcessorKoelerMethode = "Lucht";
	}
	else if(temp == '2') {
		ProcessorKoelerMethode = "Water";
	}	
	return ProcessorKoelerMethode;
	}


public static String ProcessorDiamter() {
	temp = string.charAt(28);
	if(temp == '1') {
		ProcessorDiamter = "6 cm";
	}
	else if(temp == '2') {
		ProcessorDiamter = "7 cm";
	}	
	else if(temp == '3') {
		ProcessorDiamter = "8 cm ";
	
	}	else if(temp == '4') {
		ProcessorDiamter = "9 cm";
	}	
	else if(temp == '5') {
		ProcessorDiamter = "10 cm";
	}	
	else if(temp == '6') {
		ProcessorDiamter = "11 cm";
	}	
	else if(temp == '7') {
		ProcessorDiamter = "12 cm";
	}	
	else if(temp == '8') {
		ProcessorDiamter = "13 cm";
	}	
	else if(temp == '9') {
		ProcessorDiamter = "14 cm";
	}	
	else if(temp == '0') {
		ProcessorDiamter = "";
	}
	return ProcessorDiamter;
	}

 public static String ProcessorCoolerRSpeedMin(){
	
	temp = string.charAt(29);
	if(temp == '1') {
		ProcessorCoolerRSpeedMin = "800rpm";
	}
	else if(temp == '2') {
		ProcessorCoolerRSpeedMin = "1000rpm";
	}	
	else if(temp == '3') {
		ProcessorCoolerRSpeedMin = "1200rpm";
	
	}	else if(temp == '4') {
		ProcessorCoolerRSpeedMin = "1400rpm";
	}	
	else if(temp == '5') {
		ProcessorCoolerRSpeedMin = "1600rpm";
	}	
	else if(temp == '6') {
		ProcessorCoolerRSpeedMin = "1800rpm";
	}	
	else if(temp == '7') {
		ProcessorCoolerRSpeedMin = "2000rpm";
	}	
	else if(temp == '8') {
		ProcessorCoolerRSpeedMin = "2200rpm";
	}	
	else if(temp == '9') {
		ProcessorCoolerRSpeedMin = "2400rpm";
	}	
	else if(temp == 'a') {
		ProcessorCoolerRSpeedMin = "2600rpm";
	}	
	else if(temp == 'b') {
		ProcessorCoolerRSpeedMin = "2800rpm";
	}	
	else if(temp == 'c') {
		ProcessorCoolerRSpeedMin = "3000rpm";
	}	
	else if(temp == 'd') {
		ProcessorCoolerRSpeedMin = "3200rpm";
	}	
	else if(temp == 'e') {
		ProcessorCoolerRSpeedMin = "3400rpm";
	}	
	else if(temp == '0') {
		ProcessorCoolerRSpeedMin = "";
	}	
	return ProcessorCoolerRSpeedMin;
	}



public static String ProcessorCoolerRSpeedMax(){
	
	temp = string.charAt(30);
	if(temp == '1') {
		ProcessorCoolerRSpeedMax = "800rpm";
	}
	else if(temp == '2') {
		ProcessorCoolerRSpeedMax = "1000rpm";
	}	
	else if(temp == '3') {
		ProcessorCoolerRSpeedMax = "1200rpm";
	
	}	else if(temp == '4') {
		ProcessorCoolerRSpeedMax = "1400rpm";
	}	
	else if(temp == '5') {
		ProcessorCoolerRSpeedMax = "1600rpm";
	}	
	else if(temp == '6') {
		ProcessorCoolerRSpeedMax = "1800rpm";
	}	
	else if(temp == '7') {
		ProcessorCoolerRSpeedMax = "2000rpm";
	}	
	else if(temp == '8') {
		ProcessorCoolerRSpeedMax = "2200rpm";
	}	
	else if(temp == '9') {
		ProcessorCoolerRSpeedMax = "2400rpm";
	}	
	else if(temp == 'a') {
		ProcessorCoolerRSpeedMax = "2600rpm";
	}	
	else if(temp == 'b') {
		ProcessorCoolerRSpeedMax = "2800rpm";
	}	
	else if(temp == 'c') {
		ProcessorCoolerRSpeedMax = "3000rpm";
	}	
	else if(temp == 'd') {
		ProcessorCoolerRSpeedMax = "3200rpm";
	}	
	else if(temp == 'e') {
		ProcessorCoolerRSpeedMax = "3400rpm";
	}	
	else if(temp == '0') {
		ProcessorCoolerRSpeedMax = "";
	}
	return ProcessorCoolerRSpeedMax;
	}



//interne harde schrijf
//boxen = 31 32 33 34 
//radio = 35 1 2
//boxen = 36 37 38 39 40 - 45
//radio = 46
//radio = 47
//radio = 48
//slider r = 49 min 50 max 


public static String HarddriveMerkLacie() {
	temp = string.charAt(31);
	if(temp == '1') {
		HarddriveMerkLacie = "LaCie";
	}
	else  {
		HarddriveMerkLacie = "selecteer merk";
	}	
	return HarddriveMerkLacie;
	}




public static String HarddriveMerkSeagate() {
	temp = string.charAt(32);
	//System.out.print(temp);
	if(temp == '1') {
		HarddriveMerkSeagate = "Seagate";
	}
	else {
		HarddriveMerkSeagate = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return HarddriveMerkSeagate;
}


public static String HarddriveMerToshiba() {
	temp = string.charAt(33);
		//System.out.print(temp);
	if(temp == '1') {
		HarddriveMerToshiba = "Toshiba";
		}
	else {
		HarddriveMerToshiba = "selecteer merk";
	}
	return HarddriveMerToshiba;
	}


public static String HarddriveMerWesternDigital() {
	temp = string.charAt(34);
	//System.out.print(temp);
	if(temp == '1') {
		HarddriveMerWesternDigital = "WesternDigital";
	}
	else {
		HarddriveMerWesternDigital = "selecteer merk";
	}
	//System.out.print(cpu_p4);
	return HarddriveMerWesternDigital;
}


public static String HarddriveFormaat() {
	temp = string.charAt(35);
	if(temp == '1') {
		HarddriveFormaat = "2,5inch";
	}
	else if(temp == '2') {
		HarddriveFormaat = "3,5inch";
	}	
	return HarddriveFormaat;
	}



public static String Harddrivestoragecapacity160gb() {
	temp = string.charAt(36);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity160gb = "160 GB";
		}
	else {
		Harddrivestoragecapacity160gb = "selecteer merk";
	}
	return Harddrivestoragecapacity160gb;
	}

public static String Harddrivestoragecapacity320gb() {
	temp = string.charAt(37);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity320gb = "320 GB";
		}
	else {
		Harddrivestoragecapacity320gb = "selecteer merk";
	}
	return Harddrivestoragecapacity320gb;
	}
public static String Harddrivestoragecapacity500gb() {
	temp = string.charAt(38);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity500gb = "500 GB";
		}
	else {
		Harddrivestoragecapacity500gb = "selecteer merk";
	}
	return Harddrivestoragecapacity500gb;
	}
public static String Harddrivestoragecapacity750gb() {
	temp = string.charAt(39);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity750gb = "750 GB";
		}
	else {
		Harddrivestoragecapacity750gb = "selecteermerk";
	}
	return Harddrivestoragecapacity750gb;
	}

public static String Harddrivestoragecapacity1tb() {
	temp = string.charAt(40);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity1tb = "1000 GB";
		}
	else {
		Harddrivestoragecapacity1tb = "selecteer merk";
	}
	return Harddrivestoragecapacity1tb;
	}


public static String Harddrivestoragecapacity2tb() {
	temp = string.charAt(41);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity2tb = "2000 GB";
		}
	else {
		Harddrivestoragecapacity2tb = "selecteer merk";
	}
	return Harddrivestoragecapacity2tb;
	}

public static String Harddrivestoragecapacity3tb() {
	temp = string.charAt(42);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity3tb = "3000 GB";
		}
	else {
		Harddrivestoragecapacity3tb = "selecteer merk";
	}
	return Harddrivestoragecapacity3tb;
	}

public static String Harddrivestoragecapacity4tb() {
	temp = string.charAt(43);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity4tb = "4000 GB";
		}
	else {
		Harddrivestoragecapacity4tb = "selecteer merk";
	}
	return Harddrivestoragecapacity4tb;
	}

public static String Harddrivestoragecapacity5tb() {
	temp = string.charAt(44);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity5tb = "5000 GB";
		}
	else {
		Harddrivestoragecapacity5tb = "selecteer merk";
	}
	return Harddrivestoragecapacity5tb;
	}

public static String Harddrivestoragecapacity6tb() {
	temp = string.charAt(45);
		//System.out.print(temp);
	if(temp == '1') {
		Harddrivestoragecapacity6tb = "6000 GB";
		}
	else {
		Harddrivestoragecapacity6tb = "selecteer merk";
	}
	return Harddrivestoragecapacity6tb;
	}



public static String Harddriveconnection(){
	
	temp = string.charAt(46);
	if(temp == '1') {
		Harddriveconnection = "S-ATA(II)";
	}
	else if(temp == '2') {
		Harddriveconnection = "S-ATA(III)";
	}	
	return Harddriveconnection;
	}





public static String HarddriveBuffer(){
	
	temp = string.charAt(47);
	if(temp == '1') {
		HarddriveBuffer = "8Mb";
	}
	else if(temp == '2') {
		HarddriveBuffer = "16MB";
	}	
	else if(temp == '3') {
		HarddriveBuffer = "32MB";
	}
	else if(temp == '4') {
		HarddriveBuffer = "64MB";
	}
	else if(temp == '5') {
		HarddriveBuffer = "128MB";
	}
	else if(temp == '6') {
		HarddriveBuffer = "Geen voorkeur";
	}
	else if(temp == '0') {
		HarddriveBuffer = "0";
	}
	return HarddriveBuffer;
	}



public static String HarddriveSpeed(){
	
	temp = string.charAt(48);
	if(temp == '1') {
		HarddriveSpeed = "5400rpm";
	}
	else if(temp == '2') {
		HarddriveSpeed = "5700rpm";
	}	
	else if(temp == '3') {
		HarddriveSpeed = "5900rpm";
	}	
	else if(temp == '4') {
		HarddriveSpeed = "5940rpm";
	}	
	else if(temp == '5') {
		HarddriveSpeed = "7200rpm";
	}		
	else if(temp == '6') {
		HarddriveSpeed = "Geen voorkeur";
	}	
	return HarddriveSpeed;
	}

public static String HarddrivePriceMin() {
	temp = string.charAt(49);
		//System.out.print(temp);
	if(temp == '1') {
		HarddrivePriceMin = "0";
		}
	else if (temp == '2'){
		HarddrivePriceMin = "50 ";
	}
	else if (temp == '3'){
		HarddrivePriceMin = "100";
	}
	else if (temp == '4'){
		HarddrivePriceMin = "150";
	}
	else if (temp == '5'){
		HarddrivePriceMin = "200";
	}
	else if (temp == '6'){
		HarddrivePriceMin = "250";
	}
	else if (temp == '7'){
		HarddrivePriceMin = "300";
	}
	else if (temp == '8'){
		HarddrivePriceMin = "350";
	}
	else if (temp == '9'){
		HarddrivePriceMin = "400";
	}
	return HarddrivePriceMin;
	}

    public static String HarddrivePriceMax() {
	temp = string.charAt(50);
	//System.out.print(temp);
   if(temp == '1') {
	   HarddrivePriceMax = "0";
	}
   else if (temp == '2'){
	   HarddrivePriceMax = "50 ";
   }
   else if (temp == '3'){
	  HarddrivePriceMax = "100";
   }
    else if (temp == '4'){
	   HarddrivePriceMax = "150";
   }
    else if (temp == '5'){
	   HarddrivePriceMax = "200";
    }
    else if (temp == '6'){
	   HarddrivePriceMax = "250";
   }
    else if (temp == '7'){
	   HarddrivePriceMax = "300";
   }
   else if (temp == '8'){
	  HarddrivePriceMax = "350";
   }
   else if (temp == '9'){
	  HarddrivePriceMax = "400";
  }
   return HarddrivePriceMax;
 }
 

//50 end 
// Geluidskaarten 
// box = 51 52
// radio = 53
//radio = 54
//radio = 55
// boxen = 56 57 58 59 60 61 62 
// radio = 63
// radio = 64
//radio = 65
// slider r= 66 min 67 max 



public static  String SoundcardMerkAsus(){
	temp = string.charAt(51);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardMerkAsus = "Asus";
	}
	else {
		SoundcardMerkAsus = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardMerkAsus;
}
	



public static  String SoundcardMerkCreative(){
	temp = string.charAt(52);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardMerkCreative = "Creative";
	}
	else {
		SoundcardMerkCreative = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardMerkCreative;
}
	


public static String SoundcardSample(){
	temp = string.charAt(53);
	//System.out.print(temp);
	   if(temp == '1') {
		   SoundcardSample = "8,000kHz";
		}
	   else if (temp == '2'){
		   SoundcardSample = "11,025kHz";
	   }
	   else if (temp == '3'){
		   SoundcardSample = "16,000kHz";
	   }
	    else if (temp == '4'){
	    	SoundcardSample = "22,050kHz";
	   }
	    else if (temp == '5'){
	    	SoundcardSample = "24,000kHz";
	    }
	    else if (temp == '6'){
	    	SoundcardSample = "32,000kHz";
	   }
	    else if (temp == '7'){
	    	SoundcardSample = "44,100kHz";
	   }
	   else if (temp == '8'){
		   SoundcardSample = "48,000kHz";
	   }
	   else if (temp == '9'){
		   SoundcardSample = "88,200kHz";
	  }
	   else if (temp == 'a'){
		   SoundcardSample = "96,000kHz";
	  }
	   else if (temp == 'b'){
		   SoundcardSample = "176,400kHz";
	  }
	   else if (temp == 'c'){
		   SoundcardSample = "192,000kHz";
	  }
	   else if (temp == '0'){
		   SoundcardSample = "0";
	  }
	   return SoundcardSample;
	 }
	 


public static  String SoundcardAiso(){
	temp = string.charAt(54);
	//System.out.print(temp);
	   if(temp == '1') {
		   SoundcardAiso = "0";
		}
	   else if (temp == '2'){
		   SoundcardAiso = "0";
	   }
	   else if (temp == '3'){
		   SoundcardAiso = "0";
	   }
	    else if (temp == '4'){
	    	SoundcardAiso = "0";
	   }
	    else if (temp == '5'){
	    	SoundcardAiso = "0";
	    }
	    else if (temp == '6'){
	    	SoundcardAiso = "0";
	   }
	    else if (temp == '7'){
	    	SoundcardAiso = "0";
	   }
	    else if (temp == '0'){
	    	SoundcardAiso = "0";
	   }
	   return SoundcardAiso;
 }
public static String Soundcardopticalinput(){
	temp = string.charAt(55);
	//System.out.print(temp);
	   if(temp == '1') {
		   Soundcardopticalinput = "Ja";
		}
	   else if (temp == '2'){
		   Soundcardopticalinput = "Nee";
	   }
	return Soundcardopticalinput;


}
// hier was ik 
public static  String SoundcardProcessorAsusAV100(){
	temp = string.charAt(56);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardProcessorAsusAV100 = "Asus AV100";
	}
	else {
		SoundcardProcessorAsusAV100 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardProcessorAsusAV100;
}
	
public static  String SoundcardProcessorAsusUS100 (){
	temp = string.charAt(57);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardProcessorAsusUS100 = "Asus UA100";
	}
	else {
		SoundcardProcessorAsusUS100 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardProcessorAsusUS100;
}
	

public static  String  SoundcardProcessorCmi8786 (){
	temp = string.charAt(58);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardProcessorCmi8786 = "C-Media CMI8786";
	}
	else {
		SoundcardProcessorCmi8786 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardProcessorCmi8786;
}
	

public static  String SoundcardProcessorCmi8888DHT (){
	temp = string.charAt(59);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardProcessorCmi8888DHT = "CMI8888DHT";
	}
	else {
		SoundcardProcessorCmi8888DHT = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardProcessorCmi8888DHT;
}
	

public static  String SoundcardProcessorSoundCore3D(){
	temp = string.charAt(60);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardProcessorSoundCore3D = "Sound Core3D";
	}
	else {
		SoundcardProcessorSoundCore3D = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardProcessorSoundCore3D;
}
	

public static  String SoundcardProcessorSounndGeenvoorkeur (){
	temp = string.charAt(61);
	//System.out.print(temp);
	if(temp == '1') {
		SoundcardProcessorSounndGeenvoorkeur = "Geen voorkeur";
	}
	else {
		SoundcardProcessorSounndGeenvoorkeur = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return SoundcardProcessorSounndGeenvoorkeur;
}
	//

public static String SoundcardSpeakerChannel(){
	temp = string.charAt(62);
	//System.out.print(temp);
	   if(temp == '1') {
		   SoundcardSpeakerChannel = "5.1surround";
		}
	   else if (temp == '2'){
		   SoundcardSpeakerChannel = " 7.1 surround";
	   }
	return SoundcardSpeakerChannel;

}

public static String headphonejack(){
	temp = string.charAt(63);
	//System.out.print(temp);
	   if(temp == '1') {
		   headphonejack = "Ja";
		}
	   else if (temp == '2'){
		   headphonejack = "Nee";
	   }
	return headphonejack;


}

public static String mmminijack(){
	temp = string.charAt(64);
	//System.out.print(temp);
	   if(temp == '1') {
		   mmminijack = "0";
		}
	   else if (temp == '2'){
		   mmminijack = "0";
	   }
	   else if (temp == '0'){
		   mmminijack = "0";
	   }
	return mmminijack;


}

public static String SoundcardPrijsMin(){
temp = string.charAt(65);
//System.out.print(temp);
   if(temp == '1') {
	   SoundcardPrijsMin = "0";
	}
   else if (temp == '2'){
	   SoundcardPrijsMin = "20";
   }
   else if (temp == '3'){
	   SoundcardPrijsMin = "40";
   }
    else if (temp == '4'){
    	SoundcardPrijsMin = "60";
   }
    else if (temp == '5'){
    	SoundcardPrijsMin = "80";
    }
    else if (temp == '6'){
    	SoundcardPrijsMin = "100";
   }
    else if (temp == '7'){
    	SoundcardPrijsMin = "120";
   }
    else if (temp == '8'){
    	SoundcardPrijsMin = "140";
   }
    else if (temp == '9'){
    	SoundcardPrijsMin = "160";
   }
    else if (temp == 'a'){
    	SoundcardPrijsMin = "180";
   }
    else if (temp == 'b'){
    	SoundcardPrijsMin = "200";
   }
   return SoundcardPrijsMin;
}

public static String SoundcardPrijsMax(){
temp = string.charAt(66);
//System.out.print(temp);
   if(temp == '1') {
	   SoundcardPrijsMax = "0";
	}
   else if (temp == '2'){
	   SoundcardPrijsMax = "20";
   }
   else if (temp == '3'){
	   SoundcardPrijsMax = "40";
   }
    else if (temp == '4'){
    	SoundcardPrijsMax = "60";
   }
    else if (temp == '5'){
    	SoundcardPrijsMax = "80";
    }
    else if (temp == '6'){
    	SoundcardPrijsMax = "100";
   }
    else if (temp == '7'){
    	SoundcardPrijsMax = "120";
   }
    else if (temp == '8'){
    	SoundcardPrijsMax = "140";
   }
    else if (temp == '9'){
    	SoundcardPrijsMax = "160";
   }
    else if (temp == 'a'){
    	SoundcardPrijsMax = "180";
   }
    else if (temp == 'b'){
    	SoundcardPrijsMax = "200";
   }
   return SoundcardPrijsMax;
}


// pci
// radio = 67
//radio = 68
//radio = 69
//radio = 70
// slider r = 71 min  max 72


public static String  PciUsb() {
temp = string.charAt(67);
//System.out.print(temp);
 if(temp == '1') {
	 PciUsb = "Ja";
	}
 else if (temp == '2'){
	 PciUsb = "Nee";
 }
return PciUsb;

}



public static String PciFirewire() {
temp = string.charAt(68);
//System.out.print(temp);
 if(temp == '1') {
	 PciFirewire = "Ja";
	}
 else if (temp == '2'){
	 PciFirewire = "Nee";
 }
return mmminijack;
 }

 	
public static String PciSataConnection() {
temp = string.charAt(69);
//System.out.print(temp);
   if(temp == '1') {
	   PciSataConnection = "Ja";
	}
   else if (temp == '2'){
	   PciSataConnection = "Nee";
   }
   else if (temp == '0'){
	   PciSataConnection = "0";
   }
return PciSataConnection;

}



public static String PciESataConnection() {
temp = string.charAt(70);
//System.out.print(temp);
   if(temp == '1') {
	   PciESataConnection = "Ja";
	}
   else if (temp == '2'){
	   PciESataConnection = "Nee";
   }
   else if (temp == '0'){
	   PciESataConnection = "0";
   }
   return PciSataConnection;
}


	
public static String PciPrijsMin() {
temp = string.charAt(71);
//System.out.print(temp);
 if(temp == '1') {
	 PciPrijsMin = "0";
	}
 else if (temp == '2'){
	 PciPrijsMin = "20";
 }
 else if (temp == '3'){
	 PciPrijsMin = "40";
 }
  else if (temp == '4'){
	  PciPrijsMin = "60";
 }
  else if (temp == '5'){
	  PciPrijsMin = "80";
  }
 return PciPrijsMin;
 }


public static String PciPrijsMax() {
temp = string.charAt(72);
//System.out.print(temp);
 if(temp == '1') {
	 PciPrijsMax = "0";
	}
 else if (temp == '2'){
	 PciPrijsMax = "20";
 }
 else if (temp == '3'){
	 PciPrijsMax = "40";
 }
  else if (temp == '4'){
	  PciPrijsMax = "60";
 }
  else if (temp == '5'){
	  PciPrijsMax = "80";
  }
 return PciPrijsMax;
 }


// videokaart 
// box= 73 nvidia 
// box = 74 amd 
// box = 75 - 84 amd
// box = 85 -94 nvidia
// box = 95 96 97 98 99 100 
// radio = 101 type
// radio = 102 hdmi
// radio = 103 vga 
// radio = 104 geheugen
// radio = 105 dvi 
// radio = 106 dvi-d
// slider = 107 min 108 max
// slider = 109 min 110 max 



public static String VideocardmanufacturerNvida() {
	temp = string.charAt(73);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardmanufacturerNvida = "NVIDIA";
	}
	else {
		VideocardmanufacturerNvida = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardmanufacturerNvida;
}
	




public static String VideocardmanufacturerAmd() {
	temp = string.charAt(74);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardmanufacturerAmd = "AMD";
	}
	else {
		VideocardmanufacturerAmd = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardmanufacturerAmd;
}
	



public static String VideocardAmdAMDRadeonR9270X() {
	temp = string.charAt(75);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR9270X = "AMDRadeonR9270X";
	}
	else {
		VideocardAmdAMDRadeonR9270X = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR9270X;
}
	


 


public static String VideocardAmdAMDRadeonR9270() {
	temp = string.charAt(76);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR9270 = "AMDRadeonR9270";
	}
	else {
		VideocardAmdAMDRadeonR9270 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR9270;
}
	



public static String VideocardAmdAMDRadeonR7240() {
	temp = string.charAt(77);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR7240 = "AMDRadeonR7240";
	}
	else {
		VideocardAmdAMDRadeonR7240 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR7240;
}
	

public static String VideocardAmdAMDRadeonHD6450() {
	temp = string.charAt(78);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonHD6450 = "AMDRadeonHD6450";
	}
	else {
		VideocardAmdAMDRadeonHD6450 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonHD6450;
}

public static String VideocardAmdAMDRadeonR9280() {
	temp = string.charAt(79);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR9280 = "AMDRadeonR9280";
	}
	else {
		VideocardAmdAMDRadeonR9280 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR9280;
}

public static String VideocardAmdAMDRadeonR9280X() {
	temp = string.charAt(80);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR9280X = "AMDRadeonR9280X";
	}
	else {
		VideocardAmdAMDRadeonR9280X = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR9280X;
}
	
	

public static String VideocardAmdAMDRadeonR9290() {
	temp = string.charAt(81);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR9290 = "AMDRadeonR9290";
	}
	else {
		VideocardAmdAMDRadeonR9290 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR9290;
}

public static String VideocardAmdAMDRadeonR9290X() {
	temp = string.charAt(82);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR9290X = "AMDRadeonR9290X";
	}
	else {
		VideocardAmdAMDRadeonR9290X = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR9290X;
}

public static String VideocardAmdAMDRadeonR7250() {
	temp = string.charAt(83);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonR7250 = "AMDRadeonR7250";
	}
	else {
		VideocardAmdAMDRadeonR7250 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonR7250;
}

public static String VideocardAmdAMDRadeonHD3450AGP() {
	temp = string.charAt(84);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardAmdAMDRadeonHD3450AGP = "AMD Radeon HD 3450 AGP";
	}
	else {
		VideocardAmdAMDRadeonHD3450AGP = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardAmdAMDRadeonHD3450AGP;
}




public static String VideocardnvidiaNVIDIAFX5500(){
	temp = string.charAt(85);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAFX5500 = "NVIDIAFX5500";
	}
	else {
		VideocardnvidiaNVIDIAFX5500 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAFX5500;
}

	
	



public static String VideocardnvidiaNVIDIAGeForceGTX780(){
	temp = string.charAt(86);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX780 = "NVIDIAGeForceGTX780";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX780 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX780;
}	
	



public static String VideocardnvidiaNVIDIAGeForceGTX980(){
	temp = string.charAt(87);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX980 = "NVIDIAGeForceGTX980";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX980 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX980;
}	
	
	
	



public static String VideocardnvidiaNVIDIAGeForceGTX970(){
	temp = string.charAt(88);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX970 = "NVIDIAGeForceGTX970";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX970 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX970;
}	
	
	
	

public static String VideocardnvidiaNVIDIAGeForceGT730(){
	temp = string.charAt(89);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGT730 = "NVIDIAGeForceGT730";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGT730 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGT730;
}	
	


public static String VideocardnvidiaNVIDIAGeForceGTX660(){
	temp = string.charAt(90);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX660 = "NVIDIAGeForceGTX660";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX660 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX660;
}	
	


public static String VideocardnvidiaNVIDIAGeForceGTX750(){
	temp = string.charAt(91);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX750 = "NVIDIAGeForceGTX750";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX750 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX750;
}	
	



public static String VideocardnvidiaNVIDIAGeForceGTX760(){
	temp = string.charAt(92);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX760 = "NVIDIAGeForceGTX760";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX760 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX760;
}	
	



public static String VideocardnvidiaNVIDIAGeForceGT740(){
	temp = string.charAt(93);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGT740 = "NVIDIA GeForce GT 740";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGT740 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGT740;
}	
	


public static String VideocardnvidiaNVIDIAGeForceGTX770(){
	temp = string.charAt(94);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardnvidiaNVIDIAGeForceGTX770 = "NVIDIAGeForceGTX770";
	}
	else {
		VideocardnvidiaNVIDIAGeForceGTX770 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardnvidiaNVIDIAGeForceGTX770;
}

public static String VideocardMerkAsus(){
	temp = string.charAt(95);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardMerkAsus = "Asus";
	}
	else {
		VideocardMerkAsus = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardMerkAsus;
}	
	
	

public static String VideocardMerkClub3d(){
	temp = string.charAt(96);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardMerkClub3d = "Club3D";
	}
	else {
		VideocardMerkClub3d = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardMerkClub3d;
}
	
	
	

public static String VideocardMerkGigabyte(){
	temp = string.charAt(97);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardMerkGigabyte = "Gigabyte";
	}
	else {
		VideocardMerkGigabyte = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardMerkGigabyte;
}

public static String VideocardMerkSapphire(){
	temp = string.charAt(98);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardMerkSapphire = "Sapphire";
	}
	else {
		VideocardMerkSapphire = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardMerkSapphire;
}

public static String VideocardMerkMSI(){
	temp = string.charAt(99);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardMerkMSI = "MSI";
	}
	else {
		VideocardMerkMSI = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardMerkMSI;
}

public static String VideocardMerkGeenvoorkeur(){
	temp = string.charAt(100);
	//System.out.print(temp);
	if(temp == '1') {
		VideocardMerkGeenvoorkeur = "Geenvoorkeur";
	}
	else {
		VideocardMerkGeenvoorkeur = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return VideocardMerkGeenvoorkeur;
}
	
public static String VideocardTyeMemory(){
	temp = string.charAt(101);
	//System.out.print(temp);
	 if(temp == '1') {
		 VideocardTyeMemory = "DDR2";
		}
	 else if (temp == '2'){
		 VideocardTyeMemory = "DDR3";
	 }
	 else if (temp == '3'){
		 VideocardTyeMemory = "GDDR5";
	 }
	  else if (temp == '4'){
		  VideocardTyeMemory = "Geen voorkeur";
	 }
	  
	 return VideocardTyeMemory;
	 }

public static String VideocardHdmi(){
	temp = string.charAt(102);
	//System.out.print(temp);
	 if(temp == '1') {
		 VideocardHdmi = "0";
		}
	 else if (temp == '2'){
		 VideocardHdmi = "1";
	 }
	 else if (temp == '3'){
		 VideocardHdmi = "2";
	 }
	 else if (temp == '0'){
		 VideocardHdmi = "0";
	 }
	 return VideocardHdmi;
	 }


public static String VideocardVga(){
	temp = string.charAt(103);
	//System.out.print(temp);
	   if(temp == '1') {
		   VideocardVga = "Ja";
		}
	   else if (temp == '2'){
		   VideocardVga = "Nee";
	   }
	return VideocardVga;


}


public static String VideocardMemorybus(){
	temp = string.charAt(104);
	//System.out.print(temp);
	   if(temp == '1') {
		   VideocardMemorybus = "64bit";
		}
	   else if (temp == '2'){
		   VideocardMemorybus = "128bit";
	   }
	   else if (temp == '3'){
		   VideocardMemorybus = "192bit";
	   }
	    else if (temp == '4'){
	    	VideocardMemorybus = "256bit";
	   }
	    else if (temp == '5'){
	    	VideocardMemorybus = "384bit";
	    }
	    else if (temp == '6'){
	    	VideocardMemorybus = "512bit";
	   }
	    else if (temp == '7'){
	    	VideocardMemorybus = "Geen voorkeur";
	   }
	return VideocardMemorybus;
}

public static String VideocardDVIIConnection(){
	temp = string.charAt(105);
	//System.out.print(temp);
	   if(temp == '1') {
		   VideocardDVIIConnection = "Ja";
		}
	   else if (temp == '2'){
		   VideocardDVIIConnection = "Nee";
	   }
	   else if (temp == '0'){
		   VideocardDVIIConnection = "0";
	   }
	return VideocardDVIIConnection;

}


public static String VideocardDVIDConnection(){
	temp = string.charAt(106);
	//System.out.print(temp);
	   if(temp == '1') {
		   VideocardDVIDConnection = "0";
		}
	   else if (temp == '2'){
		   VideocardDVIDConnection = "1";
	   }
	   else if (temp == '3'){
		   VideocardDVIDConnection = "2";
	   }
	   else if (temp == '0'){
		   VideocardDVIDConnection = "0";
	   }

return VideocardDVIDConnection;
}



public static String VideocardPrijsMin(){
	temp = string.charAt(107);
	//System.out.print(temp);
	   if(temp == '1') {
		   VideocardPrijsMin = "0";
		}
	   else if (temp == '2'){
		   VideocardPrijsMin = "100";
	   }
	   else if (temp == '3'){
		   VideocardPrijsMin = "200";
	   }	
	   else if (temp == '4'){
		   VideocardPrijsMin = "300";
	   }
	   else if (temp == '5'){
		   VideocardPrijsMin = "400";
	   }	
	   else if (temp == '6'){
		   VideocardPrijsMin = "500";
	   }
	   else if (temp == '7'){
		   VideocardPrijsMin = "600";
	   }	
return VideocardPrijsMin;
}

public static String VideocardPrijsMax(){
	temp = string.charAt(108);
	   if(temp == '1') {
		   VideocardPrijsMax = "0";
		}
	   else if (temp == '2'){
		   VideocardPrijsMax = "100";
	   }
	   else if (temp == '3'){
		   VideocardPrijsMax = "200";
	   }	
	   else if (temp == '4'){
		   VideocardPrijsMax = "300";
	   }
	   else if (temp == '5'){
		   VideocardPrijsMax = "400";
	   }	
	   else if (temp == '6'){
		   VideocardPrijsMax = "500";
	   }
	   else if (temp == '7'){
		   VideocardPrijsMax = "600";
	   }	
return VideocardPrijsMax;
}


public static String VideocardMemorryMBMin(){
	temp = string.charAt(109);  
	if(temp == '1') {
		VideocardMemorryMBMin = "500 MB";
		}
	   else if (temp == '2'){
		   VideocardMemorryMBMin = "1013 MB";
	   }
	   else if (temp == '3'){
		   VideocardMemorryMBMin = "1526 MB";
	   }	
	   else if (temp == '4'){
		   VideocardMemorryMBMin = "2039 MB ";
	   }
	   else if (temp == '5'){
		   VideocardMemorryMBMin = "2552 MB";
	   }	
	   else if (temp == '6'){
		   VideocardMemorryMBMin = "3065 MB";
	   }
	   else if (temp == '7'){
		   VideocardMemorryMBMin = "3578 MB";
	   }
	   else if (temp == '8'){
		   VideocardMemorryMBMin = "4091 MB";
	   }
	   else if (temp == '9'){
		   VideocardMemorryMBMin = "4604 MB";
	   }
	   else if (temp == 'a'){
		   VideocardMemorryMBMin = "5117 MB";
	   }
	   else if (temp == 'b'){
		   VideocardMemorryMBMin = "5630 MB";
	   }
	   else if (temp == 'c'){
		   VideocardPrijsMax = "6143 MB";
	   }
	   else if (temp == 'd'){
		   VideocardMemorryMBMin = "6656 MB";
	   }
	
	   else if (temp == 'e'){
		   VideocardMemorryMBMin = "7169 MB";
	   }
	
	   else if (temp == 'f'){
		   VideocardMemorryMBMin = "7682 MB";
	   }
	
	   else if (temp == 'g'){
		   VideocardMemorryMBMin = "8195 MB";
	   }
	
	return VideocardMemorryMBMin;
	

}
public static String VideocardMemorryMBMax(){
	temp = string.charAt(110);
	  if(temp == '1') {
		  VideocardMemorryMBMax = "500 MB";
		}
	   else if (temp == '2'){
		   VideocardMemorryMBMax = "1013 MB";
	   }
	   else if (temp == '3'){
		   VideocardMemorryMBMax = "1526 MB";
	   }	
	   else if (temp == '4'){
		   VideocardMemorryMBMax = "2039 MB";
	   }
	   else if (temp == '5'){
		   VideocardMemorryMBMax = "2552 MB";
	   }	
	   else if (temp == '6'){
		   VideocardMemorryMBMax = "3065 MB";
	   }
	   else if (temp == '7'){
		   VideocardMemorryMBMax = "3578 MB";
	   }
	   else if (temp == '8'){
		   VideocardMemorryMBMax = "4091 MB";
	   }
	   else if (temp == '9'){
		   VideocardMemorryMBMax = "4604 MB";
	   }
	   else if (temp == 'a'){
		   VideocardMemorryMBMax = "5117 MB";
	   }
	   else if (temp == 'b'){
		   VideocardMemorryMBMax = "5630 MB";
	   }
	   else if (temp == 'c'){
		   VideocardMemorryMBMax = "6143 MB";
	   }
	   else if (temp == 'd'){
		   VideocardMemorryMBMax = "6656 MB";
	   }
	
	   else if (temp == 'e'){
		   VideocardMemorryMBMax = "7169 MB";
	   }
	
	   else if (temp == 'f'){
		   VideocardMemorryMBMax = "7682 MB";
	   }
	
	   else if (temp == 'g'){
		   VideocardMemorryMBMax = "8195 MB";
	   }
	
	return VideocardMemorryMBMax;
	

}
    // 110
	// processor 
   // box = 111  112
   // box 113 114 115 116 
  // slider = 117 min 118 max
  // box = 119 120 121 122 123 124 125 126 127 
  // slider = 128 min 129 max 


public static String ProcessorMerkIntel() {
	temp = string.charAt(111);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorMerkIntel = "Intel";
	}
	else {
		ProcessorMerkIntel = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorMerkIntel;
}
	
	
public static String ProcessorMerkAMD() {
	temp = string.charAt(112);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorMerkAMD = "AMD";
	}
	else {
		ProcessorMerkAMD = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorMerkAMD;
}
	
	



public static String ProcessorcoresDualcore() {
	temp = string.charAt(113);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorcoresDualcore = "Dual core (2)Processor ";
	}
	else {
		ProcessorcoresDualcore = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorcoresDualcore;
}
	

public static String ProcessorcoresQuadcore() {
	temp = string.charAt(114);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorcoresQuadcore = "Quadcore(4)Processor";
	}
	else {
		ProcessorcoresQuadcore = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorcoresQuadcore;
}
	

public static String Processorcores6core() {
	temp = string.charAt(115);
	//System.out.print(temp);
	if(temp == '1') {
		Processorcores6core = " 6-Core Processor";
	}
	else {
		Processorcores6core = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return Processorcores6core;
}
	

public static String Processorcores8core() {
	temp = string.charAt(116);
	//System.out.print(temp);
	if(temp == '1') {
		Processorcores8core = "8-CoreProcessor";
	}
	else {
		Processorcores8core = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return Processorcores8core;
}
	


public static String ProcessorPPrijsMin() {
	temp = string.charAt(117);
	//System.out.print(temp);
	   if(temp == '1') {
		   ProcessorPPrijsMin = "0";
		}
	   else if (temp == '2'){
		   ProcessorPPrijsMin = "100";
	   }
	   else if (temp == '3'){
		   ProcessorPPrijsMin = "200";
	   }
	    else if (temp == '4'){
	    	ProcessorPPrijsMin = "300";
	   }
	    else if (temp == '5'){
	    	ProcessorPPrijsMin = "400";
	    }
	    else if (temp == '6'){
	    	ProcessorPPrijsMin = "500";
	   }
	    else if (temp == '7'){
	    	ProcessorPPrijsMin = "600";
	   }
	    else if (temp == '8'){
	    	ProcessorPPrijsMin = "700";
	   }
	    else if (temp == '9'){
	    	ProcessorPPrijsMin = "800";
	   }
	    else if (temp == 'a'){
	    	ProcessorPPrijsMin = "900";
	   }
	    else if (temp == 'b'){
	    	ProcessorPPrijsMin = "1000";
	   }
	   return ProcessorPPrijsMin;
	}


public static String ProcessorPPrijsMax() {
	temp = string.charAt(118);
	//System.out.print(temp);
	   if(temp == '1') {
		   ProcessorPPrijsMax = "0";
		}
	   else if (temp == '2'){
		   ProcessorPPrijsMax = "100";
	   }
	   else if (temp == '3'){
		   ProcessorPPrijsMax = "200";
	   }
	    else if (temp == '4'){
	    	ProcessorPPrijsMax = "300";
	   }
	    else if (temp == '5'){
	    	ProcessorPPrijsMax = "400";
	    }
	    else if (temp == '6'){
	    	ProcessorPPrijsMax = "500";
	   }
	    else if (temp == '7'){
	    	ProcessorPPrijsMax = "600";
	   }
	    else if (temp == '8'){
	    	ProcessorPPrijsMax = "700";
	   }
	    else if (temp == '9'){
	    	ProcessorPPrijsMax = "800";
	   }
	    else if (temp == 'a'){
	    	ProcessorPPrijsMax = "900";
	   }
	    else if (temp == 'b'){
	    	ProcessorPPrijsMax = "1000";
	   }
	   return ProcessorPPrijsMax;
	}


 



public static String ProcessorSerieA10() {
	temp = string.charAt(119);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSerieA10 = "A10";
	}
	else {
		ProcessorSerieA10 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSerieA10;
}
	

public static String ProcessorSerieA6() {
	temp = string.charAt(120);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSerieA6 = "A6";
	}
	else {
		ProcessorSerieA6 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSerieA6;
}
	

public static String ProcessorSerieA8() {
	temp = string.charAt(121);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSerieA8 = "A8";
	}
	else {
		ProcessorSerieA8 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSerieA8;
}

public static String ProcessorSeriecorei3() {
	temp = string.charAt(122);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSeriecorei3 = "Core i3";
	}
	else {
		ProcessorSeriecorei3 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSeriecorei3;
}

public static String ProcessorSeriecorei5() {
	temp = string.charAt(123);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSeriecorei5 = "Core i5";
	}
	else {
		ProcessorSeriecorei5 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSeriecorei5;
}

public static String ProcessorSeriecorei7() {
	temp = string.charAt(124);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSeriecorei7 = "Core i7";
	}
	else {
		ProcessorSeriecorei7 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSeriecorei7;
}

public static String ProcessorSerieFX() {
	temp = string.charAt(125);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSerieFX = "(FX)";
	}
	else {
		ProcessorSerieFX = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSerieFX;
}

public static String ProcessorSeriepentium() {
	temp = string.charAt(126);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSeriepentium = "Pentium ";
	}
	else {
		ProcessorSeriepentium = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSeriepentium;
}

public static String ProcessorSeriesempron() {
	temp = string.charAt(127);
	//System.out.print(temp);
	if(temp == '1') {
		ProcessorSeriesempron = "Sempron";
	}
	else {
		ProcessorSeriesempron = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ProcessorSeriesempron;
}






public static String ProcessorclockingMin() {
	temp = string.charAt(128);
	//System.out.print(temp);
	   if(temp == '1') {
		   ProcessorclockingMin = "2900";
		}
	   else if (temp == '2'){
		   ProcessorclockingMin = "3050";
	   }
	   else if (temp == '3'){
		   ProcessorclockingMin = "3200";
	   }
	    else if (temp == '4'){
	    	ProcessorclockingMin = "3350";
	   }
	    else if (temp == '5'){
	    	ProcessorclockingMin = "3500";
	    }
	    else if (temp == '6'){
	    	ProcessorclockingMin = "360";
	   }
	    else if (temp == '7'){
	    	ProcessorclockingMin = "3800";
	   }
	    else if (temp == '8'){
	    	ProcessorclockingMin = "3950";
	   }
	    else if (temp == '9'){
	    	ProcessorclockingMin = "4100";
	   }
	    else if (temp == 'a'){
	    	ProcessorclockingMin = "4250";
	   }
	    else if (temp == 'b'){
	    	ProcessorclockingMin = "4400";
	   }
	    else if (temp == 'c'){
	    	ProcessorclockingMin = "4450";
	   }
	    else if (temp == 'd'){
	    	ProcessorclockingMin = "4700";
	   }
	   return ProcessorclockingMin;
	}


public static String ProcessorclockingMax() {
	temp = string.charAt(129);
	//System.out.print(temp);
	   if(temp == '1') {
		   ProcessorclockingMax = "2900";
		}
	   else if (temp == '2'){
		   ProcessorclockingMax = "3050";
	   }
	   else if (temp == '3'){
		   ProcessorclockingMax = "3200";
	   }
	    else if (temp == '4'){
	    	ProcessorclockingMax = "3350";
	   }
	    else if (temp == '5'){
	    	ProcessorclockingMax = "3500";
	    }
	    else if (temp == '6'){
	    	ProcessorclockingMax = "3600";
	   }
	    else if (temp == '7'){
	    	ProcessorclockingMax = "3800";
	   }
	    else if (temp == '8'){
	    	ProcessorclockingMax = "3950";
	   }
	    else if (temp == '9'){
	    	ProcessorclockingMax = "4100";
	   }
	    else if (temp == 'a'){
	    	ProcessorclockingMax = "4250";
	   }
	    else if (temp == 'b'){
	    	ProcessorclockingMax = "4400";
	   }
	    else if (temp == 'c'){
	    	ProcessorclockingMax = "4450";
	   }
	    else if (temp == 'd'){
	    	ProcessorclockingMin = "4700";
	   }
	   return ProcessorclockingMax;
	}




/// intern geheugen 
//box = 130 131 132  133 134 135 
//box = 136 137 138 139 140 141 
//radio = 142 
//radio = 143 
//box = 144 145 146 147
//box = 148 149 150 151
//radio = 152
//sliderr = 153 min  154 max 

public static String internalmemoryCorsair() {
	temp = string.charAt(130);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemoryCorsair = "Corsair";
	}
	else {
		internalmemoryCorsair = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemoryCorsair;
}


public static String internalmemoryCrusial() {
	temp = string.charAt(131);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemoryCrusial = "Crucial";
	}
	else {
		internalmemoryCrusial = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemoryCrusial;
}
	


public static String internalmemorykingston() {
     temp = string.charAt(132);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemorykingston = "Kingston";
	}
	else {
		internalmemorykingston = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemorykingston;
}
	



public static String internalmemoryqnap(){
    temp = string.charAt(133);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemoryqnap = "QNAP";
	}
	else {
		internalmemoryqnap = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemoryqnap;
}
	
public static String internalmemorysynology() {
    temp = string.charAt(134);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemorysynology = "Synology";
	}
	else {
		internalmemorysynology = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemorysynology;
}
	

public static String internalmemorygeenvoorkeur() {
    temp = string.charAt(135);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemorygeenvoorkeur = "Geen voorkeur";
	}
	else {
		internalmemorygeenvoorkeur = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemorygeenvoorkeur;
}
	




public static String internalmemoryRAM1GB() {
    temp = string.charAt(136);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemoryRAM1GB = "1 GB";
	}
	else {
		internalmemoryRAM1GB = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemoryRAM1GB;
}
	


public static String internalmemoryRAM2GB() {
	   temp = string.charAt(137);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemoryRAM2GB = "2 GB";
		}
		else {
			internalmemoryRAM2GB = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemoryRAM2GB;
	}


public static String internalmemoryRAM4GB() {
	   temp = string.charAt(138);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemoryRAM4GB = "4 GB";
		}
		else {
			internalmemoryRAM4GB = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemoryRAM4GB;
	}


public static String internalmemoryRAM8GB() {
	   temp = string.charAt(139);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemoryRAM8GB = "8 GB";
		}
		else {
			internalmemoryRAM8GB = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemoryRAM8GB;
	}


public static String internalmemoryRAM16GB() {
	   temp = string.charAt(140);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemoryRAM16GB = "16 GB";
		}
		else {
			internalmemoryRAM16GB = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemoryRAM16GB;
	}


public static String internalmemoryRAM32GB() {
	   temp = string.charAt(141);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemoryRAM32GB = "32 GB";
		}
		else {
			internalmemoryRAM32GB = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemorygeenvoorkeur;
	}



public static String internalmemoryclocking() {
	temp = string.charAt(142);
	//System.out.print(temp);
	   if(temp == '1') {
		   internalmemoryclocking = "667 MHz";
		}
	   else if (temp == '2'){
		   internalmemoryclocking = "800 MHz";
	   }
	   else if (temp == '3'){
		   internalmemoryclocking = "1333 MHz";
	   }
	    else if (temp == '4'){
	    	internalmemoryclocking = "1600 MHz";
	   }
 return internalmemoryclocking;
}

public static String internalmemoryGaming() {
	temp = string.charAt(143);
	//System.out.print(temp);
	   if(temp == '1') {
		   internalmemoryGaming = "Ja";
		}
	   else if (temp == '2'){
		   internalmemoryGaming = "Nee";
	   }
	return internalmemoryGaming;

}



public static String internalmemorysuitableforDesktop() {
	 temp = string.charAt(144);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemorysuitableforDesktop = "Desktop";
		}
		else {
			internalmemorysuitableforDesktop = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemorysuitableforDesktop;
	}



public static String internalmemorysuitableforLaptop() {
	 temp = string.charAt(145);
		//System.out.print(temp);
		if(temp == '1') {
			internalmemorysuitableforLaptop = "Laptop";
		}
		else {
			internalmemorysuitableforLaptop = "chooseplease";
		}
		//System.out.print(cpu_p4);
		return internalmemorysuitableforLaptop;
	}


public static String internalmemorysuitableforNas() {
	temp = string.charAt(146);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemorysuitableforNas = "NAS";
	}
	else {
		internalmemorysuitableforNas = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemorysuitableforNas;
}

public static String internalmemorysuitableforMac() {
	temp = string.charAt(147);
	//System.out.print(temp);
	if(temp == '1') {
		internalmemorysuitableforMac = "Mac";
	}
	else {
		internalmemorysuitableforMac = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return internalmemorysuitableforMac;
}


public static String internalmemoryType() {
	temp = string.charAt(148);
	//System.out.print(temp);
	   if(temp == '1') {
		   internalmemoryType = "DDR2";
		}
	   else if (temp == '2'){
		   internalmemoryType = "DDR3";
	   }
	   else if (temp == '3'){
		   internalmemoryType = "DIMM DDR3";
	   }
	    else if (temp == '4'){
	    	internalmemoryType = "DIMM DDR4";
	   }
 return internalmemoryType;
}

public static String internalmemoryChannel() {
	temp = string.charAt(149);
	//System.out.print(temp);
	   if(temp == '1') {
		   internalmemoryChannel = "(Single Channel)";
		}
	   else if (temp == '2'){
		   internalmemoryChannel = "(Dual Channel)";
	   }
	   else if (temp == '3'){
		   internalmemoryChannel = "(Quad Channel)";
}
	return internalmemoryChannel;
}

public static String internalmemoryPrijsMin() {
	temp = string.charAt(150);
	//System.out.print(temp);
	   if(temp == '1') {
		   internalmemoryPrijsMin = "0";
		}
	   else if (temp == '2'){
		   internalmemoryPrijsMin = "50";
	   }
	   else if (temp == '3'){
		   internalmemoryPrijsMin = "100";
	   }
	   else if (temp == '4'){
		   internalmemoryPrijsMin = "150";
	   }
	   else if (temp == '5'){
		   internalmemoryPrijsMin = "200";
	   }
	   else if (temp == '6'){
		   internalmemoryPrijsMin = "250";
	   }
	   else if (temp == '7'){
		   internalmemoryPrijsMin = "300";
	   }
	   else if (temp == '8'){
		   internalmemoryPrijsMin = "350";
	   }
	   else if (temp == '9'){
		   internalmemoryPrijsMin = "400";
	   }
	   else if (temp == 'a'){
		   internalmemoryPrijsMin = "450";
	   }
	   else if (temp == 'b'){
		   internalmemoryPrijsMin = "500";
	   }
 return internalmemoryPrijsMin;
}


public static String internalmemoryPrijsMax() {
	temp = string.charAt(151);
	//System.out.print(temp);
	   if(temp == '1') {
		   internalmemoryPrijsMax = "0";
		}
	   else if (temp == '2'){
		   internalmemoryPrijsMax = "50";
	   }
	   else if (temp == '3'){
		   internalmemoryPrijsMax = "100";
	   }
	   else if (temp == '4'){
		   internalmemoryPrijsMax = "150";
	   }
	   else if (temp == '5'){
		   internalmemoryPrijsMax = "200";
	   }
	   else if (temp == '6'){
		   internalmemoryPrijsMax = "250";
	   }
	   else if (temp == '7'){
		   internalmemoryPrijsMax = "300";
	   }
	   else if (temp == '8'){
		   internalmemoryPrijsMax = "350";
	   }
	   else if (temp == '9'){
		   internalmemoryPrijsMax = "400";
	   }
	   else if (temp == 'a'){
		   internalmemoryPrijsMax = "450";
	   }
	   else if (temp == 'b'){
		   internalmemoryPrijsMax = "500";
	   }
 return internalmemoryPrijsMax ;
}

//intern geheugen 
//box = 130 131 132  133 134 135 
//box = 136 137 138 139 140 141
//radio = 142
//radio = 143
//box = 144 145 146 147
//radio= 148
//radio = 149
//sliderr = 150 min 151 max 


// 151
//moederbord
//box= 152 153 154 
// radio= 155
//radio=156
//radio=157
//radio= 158
//radio=159
//radio=160
// slider= 161 min 162 max
// slider= 163 min 164 max
// radio= 165
// radio= 166
//box= 167 168 169 170 171 172
//radio= 173 
//radio= 174
// radio= 175
// slider= 176 min 177 max
// slider= 178 min 179 max

public static String motherboardMerkAsrock() {
	temp = string.charAt(152);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardMerkAsrock = "Asrock";
	}
	else {
		motherboardMerkAsrock = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardMerkAsrock;
}

public static String motherboardMerkAsus() {
	temp = string.charAt(153);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardMerkAsus = "Asus";
	}
	else {
		motherboardMerkAsus = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardMerkAsus;
}
public static String motherboardMerkMSI() {
	temp = string.charAt(154);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardMerkMSI = "MSI";
	}
	else {
		motherboardMerkMSI = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardMerkMSI;
}





public static String motherboardformaat() {
	temp = string.charAt(155);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardformaat = "ATX";
		}
	   else if (temp == '2'){
		   motherboardformaat = "E-ATX";
	   }
	   else if (temp == '3'){
		   motherboardformaat = "Micro-ATX";
	   }
	   else if (temp == '4'){
		   motherboardformaat = "Mini-ITX";
	   }
	   else if (temp == '5'){
		   motherboardformaat = "XL-ATX";
	   }
	   return motherboardformaat;
}




public static String motherboardWifi() {
	temp = string.charAt(156);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardWifi = "Ja";
		}
	   else if (temp == '2'){
		   motherboardWifi = "Nee";
	   }
   return motherboardWifi;
}
public static String motherboardmemoryslots() {
	temp = string.charAt(157);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardmemoryslots = "2";
		}
	   else if (temp == '2'){
		   motherboardmemoryslots = "4";
	   }
	   else if (temp == '3'){
		   motherboardmemoryslots = "8";
	   }
	 return  motherboardmemoryslots;
}

public static String motherboardHDMI() {
	temp = string.charAt(158);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardHDMI = "Ja";
		}
	   else if (temp == '2'){
		   motherboardHDMI = "Nee";
	   }
   return motherboardHDMI;
}

public static String motherboardVga() {
	temp = string.charAt(159);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardVga = "Ja";
		}
	   else if (temp == '2'){
		   motherboardVga = "Nee";
	   }
return motherboardVga;
}
	
public static String motherboardDisplayport() {
	temp = string.charAt(160);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardDisplayport = "Ja";
		}
	   else if (temp == '2'){
		   motherboardDisplayport = "Nee";
	   }
return motherboardDisplayport;
}

public static String motherboardPrijsMin() {
	temp = string.charAt(161);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardPrijsMin = "0";
		}
	   else if (temp == '2'){
		   motherboardPrijsMin = "50";
	   }
	   else if (temp == '3'){
		   motherboardPrijsMin = "100";
	   }
	   else if (temp == '4'){
		   motherboardPrijsMin = "150";
	   }
	   else if (temp == '5'){
		   motherboardPrijsMin = "200";
	   }
	   else if (temp == '6'){
		   motherboardPrijsMin = "250";
	   }
	   else if (temp == '7'){
		   motherboardPrijsMin = "300";
	   }
	   else if (temp == '8'){
		   motherboardPrijsMin = "350";
	   }
	   else if (temp == '9'){
		   motherboardPrijsMin = "400";
	   }
	   else if (temp == 'a'){
		   motherboardPrijsMin = "450";
	   }
	   else if (temp == 'b'){
		   motherboardPrijsMin = "500";
	   }
	   return motherboardPrijsMin;
}
	

public static String motherboardPrijsMax() {
	temp = string.charAt(162);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardPrijsMax = "0";
		}
	   else if (temp == '2'){
		   motherboardPrijsMax = "50";
	   }
	   else if (temp == '3'){
		   motherboardPrijsMax = "100";
	   }
	   else if (temp == '4'){
		   motherboardPrijsMax = "150";
	   }
	   else if (temp == '5'){
		   motherboardPrijsMax = "200";
	   }
	   else if (temp == '6'){
		   motherboardPrijsMax = "250";
	   }
	   else if (temp == '7'){
		   motherboardPrijsMax = "300";
	   }
	   else if (temp == '8'){
		   motherboardPrijsMax = "350";
	   }
	   else if (temp == '9'){
		   motherboardPrijsMax = "400";
	   }
	   else if (temp == 'a'){
		   motherboardPrijsMax = "450";
	   }
	   else if (temp == 'b'){
		   motherboardPrijsMax = "500";
	   }
	   return motherboardPrijsMax;
}



public static String motherboardUsbPort() {
	temp = string.charAt(163);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardUsbPort = "0";
		}
	   else if (temp == '2'){
		   motherboardUsbPort = "1";
	   }
	   else if (temp == '3'){
		   motherboardUsbPort = "2";
	   }
	   else if (temp == '4'){
		   motherboardUsbPort = "3";
	   }
	   else if (temp == '5'){
		   motherboardUsbPort = "4";
	   }
	   else if (temp == '6'){
		   motherboardUsbPort = "5";
	   }
	
	   else if (temp == '7'){
		   motherboardUsbPort = "6";
	   }
	
	   else if (temp == '8'){
		   motherboardUsbPort = "7";
	   }
	
	   else if (temp == '9'){
		   motherboardUsbPort = "8";
	   }
	   else if (temp == 'a'){
		   motherboardUsbPort = "9";
	   }
	   else if (temp == 'b'){
		   motherboardUsbPort = "10";
	   }
	   else if (temp == 'c'){
		   motherboardUsbPort = "11";
	   }
	
	   else if (temp == 'd'){
		   motherboardUsbPort = "12";
	   }
	
	   else if (temp == 'e'){
		   motherboardUsbPort = "13";
	   }
	   else if (temp == 'f'){
		   motherboardUsbPort = "14";
	   }
	return motherboardUsbPort;
	
}

public static String motherboardEthernetport() {
	temp = string.charAt(164);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardEthernetport = "1";
		}
	   else if (temp == '2'){
		   motherboardEthernetport = "2";
	   }
return motherboardEthernetport;
}
	

public static String motherboardDVI() {
	temp = string.charAt(165);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardDVI = "Ja";
		}
	   else if (temp == '2'){
		   motherboardDVI = "Nee";
	   }
return motherboardDVI;
}
	


public static String motherboardRAID0() {
	temp = string.charAt(166);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardRAID0 = "RAID-0";
	}
	else {
		motherboardRAID0 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardRAID0;
}


public static String motherboardRAID1() {
	temp = string.charAt(167);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardRAID1 = "RAID-1";
	}
	else {
		motherboardRAID1 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardRAID1;
}


public static String motherboardRAID5() {
	temp = string.charAt(168);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardRAID5 = "RAID-5";
	}
	else {
		motherboardRAID5 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardRAID5;
}


public static String motherboardRAID10() {
	temp = string.charAt(169);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardRAID10 = "RAID-10";
	}
	else {
		motherboardRAID10 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardRAID10;
}


public static String motherboardJBOD() {
	temp = string.charAt(170);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardJBOD = "JBOD";
	}
	else {
		motherboardJBOD = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardJBOD;
}


public static String motherboardGeen() {
	temp = string.charAt(171);
	//System.out.print(temp);
	if(temp == '1') {
		motherboardGeen = "Geen";
	}
	else {
		motherboardGeen = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return motherboardGeen;
}



public static String motherboardAudiChannel() {
	temp = string.charAt(172);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardAudiChannel = "5.1";
		}
	   else if (temp == '2'){
		   motherboardAudiChannel = "7.1";
	   }
	   return motherboardAudiChannel;
}
public static String motherboardMemorytype() {
	temp = string.charAt(173);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardMemorytype = "DDR3";
		}
	   else if (temp == '2'){
		   motherboardMemorytype = "DIMM";
	   }
	   else if (temp == '3'){
		   motherboardMemorytype = "DIMM DDR4";
	   }
	   return motherboardMemorytype;
}
public static String motherboardmSATAConnection() {
	temp = string.charAt(174);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardmSATAConnection = "Ja";
		}
	   else if (temp == '2'){
		   motherboardmSATAConnection = "Nee";
	   }
	   else if (temp == '0'){
		   motherboardmSATAConnection = "0";
	   }
	   
	   return motherboardmSATAConnection;
	   
}
	   
	   
	   
	   
public static String motherboardmSATA300Connection() {
		temp = string.charAt(175);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardmSATA300Connection = "0";
		}
	   else if (temp == '2'){
		   motherboardmSATA300Connection = "1";
	   }
	   else if (temp == '3'){
		   motherboardmSATA300Connection = "2";
	   }
	   else if (temp == '4'){
		   motherboardmSATA300Connection = "3";
	   }
	   else if (temp == '5'){
		   motherboardmSATA300Connection = "4";
	   }
	   else if (temp == '6'){
		   motherboardmSATA300Connection = "5";
	   }
	
	   else if (temp == '7'){
		   motherboardmSATA300Connection = "6";
	   }
	   else if (temp == '0'){
		   motherboardmSATA300Connection = "0";
	   }
	
	   return motherboardmSATA300Connection;
}

public static String motherboardmSATA600Connection() {
		temp = string.charAt(176);
	//System.out.print(temp);
	   if(temp == '1') {
		   motherboardmSATA600Connection = "0";
		}
	   else if (temp == '2'){
		   motherboardmSATA600Connection = "1";
	   }
	   else if (temp == '3'){
		   motherboardmSATA600Connection = "2";
	   }
	   else if (temp == '4'){
		   motherboardmSATA600Connection = "3";
	   }
	   else if (temp == '5'){
		   motherboardmSATA600Connection = "4";
	   }
	   else if (temp == '6'){
		   motherboardmSATA600Connection = "5";
	   }
	
	   else if (temp == '7'){
		   motherboardmSATA600Connection = "6";
	   }
	   else if (temp == '8'){
		   motherboardmSATA600Connection = "7";
	   }
	   else if (temp == '9'){
		   motherboardmSATA600Connection = "8";
	  }
	   else if (temp == 'a'){
		   motherboardmSATA600Connection = "9";
	  }
	   else if (temp == 'b'){
		   motherboardmSATA600Connection = "10";
	  }
	   else if (temp == '0'){
		   motherboardmSATA600Connection = "0";
	  }
	   return motherboardmSATA600Connection;
}

//176
//casing 
// box = 177 178 179 180 181 182 
//radio = 183
// radio= 184
//radio= 185
//radio=186
//radio=187
//radio=188
//radio=189
//radio=190
// slider= 191 min 192 max
// slider= 193 min 194 max
// radio= 195
// radio= 196 
// box= 197 198 199 
// box= 200 201 202
// radio= 203 
// radio = 204
// slider= 205 min 206 max
//slider= 207 min  208 max
// slider= 209 min 210 max


public static String casingMerkAntec() {
	temp = string.charAt(177);
	//System.out.print(temp);
	if(temp == '1') {
		casingMerkAntec = "Antec";
	}
	else {
		casingMerkAntec = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingMerkAntec;
}





public static String casingMerkCoolerMaster() {
	temp = string.charAt(178);
	//System.out.print(temp);
	if(temp == '1') {
		casingMerkCoolerMaster = "CoolerMaster";
	}
	else {
		casingMerkCoolerMaster = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingMerkCoolerMaster;
}

public static String casingMerkCorsair() {
	temp = string.charAt(179);
	//System.out.print(temp);
	if(temp == '1') {
		casingMerkCorsair = "Corsair";
	}
	else {
		casingMerkCorsair = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingMerkCorsair;
}

public static String casingMerkFractalDesign() {
	temp = string.charAt(180);
	//System.out.print(temp);
	if(temp == '1') {
		casingMerkFractalDesign = "FractalDesign";
	}
	else {
		casingMerkFractalDesign = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingMerkFractalDesign;
}

public static String casingMerkSilverstone() {
	temp = string.charAt(181);
	//System.out.print(temp);
	if(temp == '1') {
		casingMerkSilverstone = "Silverstone";
	}
	else {
		casingMerkSilverstone = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingMerkSilverstone;
}

public static String casingMerGeenvoorkeur() {
	temp = string.charAt(182);
	//System.out.print(temp);
	if(temp == '1') {
		casingMerGeenvoorkeur = "Geen voorkeur";
	}
	else {
		casingMerGeenvoorkeur = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingMerGeenvoorkeur;
}





public static String casingComputerModel() {
	temp = string.charAt(183);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingComputerModel = "Cube";
		}
	   else if (temp == '2'){
		   casingComputerModel = "FullTower";
	   }
	   else if (temp == '3'){
		   casingComputerModel = "HTPC";
	   }
	   else if (temp == '4'){
		   casingComputerModel = "Miditower";
	   }
	   else if (temp == '5'){
		   casingComputerModel = "MiniTower";
	   }
	   return casingComputerModel;
}
public static String casingfanController() {
	temp = string.charAt(184);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingfanController = "Ja";
		}
	   else if (temp == '2'){
		   casingfanController = "Nee";
	   }
	   return casingfanController;
}
	 

public static String casingdustfilter() {
	temp = string.charAt(185);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingdustfilter = "Ja";
		}
	   else if (temp == '2'){
		   casingdustfilter = "Nee";
	   }
	   return casingdustfilter;
}

public static String casingsupplywatercooling() {
	temp = string.charAt(186);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingsupplywatercooling = "Ja";
		}
	   else if (temp == '2'){
		   casingsupplywatercooling = "Nee";
	   }
	   else if (temp == '0'){
		   casingsupplywatercooling = "0";
	   }
	   return casingsupplywatercooling;
}

public static String casingLEDdisplay() {
	temp = string.charAt(187);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingLEDdisplay = "Ja";
		}
	   else if (temp == '2'){
		   casingLEDdisplay = "Nee";
	   }
	   else if (temp == '0'){
		   casingLEDdisplay = "0";
	   }
	   return casingLEDdisplay;
}

public static String casingnoiseReduction() {
	temp = string.charAt(188);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingnoiseReduction = "Ja";
		}
	   else if (temp == '2'){
		   casingnoiseReduction = "Nee";
	   }
	   return casingnoiseReduction;
}

public static String casingNoisereductionmats() {
	temp = string.charAt(189);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingNoisereductionmats = "Ja";
		}
	   else if (temp == '2'){
		   casingNoisereductionmats = "Nee";
	   }
	   return casingNoisereductionmats;
}

public static String casingpanelDoor() {
	temp = string.charAt(190);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingpanelDoor = "Ja";
		}
	   else if (temp == '2'){
		   casingpanelDoor = "Nee";
	   }
	   return casingpanelDoor;
}


public static String CasingPrijsMin() {
	temp = string.charAt(191);
	//System.out.print(temp);
	   if(temp == '1') {
		   CasingPrijsMin = "30";
		}
	   else if (temp == '2'){
		   CasingPrijsMin = "50";
	   }
	   else if (temp == '3'){
		   CasingPrijsMin = "70";
	   }
	   else if (temp == '4'){
		   CasingPrijsMin = "90";
	   }
	   else if (temp == '5'){
		   CasingPrijsMin = "110";
	   }
	   else if (temp == '6'){
		   CasingPrijsMin = "130";
	   }
	   else if (temp == '7'){
		   CasingPrijsMin = "150";
	   }
	   return CasingPrijsMin;
}
public static String CasingPrijsMax() {
	temp = string.charAt(192);
	//System.out.print(temp);
	   if(temp == '1') {
		   CasingPrijsMax = "30";
		}
	   else if (temp == '2'){
		   CasingPrijsMax = "50";
	   }
	   else if (temp == '3'){
		   CasingPrijsMax = "70";
	   }
	   else if (temp == '4'){
		   CasingPrijsMax = "90";
	   }
	   else if (temp == '5'){
		   CasingPrijsMax = "110";
	   }
	   else if (temp == '6'){
		   CasingPrijsMax = "130";
	   }
	   else if (temp == '7'){
		   CasingPrijsMax = "150";
	   }
	   return CasingPrijsMax;
}


public static String casingExpansionslotsMin(){
	temp = string.charAt(193);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingExpansionslotsMin = "2";
		}
	   else if (temp == '2'){
		   casingExpansionslotsMin = "3";
	   }
	   else if (temp == '3'){
		   casingExpansionslotsMin = "4";
	   }
	   else if (temp == '4'){
		   casingExpansionslotsMin = "5";
	   }
	   else if (temp == '5'){
		   casingExpansionslotsMin = "6";
	   }
	   else if (temp == '6'){
		   casingExpansionslotsMin = "7";
	   }
	   else if (temp == '7'){
		   casingExpansionslotsMin = "8";
	   }
	   else if (temp == '8'){
		   casingExpansionslotsMin = "9";
	   }
	   else if (temp == '9'){
		   casingExpansionslotsMin = "10";
	   }
	   else if (temp == 'a'){
		   casingExpansionslotsMin = "11";
	   }
	   return casingExpansionslotsMin;
}
	



public static String casingExpansionslotsMax(){
	temp = string.charAt(194);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingExpansionslotsMax = "2";
		}
	   else if (temp == '2'){
		   casingExpansionslotsMax = "3";
	   }
	   else if (temp == '3'){
		   casingExpansionslotsMax = "4";
	   }
	   else if (temp == '4'){
		   casingExpansionslotsMax = "5";
	   }
	   else if (temp == '5'){
		   casingExpansionslotsMax = "6";
	   }
	   else if (temp == '6'){
		   casingExpansionslotsMax = "7";
	   }
	   else if (temp == '7'){
		   casingExpansionslotsMax = "8";
	   }
	   else if (temp == '8'){
		   casingExpansionslotsMax = "9";
	   }
	   else if (temp == '9'){
		   casingExpansionslotsMax = "10";
	   }
	   else if (temp == 'a'){
		   casingExpansionslotsMax = "11";
	   }
	   return casingExpansionslotsMax;
}
	

public static String CasingColor() {
	temp = string.charAt(195);
	//System.out.print(temp);
	   if(temp == '1') {
		   CasingColor = "Grijs";
		}
	   else if (temp == '2')
	   {CasingColor = "Oranje";
	   }
	   else if (temp == '3'){
		   CasingColor = "Wit";
	   }
	   else if (temp == '4'){
		   CasingColor = "Zwart";
	   }
	   else if (temp == '5'){
		   CasingColor = "Geen voorkeur";
	   }
	return CasingColor;
}

public static String CasingMatrial() {
	temp = string.charAt(196);
	//System.out.print(temp);
	   if(temp == '1') {
		   CasingMatrial = "Metaal";
		}
	   else if (temp == '2'){
		   CasingMatrial = "Kunststof";
	   }
	   else if (temp == '3'){
		   CasingMatrial = "Kunststof";
	   }
	   else if (temp == '4'){
		   CasingMatrial = "Metaal, Kunststof";
	   }
	   else if (temp == '5'){
		   CasingMatrial = "Metaal,Rubber,Kunststof,";
	   }
	   else if (temp == '6'){
		   CasingMatrial = "Metaal";
	   }
	   else if (temp == '7'){
		   CasingMatrial = "Geen voorkeur";
	   }
 return CasingMatrial;
}

public static String casingUsb20port0() {
	temp = string.charAt(197);
	//System.out.print(temp);
	if(temp == '1') {
		casingUsb20port0 = "0";
	}
	else {
		casingUsb20port0 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingUsb20port0;
}


public static String casingUsb20port1() {
	temp = string.charAt(198);
	//System.out.print(temp);
	if(temp == '1') {
		casingUsb20port1 = "1";
	}
	else {
		casingUsb20port1 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingUsb20port1;
}


public static String casingUsb20port2() {
	temp = string.charAt(199);
	//System.out.print(temp);
	if(temp == '1') {
		casingUsb20port2 = "2";
	}
	else {
		casingUsb20port2 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingUsb20port2;
}



public static String casingUsb30port0() {
	temp = string.charAt(200);
	//System.out.print(temp);
	if(temp == '1') {
		casingUsb30port0 = "0";
	}
	else {
		casingUsb30port0 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingUsb30port0;
}

public static String casingUsb30port1() {
	temp = string.charAt(201);
	//System.out.print(temp);
	if(temp == '1') {
		casingUsb30port1 = "1";
	}
	else {
		casingUsb30port1 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingUsb30port1;
}

public static String casingUsb30port2() {
	temp = string.charAt(202);
	//System.out.print(temp);
	if(temp == '1') {
		casingUsb30port2 = "2";
	}
	else {
		casingUsb30port2 = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return casingUsb30port2;
}


public static String casingFirewireport() {
	temp = string.charAt(203);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingFirewireport = "0";
		}
	   else if (temp == '2'){
		   casingFirewireport = "1";
	   }
	   else if (temp == '3'){
		   casingFirewireport = "Geen voorkeur";
	   }
	   return casingFirewireport;
}
public static String casingESATAConnection() {
	temp = string.charAt(204);
	//System.out.print(temp);
	   if(temp == '1') {
		   casingESATAConnection = "0";
		}
	   else if (temp == '2'){
		   casingESATAConnection = "1";
	   }
	   else if (temp == '3'){
		   casingESATAConnection = "Geen voorkeur";
	   }
	   return casingESATAConnection;
}

public static String casing25HDDSSDMin() {
	temp = string.charAt(205);
	//System.out.print(temp);
	   if(temp == '1') {
		   casing25HDDSSDMin = "0";
		}
	   else if (temp == '2'){
		   casing25HDDSSDMin = "1";
	   }
	   else if (temp == '3'){
		   casing25HDDSSDMin = "2";
	   }
	   else if (temp == '4'){
		   casing25HDDSSDMin = "3";
	   }
	   else if (temp == '5'){
		   casing25HDDSSDMin = "4";
	   }
	   else if (temp == '6'){
		   casing25HDDSSDMin = "5";
	   }
	
	   else if (temp == '7'){
		   casing25HDDSSDMin = "6";
	   }
	
	   else if (temp == '8'){
		   casing25HDDSSDMin = "7";
	   }
	
	   else if (temp == '9'){
		   casing25HDDSSDMin = "8";
	   }
	   else if (temp == 'a'){
		   casing25HDDSSDMin = "9";
	   }
	   else if (temp == 'b'){
		   casing25HDDSSDMin = "10";
	   }
	   else if (temp == 'c'){
		   casing25HDDSSDMin = "11";
	   }
	
	   else if (temp == 'd'){
		   casing25HDDSSDMin = "12";
	   }
	
	   else if (temp == 'e'){
		   casing25HDDSSDMin = "13";
	   }
	   else if (temp == 'f'){
		   casing25HDDSSDMin = "14";
	   }
	   else if (temp == 'g'){
		   casing25HDDSSDMin = "15";
	   }
	   else if (temp == 'h'){
		   casing25HDDSSDMin = "16";
	   }
	   else if (temp == 'i'){
		   casing25HDDSSDMin = "17";
	   }
	   else if (temp == 'j'){
		   casing25HDDSSDMin = "18";
	   }
	   
	return casing25HDDSSDMin;
	
}
	

public static String casing25HDDSSDMax() {
	temp = string.charAt(206);
	//System.out.print(temp);
	   if(temp == '1') {
		   casing25HDDSSDMax = "0";
		}
	   else if (temp == '2'){
		   casing25HDDSSDMax = "1";
	   }
	   else if (temp == '3'){
		   casing25HDDSSDMax = "2";
	   }
	   else if (temp == '4'){
		   casing25HDDSSDMax = "3";
	   }
	   else if (temp == '5'){
		   casing25HDDSSDMax = "4";
	   }
	   else if (temp == '6'){
		   casing25HDDSSDMax = "5";
	   }
	
	   else if (temp == '7'){
		   casing25HDDSSDMax = "6";
	   }
	
	   else if (temp == '8'){
		   casing25HDDSSDMax = "7";
	   }
	
	   else if (temp == '9'){
		   casing25HDDSSDMax = "8";
	   }
	   else if (temp == 'a'){
		   casing25HDDSSDMax = "9";
	   }
	   else if (temp == 'b'){
		   casing25HDDSSDMax = "10";
	   }
	   else if (temp == 'c'){
		   casing25HDDSSDMax = "11";
	   }
	
	   else if (temp == 'd'){
		   casing25HDDSSDMax = "12";
	   }
	
	   else if (temp == 'e'){
		   casing25HDDSSDMax = "13";
	   }
	   else if (temp == 'f'){
		   casing25HDDSSDMax = "14";
	   }
	   else if (temp == 'g'){
		   casing25HDDSSDMax = "15";
	   }
	   else if (temp == 'h'){
		   casing25HDDSSDMax = "16";
	   }
	   else if (temp == 'i'){
		   casing25HDDSSDMax = "17";
	   }
	   else if (temp == 'j'){
		   casing25HDDSSDMax = "18";
	   }
	   
	return casing25HDDSSDMax;
	
}




public static String casing35HDDMin() {
	temp = string.charAt(207);
	//System.out.print(temp);
	   if(temp == '1') {
		   casing35HDDMin = "2";
		}
	   else if (temp == '2'){
		   casing35HDDMin = "3";
	   }
	   else if (temp == '3'){
		   casing35HDDMin = "4";
	   }
	   else if (temp == '4'){
		   casing35HDDMin = "5";
	   }
	   else if (temp == '5'){
		   casing35HDDMin = "6";
	   }
	   else if (temp == '6'){
		   casing35HDDMin = "7";
	   }
	
	   else if (temp == '7'){
		   casing35HDDMin = "8";
	   }
	
	   else if (temp == '8'){
		   casing35HDDMin = "9";
	   }
	
	   else if (temp == '9'){
		   casing35HDDMin = "10";
	   }
	   else if (temp == 'a'){
		   casing35HDDMin = "11";
	   }
	   else if (temp == 'b'){
		   casing35HDDMin = "12";
	   }
	   else if (temp == 'c'){
		   casing35HDDMin = "13";
	   }
	   return casing35HDDMin;
}
public static String casing35HDDMax() {
	temp = string.charAt(208);
	//System.out.print(temp);
	   if(temp == '1') {
		   casing35HDDMax = "2";
		}
	   else if (temp == '2'){
		   casing35HDDMax = "3";
	   }
	   else if (temp == '3'){
		   casing35HDDMax = "4";
	   }
	   else if (temp == '4'){
		   casing35HDDMax = "5";
	   }
	   else if (temp == '5'){
		   casing35HDDMax = "6";
	   }
	   else if (temp == '6'){
		   casing35HDDMax = "7";
	   }
	
	   else if (temp == '7'){
		   casing35HDDMax = "8";
	   }
	
	   else if (temp == '8'){
		   casing35HDDMax = "9";
	   }
	
	   else if (temp == '9'){
		   casing35HDDMax = "10";
	   }
	   else if (temp == 'a'){
		   casing35HDDMax = "11";
	   }
	   else if (temp == 'b'){
		   casing35HDDMax = "12";
	   }
	   else if (temp == 'c'){
		   casing35HDDMax = "13";
	   }
	   return casing35HDDMax;
}

public static String casing525BatyMin() {
	temp = string.charAt(209);
	//System.out.print(temp);
	   if(temp == '1') {
		   casing525BatyMin = "0";
		}
	   else if (temp == '2'){
		   casing525BatyMin = "1";
	   }
	   else if (temp == '3'){
		   casing525BatyMin = "2";
	   }
	   else if (temp == '4'){
		   casing525BatyMin = "3";
	   }
	   else if (temp == '5'){
		   casing525BatyMin = "4";
	   }
	   else if (temp == '6'){
		   casing525BatyMin = "5";
	   }
	
	   else if (temp == '7'){
		   casing525BatyMin = "6";
	   }
	
	   else if (temp == '8'){
		   casing525BatyMin = "7";
	   }
	
	   else if (temp == '9'){
		   casing525BatyMin = "8";
	   }
	   else if (temp == 'a'){
		   casing525BatyMin = "9";
	   }
	return casing525BatyMin;
}
public static String casing525BatyMax() {
	temp = string.charAt(210);
	//System.out.print(temp);
	   if(temp == '1') {
		   casing525BatyMax = "0";
		}
	   else if (temp == '2'){
		   casing525BatyMax = "1";
	   }
	   else if (temp == '3'){
		   casing525BatyMax = "2";
	   }
	   else if (temp == '4'){
		   casing525BatyMax = "3";
	   }
	   else if (temp == '5'){
		   casing525BatyMax = "4";
	   }
	   else if (temp == '6'){
		   casing525BatyMax = "5";
	   }
	
	   else if (temp == '7'){
		   casing525BatyMax = "6";
	   }
	
	   else if (temp == '8'){
		   casing525BatyMax = "7";
	   }
	
	   else if (temp == '9'){
		   casing525BatyMax = "8";
	   }
	   else if (temp == 'a'){
		   casing525BatyMax = "9";
	   }
	   return casing525BatyMax;
}

//210
//SSD
// boxen = 211 212 213 214 215 216 217 218 219 220 221 222 223 224 225 
// radio = 226
// radio = 227
// slider = 228 min 229 max
// box = 230 231 232 233 234 235 236 237
// box = 238 239 240 241 242 243 244 245
// slider= 246 min 247 max
// slider = 248 min 249 max 

public static String ssdstoragecapacity30gb() {
	temp = string.charAt(211);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity30gb = "30GB";
	}
	else {
		ssdstoragecapacity30gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity30gb;
}


public static String ssdstoragecapacity60gb() {
	temp = string.charAt(212);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity60gb = "60GB";
	}
	else {
		ssdstoragecapacity60gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity60gb;
}
	
	
	
	

public static  String ssdstoragecapacity64gb() {
	temp = string.charAt(213);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity64gb = "64GB";
	}
	else {
		ssdstoragecapacity64gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity64gb;
}
	

public static  String ssdstoragecapacity80gb() {
	temp = string.charAt(214);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity80gb = "80GB";
	}
	else {
		ssdstoragecapacity80gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity80gb;
}

public static String ssdstoragecapacity120gb() {
	temp = string.charAt(215);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity120gb = "120GB";
	}
	else {
		ssdstoragecapacity120gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity120gb;
}


public static String ssdstoragecapacity128gb() {
	temp = string.charAt(216);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity128gb = "128GB";
	}
	else {
		ssdstoragecapacity128gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity128gb;
}


public static String ssdstoragecapacity180gb() {
	temp = string.charAt(217);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity180gb = "180GB";
	}
	else {
		ssdstoragecapacity180gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity180gb;
}

public static String ssdstoragecapacity240gb() {
	temp = string.charAt(218);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity240gb = "240GB";
	}
	else {
		ssdstoragecapacity240gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity240gb;
}

public static String ssdstoragecapacity250gb() {
	temp = string.charAt(219);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity250gb = "250GB";
	}
	else {
		ssdstoragecapacity250gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity250gb;
}

public static String ssdstoragecapacity256gb() {
	temp = string.charAt(220);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity256gb = "256GB";
	}
	else {
		ssdstoragecapacity256gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity256gb;
}


public static String ssdstoragecapacity480gb() {
	temp = string.charAt(221);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity480gb = "480GB";
	}
	else {
		ssdstoragecapacity480gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity480gb;
}

public static String ssdstoragecapacity500gb() {
	temp = string.charAt(222);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity500gb = "500GB";
	}
	else {
		ssdstoragecapacity500gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity500gb;
}

public static String ssdstoragecapacity512gb() {
	temp = string.charAt(223);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity512gb = "512GB";
	}
	else {
		ssdstoragecapacity512gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity512gb;
}

public static String ssdstoragecapacity960gb() {
	temp = string.charAt(224);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity960gb = "960GB";
	}
	else {
		ssdstoragecapacity960gb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity960gb;
}

public static String ssdstoragecapacity1tb() {
	temp = string.charAt(225);
	//System.out.print(temp);
	if(temp == '1') {
		ssdstoragecapacity1tb = "1000 GB";
	}
	else {
		ssdstoragecapacity1tb = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdstoragecapacity1tb;
}




public static String ssdFormaat() {
	temp = string.charAt(226);
	//System.out.print(temp);
	   if(temp == '1') {
		   ssdFormaat = "2,5 inch";
		}
	   else if (temp == '2'){
		   ssdFormaat = "mSATA(6Gb/s)";
	   }
	   else if (temp == '3'){
		   ssdFormaat = "M.2, 550MB/s";
	   }
	   return ssdFormaat; 
}
public static String ssdTypeMemory() {
	temp = string.charAt(227);
	//System.out.print(temp);
	   if(temp == '1') {
		   ssdTypeMemory = "Multi Level Cell (MLC)";
		}
	   else if (temp == '2'){
		   ssdTypeMemory = "Triple Level Cell (TLC)";
	   }
	   return ssdTypeMemory;
}

public static String ssdPrijsMin() {
	temp = string.charAt(228);
	//System.out.print(temp);
	   if(temp == '1') {
		   ssdPrijsMin = "0";
		}
	   else if (temp == '2'){
		   ssdPrijsMin = "50";
	   }
	   else if (temp == '3'){
		   ssdPrijsMin = "100";
	   }
	   else if (temp == '4'){
		   ssdPrijsMin = "150";
	   }
	   else if (temp == '5'){
		   ssdPrijsMin = "200";
	   }
	   else if (temp == '6'){
		   ssdPrijsMin = "250";
	   }
	
	   else if (temp == '7'){
		   ssdPrijsMin = "300";
	   }
	
	   else if (temp == '8'){
		   ssdPrijsMin = "350";
	   }
	
	   else if (temp == '9'){
		   ssdPrijsMin = "400";
	   }
	   else if (temp == 'a'){
		   ssdPrijsMin = "450";
	   }
	   else if (temp == 'b'){
		   ssdPrijsMin = "500";
	   }
	   else if (temp == 'c'){
		   ssdPrijsMin = "550";
	   }
	
	   else if (temp == 'd'){
		   ssdPrijsMin = "600";
	   }
	   return ssdPrijsMin;
	
}

public static String ssdPrijsMax() {
	temp = string.charAt(229);
	//System.out.print(temp);
	   if(temp == '1') {
		   ssdPrijsMax = "0";
		}
	   else if (temp == '2'){
		   ssdPrijsMax = "50";
	   }
	   else if (temp == '3'){
		   ssdPrijsMax = "100";
	   }
	   else if (temp == '4'){
		   ssdPrijsMax = "150";
	   }
	   else if (temp == '5'){
		   ssdPrijsMax = "200";
	   }
	   else if (temp == '6'){
		   ssdPrijsMax = "250";
	   }
	
	   else if (temp == '7'){
		   ssdPrijsMax = "300";
	   }
	
	   else if (temp == '8'){
		   ssdPrijsMax = "350";
	   }
	
	   else if (temp == '9'){
		   ssdPrijsMax = "400";
	   }
	   else if (temp == 'a'){
		   ssdPrijsMax = "450";
	   }
	   else if (temp == 'b'){
		   ssdPrijsMax = "500";
	   }
	   else if (temp == 'c'){
		   ssdPrijsMax = "550";
	   }
	
	   else if (temp == 'd'){
		   ssdPrijsMax = "600";
	   }
	   return ssdPrijsMax;
}


		

public static String ssdMerkAMD() {
	temp = string.charAt(230);
	//System.out.print(temp);
	if(temp == '1') {
		ssdMerkAMD = "AMD";
	}
	else {
		ssdMerkAMD = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdMerkAMD;
}

public static String ssdMerkCrucial() {
	temp = string.charAt(231);
	//System.out.print(temp);
	if(temp == '1') {
		ssdMerkCrucial = "Crucial";
	}
	else {
		ssdMerkCrucial = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdMerkCrucial;
}

public static String ssdMerkIntel() {
	temp = string.charAt(232);
	//System.out.print(temp);
	if(temp == '1') {
		ssdMerkIntel = "Intel";
	}
	else {
		ssdMerkIntel = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdMerkIntel;
}

public static String sssdMerkKingston() {
	temp = string.charAt(233);
	//System.out.print(temp);
	if(temp == '1') {
		sssdMerkKingston = "Kingston";
	}
	else {
		sssdMerkKingston = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return sssdMerkKingston;
}

public static String ssdMerkOCZ() {
	temp = string.charAt(234);
	//System.out.print(temp);
	if(temp == '1') {
		ssdMerkOCZ = "OCZ";
	}
	else {
		ssdMerkOCZ = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdMerkOCZ;
}


public static String ssdMerkSamsung() {
	temp = string.charAt(235);
	//System.out.print(temp);
	if(temp == '1') {
		ssdMerkSamsung = "Samsung";
	}
	else {
		ssdMerkSamsung = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdMerkSamsung;
}
public static String ssdMerkSanDisk() {
	temp = string.charAt(236);
	//System.out.print(temp);
	if(temp == '1') {
		ssdMerkSanDisk = "Sandisk";
	}
	else {
		ssdMerkSanDisk = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return ssdMerkSanDisk;
}

public static String sssdMerkGeenvoorkeur() {
	temp = string.charAt(237);
	//System.out.print(temp);
	if(temp == '1') {
		sssdMerkGeenvoorkeur = "Geen voorkeur";
	}
	else {
		sssdMerkGeenvoorkeur = "chooseplease";
	}
	//System.out.print(cpu_p4);
	return sssdMerkGeenvoorkeur;
}



public static String ssdControllerIndilinx() {
	temp = string.charAt(238);
	//System.out.print(temp);
	if(temp == '1') {
		ssdControllerIndilinx = "Indilinx";
	}
	else {
		ssdControllerIndilinx = "0";
	}
	//System.out.print(cpu_p4);
	return ssdControllerIndilinx;
}

public static String ssdControllerIntel() {
	temp = string.charAt(239);
	//System.out.print(temp);
	if(temp == '1') {
		ssdControllerIntel = "Intel";
	}
	else {
		ssdControllerIntel = "0";
	}
	
	//System.out.print(cpu_p4);
	return ssdControllerIntel;
}

public static String ssdControllerMarvell() {
	temp = string.charAt(240);
	//System.out.print(temp);
	if(temp == '1') {
		ssdControllerMarvell = "Marvell";
	}
	else {
		ssdControllerMarvell = "0";
	}
	//System.out.print(cpu_p4);
	return ssdControllerMarvell;
}

public static String ssdControllerSamsung() {
	temp = string.charAt(241);
	//System.out.print(temp);
	if(temp == '1') {
		ssdControllerSamsung = "Samsung";
	}
	else {
		ssdControllerSamsung = "0";
	}
	//System.out.print(cpu_p4);
	return ssdControllerSamsung;
}

public static String ssdControllerSandForce() {
	temp = string.charAt(242);
	//System.out.print(temp);
	if(temp == '1') {
		ssdControllerSandForce = "SandForce";
	}
	else {
		ssdControllerSandForce = "0";
	}
	//System.out.print(cpu_p4);
	return ssdControllerSandForce;
}

public static String ssdControllerPhison() {
	temp = string.charAt(243);
	//System.out.print(temp);
	if(temp == '1') {
		ssdControllerPhison = "Phison";
	}
	else {
		ssdControllerPhison = "0";
	}
	return ssdControllerPhison;
}

public static String ssdWritingSpeedMin() {
	temp = string.charAt(244);
	   if(temp == '1') {
		   ssdWritingSpeedMin = "100MB/s";
		}
	   else if (temp == '2'){
		   ssdWritingSpeedMin = "150MB/s";
	   }
	   else if (temp == '3'){
		   ssdPrijsMax = "200MB/s";
	   }
	   else if (temp == '4'){
		   ssdWritingSpeedMin = "250MB/s";
	   }
	   else if (temp == '5'){
		   ssdWritingSpeedMin = "300MB/s";
	   }
	   else if (temp == '6'){
		   ssdWritingSpeedMin = "350MB/s";
	   }
	
	   else if (temp == '7'){
		   ssdWritingSpeedMin = "400MB/s";
	   }
	
	   else if (temp == '8'){
		   ssdWritingSpeedMin = "450MB/s";
	   }
	
	   else if (temp == '9'){
		   ssdWritingSpeedMin = "500MB/s";
	   }
	   else if (temp == 'a'){
		   ssdWritingSpeedMin = "550MB/s";
	   }
	   else if (temp == 'b'){
		   ssdWritingSpeedMin = "600MB/s";
	   }
	   return ssdWritingSpeedMin;
	
}




public static String ssdWritingSpeedMax() {
	temp = string.charAt(245);
	   if(temp == '1') {
		   ssdWritingSpeedMax = "100MB/s";
		}
	   else if (temp == '2'){
		   ssdWritingSpeedMax = "150MB/s";
	   }
	   else if (temp == '3'){
		   ssdWritingSpeedMax = "200MB/s";
	   }
	   else if (temp == '4'){
		   ssdWritingSpeedMax = "250MB/s";
	   }
	   else if (temp == '5'){
		   ssdWritingSpeedMax = "300MB/s";
	   }
	   else if (temp == '6'){
		   ssdWritingSpeedMax = "350MB/s";
	   }
	
	   else if (temp == '7'){
		   ssdWritingSpeedMax = "400MB/s";
	   }
	
	   else if (temp == '8'){
		   ssdWritingSpeedMax = "450MB/s";
	   }
	
	   else if (temp == '9'){
		   ssdWritingSpeedMax = "500MB/s";
	   }
	   else if (temp == 'a'){
		   ssdWritingSpeedMax = "550MB/s";
	   }
	   else if (temp == 'b'){
		   ssdWritingSpeedMax = "600MB/s";
	   }
	   return ssdWritingSpeedMax;
	
}



public static String ssdReadingSpeedMin() {
	temp = string.charAt(246);
	   if(temp == '1') {
		   ssdReadingSpeedMin = "410MB/s";
		}
	   else if (temp == '2'){
		   ssdReadingSpeedMin = "430MB/s";
	   }
	   else if (temp == '3'){
		   ssdReadingSpeedMin = "450MB/s";
	   }
	   else if (temp == '4'){
		   ssdReadingSpeedMin = "470MB/s";
	   }
	   else if (temp == '5'){
		   ssdReadingSpeedMin = "490MB/s";
	   }
	   else if (temp == '6'){
		   ssdReadingSpeedMin = "510MB/s";
	   }
	
	   else if (temp == '7'){
		   ssdReadingSpeedMin = "530MB/s";
	   }
	   else if (temp == '8'){
		   ssdReadingSpeedMin = "550MB/s";
	   }
	   return ssdReadingSpeedMin;
}
public static String ssdReadingSpeedMax() {
	temp = string.charAt(247);
	   if(temp == '1') {
		   ssdReadingSpeedMax = "410MB/s";
		}
	   else if (temp == '2'){
		   ssdReadingSpeedMax = "430MB/s";
	   }
	   else if (temp == '3'){
		   ssdReadingSpeedMax = "450MB/s";
	   }
	   else if (temp == '4'){
		   ssdReadingSpeedMax = "470MB/s";
	   }
	   else if (temp == '5'){
		   ssdReadingSpeedMax = "490MB/s";
	   }
	   else if (temp == '6'){
		   ssdReadingSpeedMax = "510MB/s";
	   }
	
	   else if (temp == '7'){
		   ssdReadingSpeedMax = "530MB/s";
	   }
	   else if (temp == '8'){
		   ssdReadingSpeedMax = "550MB/s";
	   }
	   return ssdReadingSpeedMax;
}

public static String BluRayDVDMerkAsus() {
	temp = string.charAt(248);
	
	if(temp == '1') {
		BluRayDVDMerkAsus = "Asus";
	}
	else {
		BluRayDVDMerkAsus = "chooseplease";
	}
	
	return BluRayDVDMerkAsus;
}

public static String BluRayDVDMerkFreecom() {
	temp = string.charAt(249);

	if(temp == '1') {
		BluRayDVDMerkFreecom = "Freecom";
	}
	else {
		BluRayDVDMerkFreecom = "chooseplease";
	}

	return BluRayDVDMerkFreecom;
}

public static String BluRayDVDMerkApple() {
	temp = string.charAt(250);

	if(temp == '1') {
		BluRayDVDMerkApple = "Apple";
	}
	else {
		BluRayDVDMerkApple = "chooseplease";
	}

	return BluRayDVDMerkApple;
}
public static String BluRayDVDMerkLG() {
	temp = string.charAt(251);
	
	if(temp == '1') {
		BluRayDVDMerkLG = "LG";
	}
	else {
		BluRayDVDMerkLG = "chooseplease";
	}

	return BluRayDVDMerkLG;
}

public static String BluRayDVDMerkSamsung() {
	temp = string.charAt(252);

	if(temp == '1') {
		BluRayDVDMerkSamsung = "Samsung";
	}
	else {
		BluRayDVDMerkSamsung = "chooseplease";
	}
;
	return BluRayDVDMerkSamsung;
}

public static String BluRayDVDMerkGeenvoorkeur() {
	temp = string.charAt(253);

	if(temp == '1') {
		BluRayDVDMerkGeenvoorkeur = "Geen voorkeur";
	}
	else {
		BluRayDVDMerkGeenvoorkeur = "chooseplease";
	}
	
	return BluRayDVDMerkGeenvoorkeur;
}

public static String BluRayDVDDriverType() {
	temp = string.charAt(254);
	   if(temp == '1') {
		   BluRayDVDDriverType = "Intern";
		}
	   else if (temp == '2'){
		   BluRayDVDDriverType = "Extern";
	   }
	   return BluRayDVDDriverType;
} 
public static String BluRayDVDPrijsmin() {
	temp = string.charAt(255); 
	if(temp == '1') {
		BluRayDVDPrijsmin = "0";
		}
	   else if (temp == '2'){
		   BluRayDVDPrijsmin = "20";
	   }
	   else if (temp == '3'){
		   BluRayDVDPrijsmin = "40";
	   }
	   else if (temp == '4'){
		   BluRayDVDPrijsmin = "60";
	   }
	   else if (temp == '5'){
		   BluRayDVDPrijsmin = "80";
	   }
	   else if (temp == '6'){
		   BluRayDVDPrijsmin = "100";
	   }
	
	   else if (temp == '7'){
		   BluRayDVDPrijsmin = "20";
	   }
	return BluRayDVDPrijsmin;
}
public static String BluRayDVDPrijsmax() {
	temp = string.charAt(256); 
	if(temp == '1') {
		BluRayDVDPrijsmax = "0";
		}
	   else if (temp == '2'){
		   BluRayDVDPrijsmax = "20";
	   }
	   else if (temp == '3'){
		   BluRayDVDPrijsmax = "40";
	   }
	   else if (temp == '4'){
		   BluRayDVDPrijsmax = "60";
	   }
	   else if (temp == '5'){
		   BluRayDVDPrijsmax = "80";
	   }
	   else if (temp == '6'){
		   BluRayDVDPrijsmax = "100";
	   }
	
	   else if (temp == '7'){
		   BluRayDVDPrijsmax = "20";
	   }
	return BluRayDVDPrijsmax;
}


public static String BluRayDVDPlaysDiscBluray() {
	temp = string.charAt(257);
	if(temp == '1') {
		BluRayDVDPlaysDiscBluray = "Blu-ray";
	}
	else {
		BluRayDVDPlaysDiscBluray = "chooseplease";
	}
	return BluRayDVDPlaysDiscBluray;
}

public static String BluRayDVDPlaysDiscDVD() {
	temp = string.charAt(258);
	if(temp == '1') {
		BluRayDVDPlaysDiscDVD = "DVD";
	}
	else {
		BluRayDVDPlaysDiscDVD = "chooseplease";
	}
	return BluRayDVDPlaysDiscDVD;
}

public static String BluRayDVDPlaysDiscCD() {
	temp = string.charAt(259);
	if(temp == '1') {
		BluRayDVDPlaysDiscCD = "CD";
	}
	else {
		BluRayDVDPlaysDiscCD = "chooseplease";
	}
	return BluRayDVDPlaysDiscCD;
}

public static String BluRayDVDPlaysDiscFloppy() {
	temp = string.charAt(260);
	if(temp == '1') {
		BluRayDVDPlaysDiscFloppy = "Floppy";
	}
	else {
		BluRayDVDPlaysDiscFloppy = "chooseplease";
	}
	return BluRayDVDPlaysDiscFloppy;
}

public static String BluRayDVDOperatingSystem() {
	temp = string.charAt(261);
	   if(temp == '1') {
		   BluRayDVDOperatingSystem = "Windows";
		}
	   else if (temp == '2'){
		   BluRayDVDOperatingSystem = "Mac OS X";
	   }
	   return BluRayDVDOperatingSystem;
} 

public static String BluRayDVDtypetray() {
	temp = string.charAt(262);
	   if(temp == '1') {
		   BluRayDVDtypetray = "Lade";
		}
	   else if (temp == '2'){
		   BluRayDVDtypetray = "Slot-in ";
	   }
	   return BluRayDVDtypetray;
}

}







